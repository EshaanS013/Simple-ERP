const express = require('express');
const { pool } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound } = require('../middleware/errorHandler');
const { emitEvent } = require('../socket/socket');
const { recordActivity } = require('../utils/activity');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

router.get('/', asyncHandler(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT n.*, u.name AS author_name FROM notices n
     LEFT JOIN users u ON u.id = n.author_id
     ORDER BY n.pinned DESC, n.created_at DESC`
  );
  res.json({ data: rows });
}));

router.post('/', managerOnly, validate({ body: schemas.createNotice }), asyncHandler(async (req, res) => {
  const { title, content, urgent, pinned } = req.body;
  const { rows } = await pool.query(
    `INSERT INTO notices (title, content, urgent, pinned, author_id) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [title, content, urgent || false, pinned || false, req.user.id]
  );
  const notice = { ...rows[0], author_name: req.user.name };
  emitEvent('notice_created', notice);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'posted a notice', module: 'Notices', details: title, entityType: 'notice', entityId: notice.id });
  res.status(201).json(notice);
}));

router.delete('/:id', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rows, rowCount } = await pool.query('DELETE FROM notices WHERE id = $1 RETURNING title', [req.params.id]);
  if (rowCount === 0) throw notFound('Notice not found');
  emitEvent('notice_deleted', { id: Number(req.params.id) });
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'removed a notice', module: 'Notices', details: rows[0].title });
  res.json({ success: true });
}));

module.exports = router;
