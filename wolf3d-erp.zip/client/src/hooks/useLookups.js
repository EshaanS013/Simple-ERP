import { useState, useEffect } from 'react';
import Api from '../services/api';

// Loads the lookup datasets a form needs, once. Returns { users, clients, projects, departments }.
export function useLookups(needed = []) {
  const [data, setData] = useState({ users: [], clients: [], projects: [], departments: [] });

  useEffect(() => {
    let active = true;
    (async () => {
      const out = {};
      try {
        if (needed.includes('users')) out.users = await Api.usersLookup();
        if (needed.includes('clients')) {
          const r = await Api.list('clients', { pageSize: 200 });
          out.clients = r.data || [];
        }
        if (needed.includes('projects')) {
          const r = await Api.list('projects', { pageSize: 200 });
          out.projects = r.data || [];
        }
        if (needed.includes('departments')) {
          const r = await Api.departments();
          out.departments = r.data || [];
        }
      } catch { /* non-fatal */ }
      if (active) setData((d) => ({ ...d, ...out }));
    })();
    return () => { active = false; };
  }, [needed.join(',')]);

  return data;
}
