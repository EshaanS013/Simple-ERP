import { useEffect } from 'react';
import { Loader2, Inbox, AlertTriangle, X, Search, ChevronLeft, ChevronRight } from 'lucide-react';

// ---- Feedback states ----
export function Spinner({ className = 'h-5 w-5' }) {
  return <Loader2 className={`animate-spin text-brand-600 ${className}`} />;
}

export function LoadingState({ label = 'Loading…' }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-slate-500">
      <Spinner className="h-6 w-6" />
      <p className="text-sm">{label}</p>
    </div>
  );
}

export function EmptyState({ title = 'Nothing here yet', message, action }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-16 text-center">
      <div className="rounded-full bg-slate-100 p-3"><Inbox className="h-6 w-6 text-slate-400" /></div>
      <p className="text-sm font-medium text-slate-700">{title}</p>
      {message && <p className="max-w-sm text-sm text-slate-500">{message}</p>}
      {action && <div className="mt-3">{action}</div>}
    </div>
  );
}

export function ErrorState({ message = 'Could not load this data.', onRetry }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-16 text-center">
      <div className="rounded-full bg-red-50 p-3"><AlertTriangle className="h-6 w-6 text-red-500" /></div>
      <p className="text-sm font-medium text-slate-700">{message}</p>
      {onRetry && <button onClick={onRetry} className="btn-secondary btn-sm mt-2">Try again</button>}
    </div>
  );
}

// ---- Badges ----
const STATUS_STYLES = {
  pending: 'bg-amber-50 text-amber-700',
  awaiting: 'bg-slate-100 text-slate-600',
  work_order: 'bg-slate-100 text-slate-600',
  in_production: 'bg-blue-50 text-blue-700',
  production: 'bg-blue-50 text-blue-700',
  in_quality: 'bg-violet-50 text-violet-700',
  quality: 'bg-violet-50 text-violet-700',
  ready_for_dispatch: 'bg-amber-50 text-amber-700',
  dispatch: 'bg-amber-50 text-amber-700',
  on_hold: 'bg-orange-50 text-orange-700',
  received: 'bg-emerald-50 text-emerald-700',
  overdue: 'bg-red-50 text-red-700',
  partial: 'bg-violet-50 text-violet-700',
  in_progress: 'bg-blue-50 text-blue-700',
  in_review: 'bg-blue-50 text-blue-700',
  partially_complete: 'bg-violet-50 text-violet-700',
  ready: 'bg-amber-50 text-amber-700',
  dispatched: 'bg-blue-50 text-blue-700',
  completed: 'bg-emerald-50 text-emerald-700',
  approved: 'bg-emerald-50 text-emerald-700',
  delivered: 'bg-emerald-50 text-emerald-700',
  cancelled: 'bg-slate-100 text-slate-500',
  rejected: 'bg-red-50 text-red-700',
  blocked: 'bg-red-50 text-red-700',
  returned: 'bg-red-50 text-red-700',
  active: 'bg-emerald-50 text-emerald-700',
  inactive: 'bg-slate-100 text-slate-500'
};
const PRIORITY_STYLES = {
  low: 'bg-slate-100 text-slate-600',
  medium: 'bg-blue-50 text-blue-700',
  high: 'bg-amber-50 text-amber-700',
  critical: 'bg-red-50 text-red-700'
};
const humanize = (s) => (s ? String(s).replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()) : '—');

export function StatusBadge({ value }) {
  return <span className={`badge ${STATUS_STYLES[value] || 'bg-slate-100 text-slate-600'}`}>{humanize(value)}</span>;
}
export function PriorityBadge({ value }) {
  return <span className={`badge ${PRIORITY_STYLES[value] || 'bg-slate-100 text-slate-600'}`}>{humanize(value)}</span>;
}

// ---- Page header ----
export function PageHeader({ title, subtitle, children }) {
  return (
    <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-xl font-semibold tracking-tight text-slate-900">{title}</h1>
        {subtitle && <p className="mt-0.5 text-sm text-slate-500">{subtitle}</p>}
      </div>
      {children && <div className="flex items-center gap-2">{children}</div>}
    </div>
  );
}

// ---- Search input ----
export function SearchBar({ value, onChange, placeholder = 'Search…' }) {
  return (
    <div className="relative">
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
      <input value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className="input pl-9" />
    </div>
  );
}

// ---- Pagination ----
export function Pagination({ pagination, onPage }) {
  if (!pagination) return null;
  const { page, totalPages, total, pageSize } = pagination;
  const from = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, total);
  return (
    <div className="flex items-center justify-between border-t border-slate-100 px-4 py-3 text-sm text-slate-500">
      <span>{from}–{to} of {total}</span>
      <div className="flex items-center gap-1">
        <button className="btn-ghost btn-sm" disabled={page <= 1} onClick={() => onPage(page - 1)}><ChevronLeft className="h-4 w-4" /></button>
        <span className="px-2 text-slate-700">Page {page} / {totalPages}</span>
        <button className="btn-ghost btn-sm" disabled={page >= totalPages} onClick={() => onPage(page + 1)}><ChevronRight className="h-4 w-4" /></button>
      </div>
    </div>
  );
}

// ---- Modal ----
export function Modal({ open, onClose, title, children, footer, size = 'md' }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = ''; };
  }, [open, onClose]);
  if (!open) return null;
  const widths = { sm: 'max-w-md', md: 'max-w-xl', lg: 'max-w-3xl' };
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-slate-900/40 p-4 sm:p-8" onMouseDown={onClose}>
      <div className={`animate-scale-in mt-4 w-full ${widths[size]} card shadow-pop`} onMouseDown={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between border-b border-slate-100 px-5 py-4">
          <h2 className="text-base font-semibold text-slate-900">{title}</h2>
          <button onClick={onClose} className="btn-ghost btn-sm -mr-2"><X className="h-4 w-4" /></button>
        </div>
        <div className="max-h-[70vh] overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="flex items-center justify-end gap-2 border-t border-slate-100 px-5 py-3">{footer}</div>}
      </div>
    </div>
  );
}

export function ConfirmDialog({ open, onClose, onConfirm, title = 'Are you sure?', message, confirmLabel = 'Delete', busy }) {
  return (
    <Modal open={open} onClose={onClose} title={title} size="sm"
      footer={<>
        <button className="btn-secondary" onClick={onClose} disabled={busy}>Cancel</button>
        <button className="btn-danger" onClick={onConfirm} disabled={busy}>{busy ? 'Working…' : confirmLabel}</button>
      </>}>
      <p className="text-sm text-slate-600">{message}</p>
    </Modal>
  );
}

// ---- Form fields ----
export function Field({ label, error, children, required }) {
  return (
    <div>
      {label && <label className="label">{label}{required && <span className="text-red-500"> *</span>}</label>}
      {children}
      {error && <p className="mt-1 text-xs text-red-600">{error}</p>}
    </div>
  );
}

export function Input(props) { return <input {...props} className={`input ${props.className || ''}`} />; }
export function Textarea(props) { return <textarea {...props} className={`input ${props.className || ''}`} />; }
export function Select({ children, ...props }) {
  return <select {...props} className={`input ${props.className || ''}`}>{children}</select>;
}
