import { useState, useEffect, useRef } from 'react';
import { Menu, Wifi, WifiOff, LogOut, ChevronDown, KeyRound } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { socket } from '../services/socket';

export default function Topbar({ onOpenSidebar }) {
  const { user, logout } = useAuth();
  const [online, setOnline] = useState(0);
  const [connected, setConnected] = useState(socket.connected);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef();
  const navigate = useNavigate();

  useEffect(() => {
    const onConnect = () => setConnected(true);
    const onDisconnect = () => setConnected(false);
    const onPresence = (p) => setOnline(p.onlineUsers);
    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    socket.on('presence', onPresence);
    return () => { socket.off('connect', onConnect); socket.off('disconnect', onDisconnect); socket.off('presence', onPresence); };
  }, []);

  useEffect(() => {
    const onClick = (e) => { if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false); };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  const initials = (user?.name || '?').split(' ').map((p) => p[0]).slice(0, 2).join('').toUpperCase();

  return (
    <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-slate-200 bg-white/90 px-3 backdrop-blur sm:px-5">
      <button onClick={onOpenSidebar} className="btn-ghost btn-sm lg:hidden"><Menu className="h-5 w-5" /></button>
      <div className="flex-1" />

      <span className={`badge ${connected ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'}`} title={connected ? 'Realtime connected' : 'Offline'}>
        {connected ? <Wifi className="h-3.5 w-3.5" /> : <WifiOff className="h-3.5 w-3.5" />}
        <span className="hidden sm:inline">{online} online</span>
      </span>

      <div ref={menuRef} className="relative">
        <button onClick={() => setMenuOpen((v) => !v)} className="flex items-center gap-2 rounded-lg px-1.5 py-1 hover:bg-slate-50">
          <span className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">{initials}</span>
          <span className="hidden text-left sm:block">
            <span className="block text-sm font-medium leading-tight text-slate-800">{user?.name}</span>
            <span className="block text-[11px] capitalize leading-tight text-slate-400">{user?.role}</span>
          </span>
          <ChevronDown className="h-4 w-4 text-slate-400" />
        </button>
        {menuOpen && (
          <div className="absolute right-0 z-40 mt-2 w-48 card animate-fade-in p-1.5">
            <button onClick={() => { setMenuOpen(false); navigate('/change-password'); }} className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-left text-sm text-slate-600 hover:bg-slate-50">
              <KeyRound className="h-4 w-4" /> Change password
            </button>
            <button onClick={logout} className="flex w-full items-center gap-2 rounded-md px-2.5 py-2 text-left text-sm text-red-600 hover:bg-red-50">
              <LogOut className="h-4 w-4" /> Sign out
            </button>
          </div>
        )}
      </div>
    </header>
  );
}
