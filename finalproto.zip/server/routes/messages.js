const express = require('express');
const { pool } = require('../db/pool');
const { authGuard } = require('../middleware/auth');
const { attachScope } = require('../utils/scope');
const { validate } = require('../middleware/validate');
const { asyncHandler, forbidden, notFound } = require('../middleware/errorHandler');
const { emitToUsers, getOnlineUserIds } = require('../socket/socket');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard, attachScope);

const RETENTION_DAYS = 30;

// Users this person is allowed to message: managers/admins → everyone;
// employees → only those who share at least one department.
async function reachableUserIds(req) {
  if (req.isManager) {
    const { rows } = await pool.query("SELECT id FROM users WHERE id<>$1 AND status='active'", [req.user.id]);
    return rows.map((r) => r.id);
  }
  const { rows } = await pool.query(
    `SELECT DISTINCT u.id FROM users u
       JOIN user_departments ud ON ud.user_id = u.id
      WHERE u.id<>$1 AND u.status='active'
        AND ud.department_id IN (SELECT department_id FROM user_departments WHERE user_id=$1)`,
    [req.user.id]
  );
  return rows.map((r) => r.id);
}

async function canMessage(req, otherId) {
  if (otherId === req.user.id) return false;
  const ids = await reachableUserIds(req);
  return ids.includes(Number(otherId));
}

// Contact list with online status, last message preview, and unread counts.
router.get('/contacts', asyncHandler(async (req, res) => {
  const ids = await reachableUserIds(req);
  if (ids.length === 0) return res.json({ data: [] });
  const online = new Set(getOnlineUserIds());
  const { rows } = await pool.query(
    `SELECT u.id, u.name, u.role,
        (SELECT body FROM messages m WHERE (m.sender_id=u.id AND m.recipient_id=$1) OR (m.sender_id=$1 AND m.recipient_id=u.id) ORDER BY m.created_at DESC LIMIT 1) AS last_body,
        (SELECT created_at FROM messages m WHERE (m.sender_id=u.id AND m.recipient_id=$1) OR (m.sender_id=$1 AND m.recipient_id=u.id) ORDER BY m.created_at DESC LIMIT 1) AS last_at,
        (SELECT COUNT(*)::int FROM messages m WHERE m.sender_id=u.id AND m.recipient_id=$1 AND m.read_at IS NULL) AS unread
       FROM users u WHERE u.id = ANY($2::int[])
       ORDER BY last_at DESC NULLS LAST, u.name`,
    [req.user.id, ids]
  );
  res.json({ data: rows.map((r) => ({ ...r, online: online.has(r.id) })) });
}));

// Total unread (for the nav badge).
router.get('/unread-count', asyncHandler(async (req, res) => {
  const { rows } = await pool.query('SELECT COUNT(*)::int c FROM messages WHERE recipient_id=$1 AND read_at IS NULL', [req.user.id]);
  res.json({ count: rows[0].c });
}));

// Search this user's own messages.
router.get('/search', asyncHandler(async (req, res) => {
  const q = (req.query.q || '').trim();
  if (!q) return res.json({ data: [] });
  const { rows } = await pool.query(
    `SELECT m.id, m.sender_id, m.recipient_id, m.body, m.created_at,
        s.name AS sender_name, r.name AS recipient_name
       FROM messages m JOIN users s ON s.id=m.sender_id JOIN users r ON r.id=m.recipient_id
      WHERE (m.sender_id=$1 OR m.recipient_id=$1) AND m.body ILIKE $2
      ORDER BY m.created_at DESC LIMIT 50`,
    [req.user.id, `%${q}%`]
  );
  res.json({ data: rows });
}));

// Conversation with a user (also marks their messages to me as read).
router.get('/:userId(\\d+)', asyncHandler(async (req, res) => {
  const other = Number(req.params.userId);
  if (!(await canMessage(req, other))) throw forbidden('You are not allowed to message this user');
  const { rows } = await pool.query(
    `SELECT id, sender_id, recipient_id, body, read_at, created_at FROM messages
      WHERE (sender_id=$1 AND recipient_id=$2) OR (sender_id=$2 AND recipient_id=$1)
      ORDER BY created_at ASC LIMIT 500`,
    [req.user.id, other]
  );
  const unreadIds = rows.filter((m) => m.recipient_id === req.user.id && !m.read_at).map((m) => m.id);
  if (unreadIds.length) {
    await pool.query('UPDATE messages SET read_at=NOW() WHERE id = ANY($1::int[])', [unreadIds]);
    emitToUsers([other], 'dm_read', { by: req.user.id });
  }
  res.json({ data: rows });
}));

// Send a message.
router.post('/', validate({ body: schemas.sendMessage }), asyncHandler(async (req, res) => {
  const { recipient_id, body } = req.body;
  if (!(await canMessage(req, recipient_id))) throw forbidden('You are not allowed to message this user');
  const { rows } = await pool.query(
    'INSERT INTO messages (sender_id, recipient_id, body) VALUES ($1,$2,$3) RETURNING id, sender_id, recipient_id, body, read_at, created_at',
    [req.user.id, recipient_id, body.trim()]
  );
  const msg = { ...rows[0], sender_name: req.user.name };
  emitToUsers([recipient_id, req.user.id], 'dm', msg);
  res.status(201).json(msg);
}));

// Delete messages older than the retention window. Called on a timer.
async function purgeOldMessages() {
  try { await pool.query(`DELETE FROM messages WHERE created_at < NOW() - INTERVAL '${RETENTION_DAYS} days'`); }
  catch (e) { /* table may not exist yet on first boot */ }
}

module.exports = router;
module.exports.purgeOldMessages = purgeOldMessages;
module.exports.RETENTION_DAYS = RETENTION_DAYS;
