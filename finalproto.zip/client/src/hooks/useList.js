import { useState, useEffect, useCallback, useRef } from 'react';
import Api from '../services/api';
import { socket } from '../services/socket';

// Generic paginated list loader for a REST resource.
// resource: 'projects' | 'tasks' | ...   refreshEvents: socket events that should re-fetch.
export function useList(resource, { pageSize = 25, refreshEvents = [], initialFilters = {} } = {}) {
  const [data, setData] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState(initialFilters);
  const debounceRef = useRef();

  const fetchData = useCallback(async () => {
    setError(null);
    try {
      const params = { page, pageSize, ...filters };
      if (search.trim()) params.search = search.trim();
      const res = await Api.list(resource, params);
      setData(res.data || []);
      setPagination(res.pagination || null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [resource, page, pageSize, search, filters]);

  // Debounce search; immediate for page/filter changes.
  useEffect(() => {
    setLoading(true);
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(fetchData, search ? 300 : 0);
    return () => clearTimeout(debounceRef.current);
  }, [fetchData, search]);

  // Live refresh on relevant socket events.
  useEffect(() => {
    if (!refreshEvents.length) return;
    const handler = () => fetchData();
    refreshEvents.forEach((ev) => socket.on(ev, handler));
    return () => refreshEvents.forEach((ev) => socket.off(ev, handler));
  }, [refreshEvents, fetchData]);

  const updateFilter = useCallback((key, value) => {
    setPage(1);
    setFilters((f) => {
      const next = { ...f };
      if (value === '' || value == null) delete next[key];
      else next[key] = value;
      return next;
    });
  }, []);

  const onSearch = useCallback((v) => { setPage(1); setSearch(v); }, []);

  return { data, pagination, loading, error, page, setPage, search, onSearch, filters, updateFilter, refetch: fetchData };
}
