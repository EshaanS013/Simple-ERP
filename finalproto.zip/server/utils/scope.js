const { pool } = require('../db/pool');

// Returns the department ids a user belongs to.
async function getUserDepartmentIds(userId) {
  const { rows } = await pool.query('SELECT department_id FROM user_departments WHERE user_id = $1', [userId]);
  return rows.map((r) => r.department_id);
}

// Express middleware: attaches req.isManager and req.deptIds (array).
// Managers get deptIds = null meaning "all departments".
async function attachScope(req, res, next) {
  try {
    req.isManager = req.user.role === 'manager' || req.user.role === 'admin';
    req.deptIds = req.isManager ? null : await getUserDepartmentIds(req.user.id);
    next();
  } catch (e) { next(e); }
}

// Can this user act within a given department?
function canUseDepartment(req, departmentId) {
  if (req.isManager) return true;
  if (departmentId == null) return false;
  return (req.deptIds || []).includes(Number(departmentId));
}

// Builds a SQL fragment + params to restrict `<alias>.department_id` to the
// user's departments. Managers get no restriction. Employees with no
// departments get an impossible condition (see nothing).
function departmentFilter(req, alias = 'department_id', startIndex = 1) {
  if (req.isManager) return { clause: '', params: [], nextIndex: startIndex };
  const ids = req.deptIds || [];
  if (ids.length === 0) return { clause: `${alias} = -1`, params: [], nextIndex: startIndex };
  return { clause: `${alias} = ANY($${startIndex}::int[])`, params: [ids], nextIndex: startIndex + 1 };
}

module.exports = { getUserDepartmentIds, attachScope, canUseDepartment, departmentFilter };
