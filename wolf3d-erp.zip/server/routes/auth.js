const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { pool } = require('../db/pool');
const config = require('../config/env');
const { asyncHandler, unauthorized, forbidden, badRequest } = require('../middleware/errorHandler');
const { authGuard } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { loginLimiter } = require('../middleware/rateLimit');
const schemas = require('../validators/schemas');

const router = express.Router();

function signToken(user) {
  return jwt.sign({ userId: user.id, role: user.role }, config.JWT_SECRET, {
    expiresIn: config.JWT_EXPIRES_IN
  });
}

function publicUser(u) {
  return {
    id: u.id,
    name: u.name,
    username: u.username,
    role: u.role,
    department_id: u.department_id,
    must_change_password: u.must_change_password
  };
}

router.post(
  '/login',
  loginLimiter,
  validate({ body: schemas.login }),
  asyncHandler(async (req, res) => {
    const { username, password } = req.body;
    const result = await pool.query(
      'SELECT id, name, username, password_hash, role, status, department_id, must_change_password FROM users WHERE username = $1',
      [username]
    );
    // Constant-ish behaviour: same error for unknown user vs bad password.
    const user = result.rows[0];
    if (!user) throw unauthorized('Invalid username or password');
    if (user.status !== 'active') throw forbidden('This account is inactive');

    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) throw unauthorized('Invalid username or password');

    await pool.query('UPDATE users SET last_login = NOW() WHERE id = $1', [user.id]);
    res.json({ token: signToken(user), user: publicUser(user) });
  })
);

router.get('/me', authGuard, asyncHandler(async (req, res) => {
  res.json(req.user);
}));

router.post(
  '/change-password',
  authGuard,
  validate({ body: schemas.changePassword }),
  asyncHandler(async (req, res) => {
    const { currentPassword, newPassword } = req.body;
    const { rows } = await pool.query('SELECT password_hash FROM users WHERE id = $1', [req.user.id]);
    const valid = await bcrypt.compare(currentPassword, rows[0].password_hash);
    if (!valid) throw badRequest('Current password is incorrect');

    const hash = await bcrypt.hash(newPassword, config.BCRYPT_ROUNDS);
    await pool.query(
      'UPDATE users SET password_hash = $1, must_change_password = FALSE WHERE id = $2',
      [hash, req.user.id]
    );
    res.json({ success: true });
  })
);

module.exports = router;
