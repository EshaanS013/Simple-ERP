import { useState, useEffect, useCallback } from 'react';
import { FolderKanban, ClipboardList, CheckSquare, Building2 } from 'lucide-react';
import Api from '../services/api';
import { PageHeader, LoadingState, ErrorState } from '../components/ui';

const humanize = (s) => String(s).replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
const COLORS = ['bg-brand-500', 'bg-blue-500', 'bg-emerald-500', 'bg-amber-500', 'bg-violet-500', 'bg-red-500', 'bg-slate-400'];

function BreakdownCard({ title, rows }) {
  const total = rows.reduce((s, r) => s + r.count, 0);
  return (
    <div className="card p-5">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-900">{title}</h3>
        <span className="text-xs text-slate-400">{total} total</span>
      </div>
      {rows.length === 0 ? <p className="py-4 text-center text-sm text-slate-400">No data</p> : (
        <>
          <div className="mb-3 flex h-2 w-full overflow-hidden rounded-full bg-slate-100">
            {rows.map((r, i) => <div key={r.status} className={COLORS[i % COLORS.length]} style={{ width: `${total ? (r.count / total) * 100 : 0}%` }} />)}
          </div>
          <div className="space-y-1.5">
            {rows.map((r, i) => (
              <div key={r.status} className="flex items-center justify-between text-sm">
                <span className="flex items-center gap-2 text-slate-600"><span className={`h-2.5 w-2.5 rounded-full ${COLORS[i % COLORS.length]}`} />{humanize(r.status)}</span>
                <span className="font-medium text-slate-900">{r.count}</span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default function Reports() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setError(null);
    try { setData(await Api.reports()); } catch (e) { setError(e.message); } finally { setLoading(false); }
  }, []);
  useEffect(() => { load(); }, [load]);

  if (loading) return <LoadingState label="Building reports…" />;
  if (error) return <ErrorState message={error} onRetry={load} />;

  const t = data.totals;
  const projectRate = t.total_projects ? Math.round((t.completed_projects / t.total_projects) * 100) : 0;
  const taskRate = t.total_tasks ? Math.round((t.completed_tasks / t.total_tasks) * 100) : 0;

  const kpis = [
    { label: 'Total Projects', value: t.total_projects, icon: FolderKanban, color: 'text-brand-600 bg-brand-50' },
    { label: 'Work Orders', value: t.total_work_orders, icon: ClipboardList, color: 'text-violet-600 bg-violet-50' },
    { label: 'Total Tasks', value: t.total_tasks, icon: CheckSquare, color: 'text-blue-600 bg-blue-50' },
    { label: 'Clients', value: t.total_clients, icon: Building2, color: 'text-emerald-600 bg-emerald-50' }
  ];

  return (
    <section className="space-y-6">
      <PageHeader title="Reports" subtitle="Operational metrics and completion analytics." />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {kpis.map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="card p-4">
            <div className={`mb-2 inline-flex h-9 w-9 items-center justify-center rounded-lg ${color}`}><Icon className="h-[18px] w-[18px]" /></div>
            <p className="text-2xl font-semibold text-slate-900">{value ?? 0}</p>
            <p className="text-xs text-slate-500">{label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="card p-5">
          <h3 className="mb-3 text-sm font-semibold text-slate-900">Project Completion Rate</h3>
          <div className="flex items-end gap-3">
            <span className="text-3xl font-semibold text-slate-900">{projectRate}%</span>
            <span className="pb-1 text-xs text-slate-500">{t.completed_projects} of {t.total_projects} completed</span>
          </div>
          <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-emerald-500" style={{ width: `${projectRate}%` }} /></div>
        </div>
        <div className="card p-5">
          <h3 className="mb-3 text-sm font-semibold text-slate-900">Task Completion Rate</h3>
          <div className="flex items-end gap-3">
            <span className="text-3xl font-semibold text-slate-900">{taskRate}%</span>
            <span className="pb-1 text-xs text-slate-500">{t.completed_tasks} of {t.total_tasks} completed</span>
          </div>
          <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-slate-100"><div className="h-full rounded-full bg-blue-500" style={{ width: `${taskRate}%` }} /></div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <BreakdownCard title="Projects by Status" rows={data.projects} />
        <BreakdownCard title="Tasks by Status" rows={data.tasks} />
        <BreakdownCard title="Work Orders by Status" rows={data.workOrders} />
        <BreakdownCard title="Quality by Status" rows={data.quality} />
        <BreakdownCard title="Dispatch by Status" rows={data.dispatch} />
      </div>
    </section>
  );
}
