import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { Plus, Trash2, Search, Check, X, Download, Wand2, MessageSquare, History } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useToast } from '../context/ToastContext';
import { LoadingState, ErrorState, EmptyState, Pagination, StatusBadge } from './ui';

// A spreadsheet-style table with click-to-edit cells that save instantly,
// plus multi-select bulk update / delete and CSV export.
// columns: [{ key, label, type:'text'|'number'|'date'|'select'|'badge', options?, width?, readOnly?, suggestions?, format? }]
export default function InlineTable({
  resource, columns, events,
  filters = null, newRowDefaults = {}, requiredKey,
  searchPlaceholder = 'Search…', extraParams = {}, canEdit = true, canCreate = true,
  onOpenComments = null, onOpenHistory = null
}) {
  const toast = useToast();
  const [rows, setRows] = useState([]);
  const [pagination, setPagination] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [filterVal, setFilterVal] = useState('');
  const [sort, setSort] = useState({ key: '', dir: 'desc' });
  const [editing, setEditing] = useState(null);
  const [draft, setDraft] = useState('');
  const [adding, setAdding] = useState(false);
  const [newRow, setNewRow] = useState({});
  const [selected, setSelected] = useState(() => new Set());
  const [bulkField, setBulkField] = useState('');
  const [bulkValue, setBulkValue] = useState('');
  const [bulkBusy, setBulkBusy] = useState(false);
  const searchRef = useRef(null);

  const params = {
    page, pageSize: 50, ...extraParams,
    ...(search ? { search } : {}),
    ...(filters && filterVal ? { [filters.key]: filterVal } : {}),
    ...(sort.key ? { sort: sort.key, dir: sort.dir } : {})
  };

  const load = useCallback(async () => {
    setError(null);
    try {
      const res = await Api.list(resource, params);
      setRows(res.data || []);
      setPagination(res.pagination || null);
      setSelected(new Set());
    } catch (e) { setError(e.message); } finally { setLoading(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resource, page, search, filterVal, sort.key, sort.dir, JSON.stringify(extraParams)]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const refresh = () => load();
    (events || []).forEach((e) => socket.on(e, refresh));
    return () => (events || []).forEach((e) => socket.off(e, refresh));
  }, [events, load]);

  const editableCols = useMemo(() => columns.filter((c) => !c.readOnly && c.key !== 'department_name'), [columns]);

  const startEdit = (row, col) => {
    if (!canEdit || col.readOnly) return;
    setEditing({ id: row.id, key: col.key });
    const raw = row[col.key];
    setDraft(col.type === 'date' && raw ? String(raw).slice(0, 10) : (raw ?? ''));
  };

  const commit = async (row, col) => {
    const value = draft === '' ? null : draft;
    setEditing(null);
    if ((row[col.key] ?? '') === (value ?? '')) return;
    setRows((rs) => rs.map((r) => (r.id === row.id ? { ...r, [col.key]: value } : r)));
    try { await Api.update(resource, row.id, { [col.key]: value }); }
    catch (e) { toast.error(e.message); load(); }
  };

  const addRow = async () => {
    if (requiredKey && !String(newRow[requiredKey] || '').trim()) {
      toast.error(`${columns.find((c) => c.key === requiredKey)?.label || 'A field'} is required`);
      return;
    }
    try {
      await Api.create(resource, { ...newRowDefaults, ...newRow });
      toast.success('Row added'); setAdding(false); setNewRow({}); load();
    } catch (e) { toast.error(e.message); }
  };

  const del = async (row) => {
    setRows((rs) => rs.filter((r) => r.id !== row.id));
    try { await Api.remove(resource, row.id); } catch (e) { toast.error(e.message); load(); }
  };

  const toggleSort = (col) => {
    if (col.noSort) return;
    setSort((s) => (s.key === col.key ? { key: col.key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key: col.key, dir: 'asc' }));
  };

  // ---- selection ----
  const allOnPage = rows.length > 0 && rows.every((r) => selected.has(r.id));
  const toggleAll = () => setSelected(allOnPage ? new Set() : new Set(rows.map((r) => r.id)));
  const toggleOne = (id) => setSelected((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; });

  // ---- bulk update ----
  const bulkCol = editableCols.find((c) => c.key === bulkField);
  const applyBulk = async () => {
    if (!bulkField) { toast.error('Choose a field to update'); return; }
    const ids = [...selected];
    const value = bulkValue === '' ? null : bulkValue;
    setBulkBusy(true);
    setRows((rs) => rs.map((r) => (selected.has(r.id) ? { ...r, [bulkField]: value } : r)));
    try {
      await Promise.all(ids.map((id) => Api.update(resource, id, { [bulkField]: value })));
      toast.success(`Updated ${ids.length} row${ids.length > 1 ? 's' : ''}`);
      setBulkField(''); setBulkValue('');
    } catch (e) { toast.error(e.message); load(); } finally { setBulkBusy(false); }
  };

  const bulkDelete = async () => {
    const ids = [...selected];
    setBulkBusy(true);
    setRows((rs) => rs.filter((r) => !selected.has(r.id)));
    setSelected(new Set());
    try {
      await Promise.all(ids.map((id) => Api.remove(resource, id)));
      toast.success(`Deleted ${ids.length} row${ids.length > 1 ? 's' : ''}`);
    } catch (e) { toast.error(e.message); load(); } finally { setBulkBusy(false); }
  };

  // ---- CSV export ----
  const exportCsv = () => {
    const cols = columns.filter((c) => c.key !== 'department_name' || true);
    const esc = (v) => { const s = v == null ? '' : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
    const head = cols.map((c) => esc(c.label)).join(',');
    const body = rows.map((r) => cols.map((c) => {
      const v = r[c.key];
      const out = c.format ? c.format(v, r) : (c.type === 'date' && v ? String(v).slice(0, 10) : v);
      return esc(out);
    }).join(',')).join('\n');
    const blob = new Blob([head + '\n' + body], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${resource}-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  const renderCell = (row, col) => {
    const isEditing = editing && editing.id === row.id && editing.key === col.key;
    if (isEditing) {
      if (col.type === 'select') {
        return (
          <select autoFocus className="w-full rounded border border-brand-300 bg-white px-1.5 py-1 text-sm outline-none"
            value={draft} onChange={(e) => setDraft(e.target.value)} onBlur={() => commit(row, col)}
            onKeyDown={(e) => { if (e.key === 'Enter') commit(row, col); if (e.key === 'Escape') setEditing(null); }}>
            <option value="">—</option>
            {col.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        );
      }
      return (
        <input autoFocus type={col.type === 'number' ? 'number' : col.type === 'date' ? 'date' : 'text'}
          list={col.suggestions ? `sug-${col.key}` : undefined}
          className="w-full rounded border border-brand-300 bg-white px-1.5 py-1 text-sm outline-none"
          value={draft ?? ''} onChange={(e) => setDraft(e.target.value)} onBlur={() => commit(row, col)}
          onKeyDown={(e) => { if (e.key === 'Enter') commit(row, col); if (e.key === 'Escape') setEditing(null); }} />
      );
    }
    const val = row[col.key];
    if (col.type === 'badge') return <span onClick={() => startEdit(row, col)} className="cursor-pointer">{val ? <StatusBadge value={val} /> : <span className="text-slate-300">—</span>}</span>;
    const display = col.format ? col.format(val, row)
      : col.type === 'date' ? (val ? new Date(String(val).slice(0, 10) + 'T00:00:00').toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) : '')
      : (val === null || val === undefined || val === '' ? '' : String(val));
    return (
      <span onClick={() => startEdit(row, col)}
        className={`block min-h-[1.25rem] truncate ${canEdit && !col.readOnly ? 'cursor-text hover:bg-brand-50/60 rounded px-1 -mx-1' : ''}`}>
        {display || <span className="text-slate-300">—</span>}
      </span>
    );
  };

  const colCount = columns.length + (canEdit ? 2 : 0);

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input ref={searchRef} className="input pl-9" placeholder={searchPlaceholder} defaultValue={search}
            onKeyDown={(e) => { if (e.key === 'Enter') { setPage(1); setSearch(e.currentTarget.value.trim()); } }}
            onBlur={(e) => { setPage(1); setSearch(e.currentTarget.value.trim()); }} />
        </div>
        {filters && (
          <select className="input w-auto" value={filterVal} onChange={(e) => { setPage(1); setFilterVal(e.target.value); }}>
            <option value="">All {filters.label}</option>
            {filters.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
        )}
        <button className="btn-secondary whitespace-nowrap" onClick={exportCsv} title="Export current rows to CSV" disabled={!rows.length}>
          <Download className="h-4 w-4" /> Export
        </button>
        {canCreate && (
          <button className="btn-primary whitespace-nowrap" onClick={() => { setAdding((a) => !a); setNewRow({}); }}>
            <Plus className="h-4 w-4" /> Add row
          </button>
        )}
      </div>

      {/* bulk action bar */}
      {canEdit && selected.size > 0 && (
        <div className="flex flex-wrap items-center gap-2 rounded-lg border border-brand-200 bg-brand-50/70 px-3 py-2 text-sm">
          <span className="flex items-center gap-1.5 font-medium text-brand-700"><Wand2 className="h-4 w-4" /> {selected.size} selected</span>
          <span className="text-slate-400">·</span>
          <span className="text-slate-500">Set</span>
          <select className="input h-8 w-auto py-0" value={bulkField} onChange={(e) => { setBulkField(e.target.value); setBulkValue(''); }}>
            <option value="">field…</option>
            {editableCols.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}
          </select>
          {bulkCol && (bulkCol.type === 'select' ? (
            <select className="input h-8 w-auto py-0" value={bulkValue} onChange={(e) => setBulkValue(e.target.value)}>
              <option value="">—</option>
              {bulkCol.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </select>
          ) : (
            <input className="input h-8 w-36 py-0" type={bulkCol.type === 'number' ? 'number' : bulkCol.type === 'date' ? 'date' : 'text'}
              list={bulkCol.suggestions ? `sug-${bulkCol.key}` : undefined} placeholder="value"
              value={bulkValue} onChange={(e) => setBulkValue(e.target.value)} />
          ))}
          <button className="btn-primary h-8 py-0" onClick={applyBulk} disabled={bulkBusy || !bulkField}>Apply</button>
          <span className="text-slate-300">|</span>
          <button className="btn-ghost h-8 py-0 text-red-600 hover:bg-red-50" onClick={bulkDelete} disabled={bulkBusy}>
            <Trash2 className="h-4 w-4" /> Delete
          </button>
          <button className="btn-ghost h-8 py-0 text-slate-500" onClick={() => setSelected(new Set())}>Clear</button>
        </div>
      )}

      {columns.filter((c) => c.suggestions).map((c) => (
        <datalist key={c.key} id={`sug-${c.key}`}>{c.suggestions.map((s) => <option key={s} value={s} />)}</datalist>
      ))}

      {loading ? <LoadingState /> : error ? <ErrorState message={error} onRetry={load} /> : (
        <div className="card overflow-x-auto p-0">
          <table className="w-full min-w-[720px] border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50/80 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
                {canEdit && (
                  <th className="w-9 px-3 py-2.5">
                    <input type="checkbox" className="h-4 w-4 cursor-pointer rounded border-slate-300" checked={allOnPage} onChange={toggleAll} />
                  </th>
                )}
                {columns.map((col) => (
                  <th key={col.key} onClick={() => toggleSort(col)}
                    className={`px-3 py-2.5 ${col.noSort ? '' : 'cursor-pointer select-none hover:text-slate-700'}`}
                    style={col.width ? { width: col.width } : undefined}>
                    {col.label}{sort.key === col.key ? (sort.dir === 'asc' ? ' ↑' : ' ↓') : ''}
                  </th>
                ))}
                {canEdit && <th className="w-10 px-2 py-2.5"></th>}
              </tr>
            </thead>
            <tbody>
              {adding && (
                <tr className="border-b border-brand-100 bg-brand-50/40">
                  {canEdit && <td className="px-3 py-1.5"></td>}
                  {columns.map((col) => (
                    <td key={col.key} className="px-2 py-1.5 align-middle">
                      {col.readOnly ? <span className="text-slate-300">—</span> : col.type === 'select' ? (
                        <select className="w-full rounded border border-slate-300 px-1.5 py-1 text-sm"
                          value={newRow[col.key] || ''} onChange={(e) => setNewRow((n) => ({ ...n, [col.key]: e.target.value }))}>
                          <option value="">—</option>
                          {col.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                        </select>
                      ) : (
                        <input type={col.type === 'number' ? 'number' : col.type === 'date' ? 'date' : 'text'}
                          list={col.suggestions ? `sug-${col.key}` : undefined}
                          className="w-full rounded border border-slate-300 px-1.5 py-1 text-sm" placeholder={col.label}
                          value={newRow[col.key] || ''} onChange={(e) => setNewRow((n) => ({ ...n, [col.key]: e.target.value }))}
                          onKeyDown={(e) => { if (e.key === 'Enter') addRow(); }} />
                      )}
                    </td>
                  ))}
                  <td className="px-1 py-1.5">
                    <div className="flex items-center gap-1">
                      <button className="rounded p-1 text-emerald-600 hover:bg-emerald-50" onClick={addRow} title="Save"><Check className="h-4 w-4" /></button>
                      <button className="rounded p-1 text-slate-400 hover:bg-slate-100" onClick={() => { setAdding(false); setNewRow({}); }} title="Cancel"><X className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              )}
              {rows.map((row) => (
                <tr key={row.id} className={`border-b border-slate-100 last:border-0 hover:bg-slate-50/60 ${selected.has(row.id) ? 'bg-brand-50/40' : ''}`}>
                  {canEdit && (
                    <td className="px-3 py-2">
                      <input type="checkbox" className="h-4 w-4 cursor-pointer rounded border-slate-300" checked={selected.has(row.id)} onChange={() => toggleOne(row.id)} />
                    </td>
                  )}
                  {columns.map((col) => (
                    <td key={col.key} className="max-w-[220px] px-3 py-2 align-middle text-slate-700">{renderCell(row, col)}</td>
                  ))}
                  {canEdit && (
                    <td className="px-2 py-2">
                      <div className="flex items-center gap-0.5">
                        {onOpenHistory && (
                          <button className="rounded p-1 text-slate-300 hover:bg-slate-100 hover:text-slate-600" onClick={() => onOpenHistory(row)} title="Change history">
                            <History className="h-4 w-4" />
                          </button>
                        )}
                        {onOpenComments && (
                          <button className="rounded p-1 text-slate-300 hover:bg-brand-50 hover:text-brand-500" onClick={() => onOpenComments(row)} title="Comments">
                            <MessageSquare className="h-4 w-4" />
                          </button>
                        )}
                        <button className="rounded p-1 text-slate-300 hover:bg-red-50 hover:text-red-500" onClick={() => del(row)} title="Delete row">
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
              {rows.length === 0 && !adding && (
                <tr><td colSpan={colCount} className="p-0"><EmptyState title="No records yet" message={canEdit ? 'Click “Add row” to enter your first record.' : 'Nothing to show.'} /></td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      <div className="flex items-center justify-between text-xs text-slate-400">
        <span>{pagination ? `${pagination.total} record${pagination.total === 1 ? '' : 's'}` : ''}</span>
        {pagination && pagination.totalPages > 1 && <Pagination pagination={pagination} onPage={setPage} />}
      </div>
    </div>
  );
}
