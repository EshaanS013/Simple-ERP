const { Server } = require('socket.io');
const config = require('../config/env');
const { resolveUserFromToken } = require('../middleware/auth');

let io = null;
// Track sessions so presence reflects unique users even with multiple tabs.
const sessionsBySocket = new Map(); // socketId -> userId

function presenceCount() {
  return new Set(sessionsBySocket.values()).size;
}

function onlineUserIds() {
  return [...new Set(sessionsBySocket.values())];
}

function broadcastPresence() {
  if (!io) return;
  io.emit('presence', { onlineUsers: presenceCount(), onlineUserIds: onlineUserIds() });
}

function initSocket(server) {
  io = new Server(server, {
    cors: {
      origin: config.ALLOWED_ORIGINS,
      methods: ['GET', 'POST'],
      credentials: true
    }
  });

  // Authenticate every socket using the same JWT as the REST API.
  io.use(async (socket, next) => {
    try {
      const token =
        (socket.handshake.auth && socket.handshake.auth.token) ||
        ((socket.handshake.headers && socket.handshake.headers.authorization) || '').replace('Bearer ', '');
      if (!token) return next(new Error('Authentication required'));
      const user = await resolveUserFromToken(token);
      if (!user) return next(new Error('Invalid session'));
      socket.data.user = { id: user.id, name: user.name, role: user.role };
      next();
    } catch (err) {
      next(new Error('Authentication failed'));
    }
  });

  io.on('connection', (socket) => {
    sessionsBySocket.set(socket.id, socket.data.user.id);
    socket.join(`user:${socket.data.user.id}`);
    socket.emit('presence', { onlineUsers: presenceCount(), onlineUserIds: onlineUserIds() });
    broadcastPresence();

    socket.on('disconnect', () => {
      sessionsBySocket.delete(socket.id);
      broadcastPresence();
    });
  });

  return io;
}

// Broadcast a domain event to all connected clients. Safe no-op before init.
function emitEvent(event, payload) {
  if (!io) return;
  io.emit(event, payload);
}

function getOnlineUsers() {
  return presenceCount();
}

function getOnlineUserIds() {
  return onlineUserIds();
}

// Emit an event to all sockets belonging to specific user id(s).
function emitToUsers(userIds, event, payload) {
  if (!io) return;
  for (const id of userIds) io.to(`user:${id}`).emit(event, payload);
}

module.exports = { initSocket, emitEvent, getOnlineUsers, getOnlineUserIds, emitToUsers };
