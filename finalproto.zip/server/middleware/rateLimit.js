const rateLimit = require('express-rate-limit');
const config = require('../config/env');

// Brute-force protection for login. Only FAILED attempts count, so normal
// sign-ins never accumulate — important in an office where many people share
// one outward IP through the reverse proxy. Generous ceiling to avoid lockouts.
const loginLimiter = rateLimit({
  windowMs: config.LOGIN_RATE_WINDOW_MS,
  max: config.LOGIN_RATE_MAX,
  skipSuccessfulRequests: true, // a correct login does not count toward the limit
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many failed login attempts from this network. Please wait a few minutes and try again.' }
});

// Generous limiter for the rest of the API. Set high because a whole office can
// share one source IP behind the proxy — this must never take the site down.
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: Number(process.env.API_RATE_MAX || 5000),
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please slow down.' }
});

module.exports = { loginLimiter, apiLimiter };
