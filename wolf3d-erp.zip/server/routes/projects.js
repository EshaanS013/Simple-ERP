const express = require('express');
const { pool } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound } = require('../middleware/errorHandler');
const { emitEvent } = require('../socket/socket');
const { recordActivity } = require('../utils/activity');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query);
  const { search, status, sort } = req.query;
  const conditions = [];
  const values = [];
  let i = 1;
  if (search) { conditions.push(`(p.project_number ILIKE $${i} OR p.project_name ILIKE $${i} OR p.remarks ILIKE $${i})`); values.push(`%${search}%`); i++; }
  if (status) { conditions.push(`p.status = $${i}`); values.push(status); i++; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const order = sort === 'deadline' ? 'ORDER BY p.deadline ASC NULLS LAST' : 'ORDER BY p.created_at DESC';

  const total = await pool.query(`SELECT COUNT(*)::int c FROM projects p ${where}`, values);
  const rows = await pool.query(
    `SELECT p.*, c.name AS client_name,
       (SELECT COUNT(*)::int FROM tasks t WHERE t.project_id = p.id AND t.status != 'completed') AS open_tasks,
       (SELECT COUNT(*)::int FROM activities a WHERE a.project_id = p.id) AS activity_count
     FROM projects p LEFT JOIN clients c ON c.id = p.client_id
     ${where} ${order} LIMIT $${i} OFFSET $${i + 1}`,
    [...values, pageSize, offset]
  );
  res.json(paginatedResponse(rows.rows, total.rows[0].c, page, pageSize));
}));

router.get('/:id', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rows, rowCount } = await pool.query(
    `SELECT p.*, c.name AS client_name, w.work_order_number, w.status AS work_order_status
     FROM projects p LEFT JOIN clients c ON c.id = p.client_id
     LEFT JOIN work_orders w ON w.id = p.work_order_id WHERE p.id = $1`,
    [req.params.id]
  );
  if (rowCount === 0) throw notFound('Project not found');
  res.json(rows[0]);
}));

router.post('/', managerOnly, validate({ body: schemas.createProject }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO projects (project_number, project_name, client_id, part_name, service_type, assigned_to, progress_percent, start_date, deadline, status, remarks, work_order_id, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) RETURNING *`,
    [b.project_number, b.project_name, b.client_id || null, b.part_name || null, b.service_type || null, b.assigned_to || [], b.progress_percent, b.start_date || null, b.deadline || null, b.status, b.remarks || null, b.work_order_id || null, req.user.id]
  );
  const p = rows[0];
  emitEvent('project_created', p);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'created a project', module: 'Projects', details: p.project_name, entityType: 'project', entityId: p.id, projectId: p.id });
  res.status(201).json(p);
}));

router.put('/:id', managerOnly, validate({ params: schemas.idParam, body: schemas.updateProject }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows, rowCount } = await pool.query(
    `UPDATE projects SET project_name=$1, client_id=$2, part_name=$3, service_type=$4, assigned_to=$5, progress_percent=$6, start_date=$7, deadline=$8, status=$9, remarks=$10, work_order_id=$11
     WHERE id=$12 RETURNING *`,
    [b.project_name, b.client_id || null, b.part_name || null, b.service_type || null, b.assigned_to || [], b.progress_percent, b.start_date || null, b.deadline || null, b.status, b.remarks || null, b.work_order_id || null, req.params.id]
  );
  if (rowCount === 0) throw notFound('Project not found');
  emitEvent('project_updated', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'updated a project', module: 'Projects', details: rows[0].project_name, entityType: 'project', entityId: rows[0].id, projectId: rows[0].id });
  res.json(rows[0]);
}));

router.delete('/:id', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rows, rowCount } = await pool.query('DELETE FROM projects WHERE id = $1 RETURNING project_name', [req.params.id]);
  if (rowCount === 0) throw notFound('Project not found');
  emitEvent('project_deleted', { id: Number(req.params.id) });
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'deleted a project', module: 'Projects', details: rows[0].project_name });
  res.json({ success: true });
}));

module.exports = router;
