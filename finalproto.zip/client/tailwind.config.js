/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'sans-serif']
      },
      colors: {
        brand: {
          50: '#ecf8fd', 100: '#cfeefb', 200: '#a3e0f7', 300: '#6bccf1',
          400: '#2fb2e7', 500: '#0399d9', 600: '#037db4', 700: '#066391',
          800: '#0b5076', 900: '#0e4361'
        },
        accent: {
          50: '#fdeaea', 100: '#fbd0d1', 200: '#f7a6a8', 300: '#f3777a',
          400: '#f14f53', 500: '#ee2e31', 600: '#d41f22', 700: '#b0181b',
          800: '#8c1719', 900: '#74181a'
        }
      },
      boxShadow: {
        card: '0 1px 2px 0 rgba(15,23,42,0.04), 0 1px 3px 0 rgba(15,23,42,0.06)',
        pop: '0 10px 30px -8px rgba(15,23,42,0.18)'
      },
      keyframes: {
        'fade-in': { '0%': { opacity: 0, transform: 'translateY(4px)' }, '100%': { opacity: 1, transform: 'translateY(0)' } },
        'scale-in': { '0%': { opacity: 0, transform: 'scale(0.97)' }, '100%': { opacity: 1, transform: 'scale(1)' } }
      },
      animation: {
        'fade-in': 'fade-in 0.2s ease-out',
        'scale-in': 'scale-in 0.15s ease-out'
      }
    }
  },
  plugins: []
};
