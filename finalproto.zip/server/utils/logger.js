// Lightweight file logger. Writes structured lines to dated files under
// LOGS_DIR, kept separate from application data so logs survive and can be
// shipped/rotated independently. Never throws — logging must not crash the app.
const fs = require('fs');
const path = require('path');

const LOGS_DIR = process.env.LOGS_DIR || path.join(__dirname, '..', 'logs');
try { fs.mkdirSync(LOGS_DIR, { recursive: true }); } catch { /* exists */ }

function write(level, event, message, meta) {
  const line = JSON.stringify({
    ts: new Date().toISOString(),
    level,
    event,
    message: message == null ? undefined : String(message),
    ...(meta && typeof meta === 'object' ? { meta } : {})
  }) + '\n';
  // Console mirror (captured by Docker logs) + dated file.
  if (level === 'error' || level === 'critical') process.stderr.write(line);
  try {
    const file = path.join(LOGS_DIR, `wolf3d-${new Date().toISOString().slice(0, 10)}.log`);
    fs.appendFile(file, line, () => {});
  } catch { /* never throw from the logger */ }
}

module.exports = {
  LOGS_DIR,
  info: (event, message, meta) => write('info', event, message, meta),
  warn: (event, message, meta) => write('warn', event, message, meta),
  error: (event, message, meta) => write('error', event, message, meta),
  critical: (event, message, meta) => write('critical', event, message, meta),
  // Convenience wrappers for the events the spec calls out.
  authFailure: (message, meta) => write('warn', 'auth_failure', message, meta),
  dbError: (message, meta) => write('error', 'db_error', message, meta),
  backup: (status, message, meta) => write(status === 'success' ? 'info' : 'error', `backup_${status}`, message, meta),
  restore: (status, message, meta) => write(status === 'success' ? 'info' : 'error', `restore_${status}`, message, meta)
};
