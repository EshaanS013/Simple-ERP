import axios from 'axios';

// Same-origin by default (served by the API/nginx), configurable for split dev.
const baseURL = import.meta.env.VITE_API_BASE_URL || '';

export const TOKEN_KEY = 'wolf3d_token';
export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => localStorage.setItem(TOKEN_KEY, t);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

const api = axios.create({ baseURL, timeout: 20000 });

// Attach bearer token to every request automatically.
api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Normalize errors and handle expired sessions globally.
api.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401 && getToken()) {
      clearToken();
      window.dispatchEvent(new CustomEvent('auth:expired'));
    }
    const message =
      error.response?.data?.error ||
      (error.code === 'ECONNABORTED' ? 'The request timed out' : null) ||
      error.message ||
      'Something went wrong';
    return Promise.reject(new Error(message));
  }
);

const unwrap = (p) => p.then((r) => r.data);

// Generic CRUD helpers ------------------------------------------------------
const list = (resource, params) => unwrap(api.get(`/api/${resource}`, { params }));
const get = (resource, id) => unwrap(api.get(`/api/${resource}/${id}`));
const create = (resource, body) => unwrap(api.post(`/api/${resource}`, body));
const update = (resource, id, body) => unwrap(api.put(`/api/${resource}/${id}`, body));
const remove = (resource, id) => unwrap(api.delete(`/api/${resource}/${id}`));

export const Api = {
  raw: api,
  // Auth
  login: (body) => unwrap(api.post('/api/auth/login', body)),
  me: () => unwrap(api.get('/api/auth/me')),
  changePassword: (body) => unwrap(api.post('/api/auth/change-password', body)),
  // Dashboard / reports / search / activity
  dashboard: () => unwrap(api.get('/api/dashboard')),
  reports: () => unwrap(api.get('/api/reports/summary')),
  search: (q) => unwrap(api.get('/api/search', { params: { q } })),
  activities: (params) => list('activities', params),
  // Lookups
  usersLookup: () => unwrap(api.get('/api/users/lookup')),
  departments: () => unwrap(api.get('/api/departments')),
  // Resources
  list, get, create, update, remove,
  // Notices / updates use wrapped { data }
  notices: () => unwrap(api.get('/api/notices')),
  createNotice: (b) => unwrap(api.post('/api/notices', b)),
  deleteNotice: (id) => unwrap(api.delete(`/api/notices/${id}`)),
  updates: () => unwrap(api.get('/api/updates')),
  departmentUpdates: (d) => unwrap(api.get(`/api/updates/${encodeURIComponent(d)}`)),
  createUpdate: (b) => unwrap(api.post('/api/updates', b))
};

export default Api;
