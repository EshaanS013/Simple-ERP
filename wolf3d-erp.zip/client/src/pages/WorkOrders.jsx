import CrudPage from '../components/CrudPage';
import { StatusBadge } from '../components/ui';
import { PROJECT_STATUS, fmtDate } from '../lib/options';

export default function WorkOrders() {
  return (
    <CrudPage
      resource="work-orders"
      title="Work Orders"
      subtitle="Intake requests from clients before they become projects."
      createLabel="New Work Order"
      refreshEvents={['work_order_created', 'work_order_updated', 'work_order_deleted']}
      lookupsNeeded={['clients']}
      statusOptions={PROJECT_STATUS}
      getRowTitle={(r) => r.work_order_number}
      defaults={{ status: 'pending', quantity: 1 }}
      columns={[
        { key: 'work_order_number', header: 'WO #', render: (r) => <span className="font-medium text-slate-900">{r.work_order_number}</span> },
        { key: 'client_name', header: 'Client', render: (r) => r.client_name || '—' },
        { key: 'service_type', header: 'Service', render: (r) => r.service_type || '—' },
        { key: 'part_name', header: 'Part', render: (r) => r.part_name || '—' },
        { key: 'quantity', header: 'Qty', render: (r) => r.quantity ?? '—' },
        { key: 'status', header: 'Status', render: (r) => <StatusBadge value={r.status} /> },
        { key: 'created_at', header: 'Created', render: (r) => fmtDate(r.created_at) }
      ]}
      buildForm={(r) => ({
        id: r.id, work_order_number: r.work_order_number, client_id: r.client_id, service_type: r.service_type,
        part_name: r.part_name, quantity: r.quantity, status: r.status, deadline: r.deadline, description: r.description
      })}
      fields={(lk) => [
        { name: 'work_order_number', label: 'Work Order Number', type: 'text', required: true, placeholder: 'WO-001' },
        { name: 'client_id', label: 'Client', type: 'select', numeric: true, options: lk.clients.map((c) => ({ value: c.id, label: c.name })) },
        { name: 'service_type', label: 'Service Type', type: 'text', placeholder: '3D Scanning, CMM…' },
        { name: 'part_name', label: 'Part Name', type: 'text' },
        { name: 'quantity', label: 'Quantity', type: 'number', min: 1 },
        { name: 'status', label: 'Status', type: 'select', required: true, options: PROJECT_STATUS },
        { name: 'deadline', label: 'Deadline', type: 'date' },
        { name: 'description', label: 'Description', type: 'textarea', full: true }
      ]}
    />
  );
}
