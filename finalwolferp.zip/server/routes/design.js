const express = require('express');
const { pool } = require('../db/pool');
const { authGuard } = require('../middleware/auth');
const { attachScope } = require('../utils/scope');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound, forbidden } = require('../middleware/errorHandler');
const { recordActivity } = require('../utils/activity');
const { emitEvent, emitToUsers } = require('../socket/socket');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard, attachScope);

// Design Daily Updates is the central project workspace. Each assignment is one
// customer project; designers log daily progress that accumulates over time.
let designDeptIdCache = null;
async function designDeptId() {
  if (designDeptIdCache) return designDeptIdCache;
  const { rows } = await pool.query("SELECT id FROM departments WHERE lower(name) = 'design' LIMIT 1");
  designDeptIdCache = rows[0]?.id || null;
  return designDeptIdCache;
}
async function ensureDesignAccess(req) {
  if (req.isManager) return true;
  const did = await designDeptId();
  return !!(did && Array.isArray(req.deptIds) && req.deptIds.includes(did));
}
function extractMentions(body, users) {
  const out = new Set(); const lower = String(body || '').toLowerCase();
  for (const u of users) {
    const h = '@' + String(u.name || '').toLowerCase().replace(/\s+/g, '');
    if (lower.includes(h) || lower.includes('@' + String(u.name || '').toLowerCase())) out.add(u.id);
  }
  return [...out];
}
// Roll the assignment's progress/status up from its latest daily update.
async function syncAssignment(assignmentId) {
  const latest = await pool.query(
    'SELECT progress_percent, status FROM design_updates WHERE assignment_id=$1 ORDER BY entry_date DESC NULLS LAST, id DESC LIMIT 1',
    [assignmentId]);
  if (latest.rowCount) {
    const { progress_percent, status } = latest.rows[0];
    const st = progress_percent >= 100 ? 'completed' : (status || 'in_progress');
    await pool.query('UPDATE design_assignments SET progress_percent=$1, status=$2, updated_at=NOW() WHERE id=$3',
      [progress_percent ?? 0, st, assignmentId]);
  }
}

const PROGRESS_FROM_STATUS = { awaiting: 0, partially_complete: 50, completed: 100 };

// ---- Daily Design Planner ----------------------------------------------
// List planner rows (one per designer/day) with project + designer info.
router.get('/planner', asyncHandler(async (req, res) => {
  if (!(await ensureDesignAccess(req))) throw forbidden('Design planner is limited to the Design department');
  const { date, designer_id, assignment_id, target_status, delivery_status, search } = req.query;
  const where = ['u.assignment_id IS NOT NULL']; const params = []; let i = 1;
  if (date) { where.push(`u.entry_date = $${i++}`); params.push(date); }
  if (designer_id) { where.push(`u.designer_id = $${i++}`); params.push(designer_id); }
  if (assignment_id) { where.push(`u.assignment_id = $${i++}`); params.push(assignment_id); }
  if (target_status) { where.push(`u.target_status = $${i++}`); params.push(target_status); }
  if (delivery_status) { where.push(`u.delivery_status = $${i++}`); params.push(delivery_status); }
  if (search) { where.push(`(u.designer_name ILIKE $${i} OR u.target ILIKE $${i} OR u.work_done ILIKE $${i} OR u.comment ILIKE $${i} OR a.part_name ILIKE $${i} OR a.work_order_number ILIKE $${i} OR a.client_name ILIKE $${i})`); params.push(`%${search}%`); i++; }
  const { rows } = await pool.query(`
    SELECT u.id, u.entry_date, u.designer_id, u.designer_name, u.assignment_id,
           u.target, u.work_done, u.comment, u.progress_percent, u.target_status, u.delivery_status,
           a.part_name, a.work_order_number, a.client_name, a.deadline
      FROM design_updates u JOIN design_assignments a ON a.id = u.assignment_id
     WHERE ${where.join(' AND ')}
     ORDER BY u.entry_date DESC, u.id DESC`, params);
  res.json({ data: rows });
}));

// Today's planner statistics for the dashboard cards.
router.get('/stats', asyncHandler(async (req, res) => {
  if (!(await ensureDesignAccess(req))) throw forbidden('No access');
  const date = req.query.date || new Date().toISOString().slice(0, 10);
  const { rows } = await pool.query(`
    SELECT u.target_status, u.progress_percent, a.deadline
      FROM design_updates u JOIN design_assignments a ON a.id = u.assignment_id
     WHERE u.assignment_id IS NOT NULL AND u.entry_date = $1`, [date]);
  const today = new Date(date);
  const stats = { date, total: rows.length, completed: 0, pending: 0, partial: 0, delayed: 0, avg_progress: 0 };
  let progressSum = 0;
  for (const r of rows) {
    if (r.target_status === 'completed') stats.completed++;
    else if (r.target_status === 'partially_complete') stats.partial++;
    else stats.pending++;
    if (r.deadline && new Date(r.deadline) < today && r.target_status !== 'completed') stats.delayed++;
    progressSum += r.progress_percent || 0;
  }
  stats.avg_progress = rows.length ? Math.round(progressSum / rows.length) : 0;
  res.json(stats);
}));

// Manager assigns work: create a planner row for a designer on a project.
router.post('/planner', validate({ body: schemas.assignPlannerRow }), asyncHandler(async (req, res) => {
  if (!req.isManager) throw forbidden('Only managers can assign work');
  const b = req.body;
  const designer = await pool.query('SELECT id, name FROM users WHERE id=$1', [b.designer_id]);
  if (designer.rowCount === 0) throw notFound('Designer not found');
  const assignment = await pool.query('SELECT id FROM design_assignments WHERE id=$1', [b.assignment_id]);
  if (assignment.rowCount === 0) throw notFound('Project not found');
  const ts = b.target_status || 'awaiting';
  const { rows } = await pool.query(
    `INSERT INTO design_updates (assignment_id, entry_date, designer_id, designer_name, target, target_status, delivery_status, progress_percent, status, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [b.assignment_id, b.entry_date, b.designer_id, designer.rows[0].name, b.target || null, ts, b.delivery_status || 'awaiting', PROGRESS_FROM_STATUS[ts], ts === 'completed' ? 'completed' : 'in_progress', req.user.id]);
  // Ensure the designer is a member of the project.
  await pool.query('INSERT INTO design_assignment_members (assignment_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [b.assignment_id, b.designer_id]);
  await syncAssignment(b.assignment_id);
  emitEvent('design_updated', { id: b.assignment_id });
  emitEvent('planner_changed', { id: rows[0].id });
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'assigned design work', module: 'Design Updates', details: designer.rows[0].name, entityType: 'design_assignment', entityId: b.assignment_id, departmentId: await designDeptId() });
  res.status(201).json(rows[0]);
}));

// Update a planner row. Assigned designer may update their own; managers any.
router.put('/planner/:id(\\d+)', validate({ body: schemas.updatePlannerRow }), asyncHandler(async (req, res) => {
  const rowId = Number(req.params.id);
  const cur = await pool.query('SELECT * FROM design_updates WHERE id=$1', [rowId]);
  if (cur.rowCount === 0) throw notFound('Planner row not found');
  const row = cur.rows[0];
  if (!req.isManager && row.designer_id !== req.user.id) throw forbidden('You can only update your own assigned work');
  const b = req.body;
  const sets = []; const vals = []; let i = 1;
  // Only managers may change the assigned target.
  if (req.isManager && 'target' in b) { sets.push(`target=$${i++}`); vals.push(b.target || null); }
  for (const k of ['work_done', 'comment']) if (k in b) { sets.push(`${k}=$${i++}`); vals.push(b[k] || null); }
  let nextStatus = row.target_status;
  if ('target_status' in b) { sets.push(`target_status=$${i++}`); vals.push(b.target_status); nextStatus = b.target_status; }
  if ('delivery_status' in b) { sets.push(`delivery_status=$${i++}`); vals.push(b.delivery_status); }
  // Progress: explicit value wins; otherwise derive from the (new) target status.
  let progress = row.progress_percent;
  if ('progress_percent' in b) progress = b.progress_percent;
  else if ('target_status' in b) progress = PROGRESS_FROM_STATUS[b.target_status];
  sets.push(`progress_percent=$${i++}`); vals.push(progress);
  sets.push(`status=$${i++}`); vals.push(nextStatus === 'completed' ? 'completed' : 'in_progress');
  vals.push(rowId);
  const { rows } = await pool.query(`UPDATE design_updates SET ${sets.join(', ')} WHERE id=$${i} RETURNING *`, vals);
  if (row.assignment_id) await syncAssignment(row.assignment_id);
  emitEvent('design_updated', { id: row.assignment_id });
  emitEvent('planner_changed', { id: rowId });
  res.json(rows[0]);
}));

// Delete a planner row (manager).
router.delete('/planner/:id(\\d+)', asyncHandler(async (req, res) => {
  if (!req.isManager) throw forbidden('Only managers can remove a planner row');
  const cur = await pool.query('SELECT assignment_id FROM design_updates WHERE id=$1', [Number(req.params.id)]);
  await pool.query('DELETE FROM design_updates WHERE id=$1', [Number(req.params.id)]);
  if (cur.rows[0]?.assignment_id) await syncAssignment(cur.rows[0].assignment_id);
  emitEvent('planner_changed', { id: Number(req.params.id) });
  res.json({ ok: true });
}));

// ---- list assignments ---------------------------------------------------
router.get('/', asyncHandler(async (req, res) => {
  if (!(await ensureDesignAccess(req))) throw forbidden('Design workspace is limited to the Design department');
  const { rows } = await pool.query(`
    SELECT a.id, a.work_order_number, a.client_name, a.part_name, a.technology, a.quantity,
           a.start_date, a.deadline, a.progress_percent, a.status, a.created_at, a.updated_at,
           (SELECT COALESCE(json_agg(u.name ORDER BY u.name),'[]')
              FROM design_assignment_members m JOIN users u ON u.id=m.user_id WHERE m.assignment_id=a.id) AS designers,
           (SELECT MAX(entry_date) FROM design_updates du WHERE du.assignment_id=a.id) AS last_update,
           (SELECT COUNT(*)::int FROM design_updates du WHERE du.assignment_id=a.id) AS update_count
      FROM design_assignments a ORDER BY a.updated_at DESC`);
  res.json({ data: rows });
}));

// ---- create assignment (manager) ---------------------------------------
router.post('/', validate({ body: schemas.createDesignAssignment }), asyncHandler(async (req, res) => {
  if (!req.isManager) throw forbidden('Only managers can create a design assignment');
  const b = req.body;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      `INSERT INTO design_assignments (work_order_number, client_name, part_name, technology, quantity, start_date, deadline, status, created_by)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
      [b.work_order_number, b.client_name, b.part_name, b.technology, b.quantity ?? null, b.start_date, b.deadline, b.status || 'not_started', req.user.id]);
    const a = rows[0];
    for (const u of (b.designer_ids || [])) await client.query('INSERT INTO design_assignment_members (assignment_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [a.id, u]);
    await client.query('COMMIT');
    emitEvent('design_created', { id: a.id, part_name: a.part_name });
    await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'created a design assignment', module: 'Design Updates', details: a.part_name, entityType: 'design_assignment', entityId: a.id, departmentId: await designDeptId() });
    res.status(201).json(a);
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
}));

// ---- assignment workspace bundle ---------------------------------------
router.get('/:id(\\d+)', asyncHandler(async (req, res) => {
  if (!(await ensureDesignAccess(req))) throw forbidden('No access');
  const id = Number(req.params.id);
  const a = await pool.query('SELECT * FROM design_assignments WHERE id=$1', [id]);
  if (a.rowCount === 0) throw notFound('Assignment not found');
  const [designers, updates, comments] = await Promise.all([
    pool.query('SELECT u.id, u.name, u.role FROM design_assignment_members m JOIN users u ON u.id=m.user_id WHERE m.assignment_id=$1 ORDER BY u.name', [id]),
    pool.query('SELECT id, entry_date, designer_name, target, work_done, comment, progress_percent, status, target_status, delivery_status, created_at FROM design_updates WHERE assignment_id=$1 ORDER BY entry_date DESC NULLS LAST, id DESC', [id]),
    pool.query('SELECT id, parent_id, body, author_name, created_at FROM design_comments WHERE assignment_id=$1 ORDER BY created_at ASC', [id])
  ]);
  const byId = new Map(); const top = [];
  comments.rows.forEach((r) => { r.replies = []; byId.set(r.id, r); });
  comments.rows.forEach((r) => { if (r.parent_id && byId.has(r.parent_id)) byId.get(r.parent_id).replies.push(r); else if (!r.parent_id) top.push(r); });
  res.json({ assignment: a.rows[0], designers: designers.rows, updates: updates.rows, comments: top });
}));

// ---- update assignment meta (manager) ----------------------------------
router.put('/:id(\\d+)', validate({ body: schemas.createDesignAssignment.partial() }), asyncHandler(async (req, res) => {
  if (!req.isManager) throw forbidden('Only managers can edit assignment details');
  const id = Number(req.params.id); const f = req.body; const sets = []; const vals = []; let i = 1;
  for (const k of ['work_order_number', 'client_name', 'part_name', 'technology', 'quantity', 'start_date', 'deadline', 'status']) {
    if (k in f) { sets.push(`${k}=$${i++}`); vals.push(f[k] === '' ? null : f[k]); }
  }
  if (f.designer_ids) {
    await pool.query('DELETE FROM design_assignment_members WHERE assignment_id=$1', [id]);
    for (const u of f.designer_ids) await pool.query('INSERT INTO design_assignment_members (assignment_id, user_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [id, u]);
  }
  if (sets.length) { vals.push(id); await pool.query(`UPDATE design_assignments SET ${sets.join(', ')}, updated_at=NOW() WHERE id=$${i}`, vals); }
  emitEvent('design_updated', { id });
  res.json((await pool.query('SELECT * FROM design_assignments WHERE id=$1', [id])).rows[0]);
}));

// ---- add a daily update (accumulates) ----------------------------------
router.post('/:id(\\d+)/updates', validate({ body: schemas.designDailyUpdate }), asyncHandler(async (req, res) => {
  if (!(await ensureDesignAccess(req))) throw forbidden('No access');
  const id = Number(req.params.id);
  const exists = await pool.query('SELECT id FROM design_assignments WHERE id=$1', [id]);
  if (exists.rowCount === 0) throw notFound('Assignment not found');
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO design_updates (assignment_id, entry_date, designer_id, designer_name, work_done, comment, progress_percent, status, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [id, b.entry_date || new Date().toISOString().slice(0, 10), req.user.id, req.user.name, b.work_done || null, b.comment || null, b.progress_percent ?? 0, b.status || 'in_progress', req.user.id]);
  await syncAssignment(id);
  emitEvent('design_updated', { id });
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'logged a design update', module: 'Design Updates', details: `${b.progress_percent}%`, entityType: 'design_assignment', entityId: id, departmentId: await designDeptId() });
  res.status(201).json(rows[0]);
}));

// ---- comments (discussion + replies + mentions + realtime) -------------
router.get('/:id(\\d+)/comments', asyncHandler(async (req, res) => {
  if (!(await ensureDesignAccess(req))) throw forbidden('No access');
  const id = Number(req.params.id);
  const { rows } = await pool.query('SELECT id, parent_id, body, author_name, created_at FROM design_comments WHERE assignment_id=$1 ORDER BY created_at ASC', [id]);
  const byId = new Map(); const top = [];
  rows.forEach((r) => { r.replies = []; byId.set(r.id, r); });
  rows.forEach((r) => { if (r.parent_id && byId.has(r.parent_id)) byId.get(r.parent_id).replies.push(r); else if (!r.parent_id) top.push(r); });
  res.json({ data: top });
}));
router.post('/:id(\\d+)/comments', validate({ body: schemas.designComment }), asyncHandler(async (req, res) => {
  if (!(await ensureDesignAccess(req))) throw forbidden('No access');
  const id = Number(req.params.id);
  const { body, parent_id } = req.body;
  if (parent_id) {
    const par = await pool.query('SELECT 1 FROM design_comments WHERE id=$1 AND assignment_id=$2 AND parent_id IS NULL', [parent_id, id]);
    if (par.rowCount === 0) throw notFound('Parent comment not found');
  }
  const { rows } = await pool.query(
    'INSERT INTO design_comments (assignment_id, parent_id, body, author_id, author_name) VALUES ($1,$2,$3,$4,$5) RETURNING id, parent_id, body, author_name, created_at',
    [id, parent_id || null, body.trim(), req.user.id, req.user.name]);
  const comment = { ...rows[0], replies: [] };
  const users = (await pool.query('SELECT id, name FROM users WHERE status=$1', ['active'])).rows;
  const mentioned = extractMentions(body, users).filter((uid) => uid !== req.user.id);
  if (mentioned.length) emitToUsers(mentioned, 'design_mention', { assignment_id: id, by: req.user.name, body: body.slice(0, 120) });
  emitEvent('design_comment', { assignment_id: id, comment });
  res.status(201).json(comment);
}));

// ---- delete assignment (manager) ---------------------------------------
router.delete('/:id(\\d+)', asyncHandler(async (req, res) => {
  if (!req.isManager) throw forbidden('Only managers can delete assignments');
  await pool.query('DELETE FROM design_assignments WHERE id=$1', [Number(req.params.id)]);
  emitEvent('design_deleted', { id: Number(req.params.id) });
  res.json({ ok: true });
}));

module.exports = router;
