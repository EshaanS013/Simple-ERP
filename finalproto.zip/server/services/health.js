// System health snapshot for the admin panel. Each metric carries a status
// (healthy | warning | critical) so the UI can render simple status cards.
const os = require('os');
const fs = require('fs');
const { pool, healthcheck } = require('../db/pool');
const { getOnlineUsers, isSocketReady } = require('../socket/socket');
const backup = require('./backup');
const pkg = require('../package.json');

function pct(used, total) { return total > 0 ? Math.round((used / total) * 100) : 0; }
function band(p, warn, crit) { return p >= crit ? 'critical' : p >= warn ? 'warning' : 'healthy'; }

async function collectHealth() {
  // Database
  let database = { status: 'critical', label: 'Unreachable' };
  let dbSize = null;
  try {
    await healthcheck();
    const r = await pool.query('SELECT pg_database_size(current_database()) AS size');
    dbSize = Number(r.rows[0].size);
    database = { status: 'healthy', label: 'Connected' };
  } catch { database = { status: 'critical', label: 'Unreachable' }; }

  // Memory (process + host)
  const mem = process.memoryUsage();
  const totalMem = os.totalmem();
  const usedMem = totalMem - os.freemem();
  const memPct = pct(usedMem, totalMem);

  // Disk usage of the backups volume (where data growth matters)
  let disk = { status: 'healthy', label: 'OK', used_pct: null };
  try {
    const s = fs.statfsSync(backup.BACKUPS_DIR);
    const total = s.blocks * s.bsize;
    const free = s.bfree * s.bsize;
    const dp = pct(total - free, total);
    disk = { status: band(dp, 80, 95), label: `${dp}% used`, used_pct: dp, total, free };
  } catch { /* statfs not available */ }

  const stats = backup.getStats();
  const last = stats.last_backup;
  // Backup considered healthy if one exists within the last ~48h.
  let backupStatus = 'warning';
  if (last) {
    const ageH = (Date.now() - new Date(last.created_at).getTime()) / 3.6e6;
    backupStatus = ageH <= 48 ? 'healthy' : 'warning';
  } else backupStatus = 'warning';

  return {
    generated_at: new Date().toISOString(),
    version: pkg.version || '1.0.0',
    server: { status: 'healthy', label: 'Running', uptime_seconds: Math.round(process.uptime()) },
    database: { ...database, size: dbSize },
    socket: { status: isSocketReady() ? 'healthy' : 'warning', label: isSocketReady() ? 'Active' : 'Initializing' },
    connected_users: getOnlineUsers(),
    memory: { status: band(memPct, 80, 92), used_pct: memPct, used: usedMem, total: totalMem, rss: mem.rss },
    disk,
    backup: { status: backupStatus, last_backup: last, count: stats.count, next_scheduled: stats.next_scheduled }
  };
}

module.exports = { collectHealth };
