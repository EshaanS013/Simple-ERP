import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Send, Users, Settings2, Factory, FolderKanban, ListChecks, CheckCircle2 } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { LoadingState, ErrorState, Modal, StatusBadge } from '../components/ui';

function StatCard({ icon: Icon, label, value, tint }) {
  return (
    <div className="card flex items-center gap-3 p-4">
      <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${tint}`}><Icon className="h-5 w-5" /></div>
      <div><p className="text-xl font-semibold text-slate-900">{value}</p><p className="text-xs text-slate-500">{label}</p></div>
    </div>
  );
}

export default function DepartmentWorkspace() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isManager } = useAuth();
  const toast = useToast();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState('');
  const [posting, setPosting] = useState(false);
  const [feed, setFeed] = useState([]);
  const [replyTo, setReplyTo] = useState(null);
  const [replyText, setReplyText] = useState('');
  const [managing, setManaging] = useState(false);
  const [allUsers, setAllUsers] = useState([]);
  const [memberIds, setMemberIds] = useState([]);
  const [savingMembers, setSavingMembers] = useState(false);

  const loadFeed = useCallback(async () => {
    try { setFeed((await Api.departmentUpdates(id)).data || []); } catch { /* not a member */ }
  }, [id]);

  const load = useCallback(async () => {
    setError(null);
    try { setData(await Api.department(id)); loadFeed(); }
    catch (e) { setError(e.message); } finally { setLoading(false); }
  }, [id, loadFeed]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const refresh = () => { load(); loadFeed(); };
    const evs = ['update_created', 'production_created', 'production_updated', 'production_deleted', 'project_created', 'design_created', 'department_updated'];
    evs.forEach((e) => socket.on(e, refresh));
    return () => evs.forEach((e) => socket.off(e, refresh));
  }, [load, loadFeed]);

  const post = async () => {
    const m = message.trim();
    if (!m) return;
    setPosting(true);
    try { await Api.postDepartmentUpdate(id, m); setMessage(''); loadFeed(); }
    catch (e) { toast.error(e.message); } finally { setPosting(false); }
  };

  const sendReply = async (parentId) => {
    const m = replyText.trim();
    if (!m) return;
    try { await Api.postDepartmentUpdate(id, m, parentId); setReplyText(''); setReplyTo(null); loadFeed(); }
    catch (e) { toast.error(e.message); }
  };

  const openManage = async () => {
    setManaging(true);
    try {
      const [users, members] = await Promise.all([Api.usersLookup(), Api.departmentMembers(id)]);
      setAllUsers(users); setMemberIds(members.data || []);
    } catch (e) { toast.error(e.message); }
  };

  const toggleMember = (uid) => setMemberIds((ids) => ids.includes(uid) ? ids.filter((x) => x !== uid) : [...ids, uid]);

  const saveMembers = async () => {
    setSavingMembers(true);
    try { await Api.setDepartmentMembers(id, memberIds); toast.success('Members updated'); setManaging(false); load(); }
    catch (e) { toast.error(e.message); } finally { setSavingMembers(false); }
  };

  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} onRetry={load} />;
  const { department, stats, members } = data;

  return (
    <section className="space-y-5">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button onClick={() => navigate('/departments')} className="btn-ghost btn-sm"><ArrowLeft className="h-4 w-4" /></button>
          <div>
            <h1 className="text-xl font-semibold text-slate-900">{department.name}</h1>
            {department.description && <p className="text-sm text-slate-500">{department.description}</p>}
          </div>
        </div>
        {isManager && <button className="btn-secondary" onClick={openManage}><Settings2 className="h-4 w-4" /> Manage members</button>}
      </div>

      {/* Mini dashboard */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard icon={Factory} label="In production" value={stats.in_production} tint="bg-blue-50 text-blue-600" />
        <StatCard icon={ListChecks} label="In quality" value={stats.in_quality} tint="bg-violet-50 text-violet-600" />
        <StatCard icon={FolderKanban} label="Ready for dispatch" value={stats.ready_dispatch} tint="bg-amber-50 text-amber-600" />
        <StatCard icon={CheckCircle2} label="Completed" value={stats.completed} tint="bg-emerald-50 text-emerald-600" />
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        {/* Feed */}
        <div className="lg:col-span-2">
          <div className="card p-4">
            <h2 className="mb-3 text-sm font-semibold text-slate-700">Department feed</h2>
            <div className="flex gap-2">
              <input className="input flex-1" placeholder="Post an update to this workspace…" value={message}
                onChange={(e) => setMessage(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && post()} />
              <button className="btn-primary" onClick={post} disabled={posting}><Send className="h-4 w-4" /></button>
            </div>
            <div className="mt-4 space-y-3">
              {feed.length === 0 ? <p className="py-6 text-center text-sm text-slate-400">No updates yet. Be the first to post.</p> :
                feed.map((u) => (
                  <div key={u.id} className="rounded-lg border border-slate-100 bg-slate-50/60 px-3 py-2">
                    <p className="text-sm text-slate-800">{u.message}</p>
                    <p className="mt-1 text-xs text-slate-400">{u.author_name || 'Someone'} · {new Date(u.created_at).toLocaleString()}</p>

                    {/* Replies */}
                    {u.replies?.length > 0 && (
                      <div className="mt-2 space-y-1.5 border-l-2 border-slate-200 pl-3">
                        {u.replies.map((r) => (
                          <div key={r.id}>
                            <p className="text-sm text-slate-700">{r.message}</p>
                            <p className="text-[11px] text-slate-400">{r.author_name || 'Someone'} · {new Date(r.created_at).toLocaleString()}</p>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Reply control */}
                    {replyTo === u.id ? (
                      <div className="mt-2 flex gap-2">
                        <input className="input h-8 flex-1 text-sm" autoFocus placeholder="Write a reply…" value={replyText}
                          onChange={(e) => setReplyText(e.target.value)}
                          onKeyDown={(e) => { if (e.key === 'Enter') sendReply(u.id); if (e.key === 'Escape') { setReplyTo(null); setReplyText(''); } }} />
                        <button className="btn-primary btn-sm" onClick={() => sendReply(u.id)}>Reply</button>
                      </div>
                    ) : (
                      <button className="mt-1.5 text-xs font-medium text-brand-600 hover:underline" onClick={() => { setReplyTo(u.id); setReplyText(''); }}>
                        Reply{u.replies?.length ? ` (${u.replies.length})` : ''}
                      </button>
                    )}
                  </div>
                ))}
            </div>
          </div>
          <div className="mt-3 flex gap-2 text-sm">
            <Link to="/production" className="btn-secondary btn-sm">Open Production</Link>
            <Link to="/design" className="btn-secondary btn-sm">Design Updates</Link>
          </div>
        </div>

        {/* Members */}
        <div className="card p-4">
          <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-700"><Users className="h-4 w-4" /> Members ({members.length})</h2>
          {members.length === 0 ? <p className="text-sm text-slate-400">No members assigned.</p> : (
            <ul className="space-y-2">
              {members.map((m) => (
                <li key={m.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">{(m.name || '?').slice(0, 2).toUpperCase()}</div>
                    <span className="text-sm text-slate-700">{m.name}</span>
                  </div>
                  {m.role === 'manager' && <StatusBadge value="active" />}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {/* Manage members (manager) */}
      <Modal open={managing} onClose={() => setManaging(false)} title={`Manage members — ${department.name}`} size="sm"
        footer={<><button className="btn-secondary" onClick={() => setManaging(false)} disabled={savingMembers}>Cancel</button><button className="btn-primary" onClick={saveMembers} disabled={savingMembers}>{savingMembers ? 'Saving…' : 'Save'}</button></>}>
        <div className="max-h-80 space-y-1 overflow-y-auto">
          {allUsers.map((u) => (
            <label key={u.id} className="flex cursor-pointer items-center gap-3 rounded-lg px-2 py-2 hover:bg-slate-50">
              <input type="checkbox" checked={memberIds.includes(u.id)} onChange={() => toggleMember(u.id)} className="h-4 w-4 rounded border-slate-300 text-brand-600" />
              <span className="text-sm text-slate-700">{u.name}</span>
              <span className="ml-auto text-xs text-slate-400">{u.role}</span>
            </label>
          ))}
        </div>
      </Modal>
    </section>
  );
}
