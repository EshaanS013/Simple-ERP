const express = require('express');
const { pool, withTransaction } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound } = require('../middleware/errorHandler');
const { recordActivity } = require('../utils/activity');
const { emitEvent } = require('../socket/socket');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

// List departments with their update counts and assigned-member counts.
router.get('/', asyncHandler(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT d.id, d.name,
      (SELECT COUNT(*)::int FROM updates u WHERE u.department = d.name) AS updates_count,
      (SELECT COUNT(*)::int FROM users us WHERE us.department_id = d.id) AS member_count
    FROM departments d
    ORDER BY d.name`);
  res.json({ data: rows });
}));

// Create a department.
router.post('/', managerOnly, validate({ body: schemas.createDepartment }), asyncHandler(async (req, res) => {
  const { rows } = await pool.query(
    'INSERT INTO departments (name) VALUES ($1) RETURNING *',
    [req.body.name]
  );
  emitEvent('department_created', rows[0]);
  await recordActivity({
    userId: req.user.id, userName: req.user.name,
    action: 'created a department', module: 'Departments',
    details: rows[0].name, entityType: 'department', entityId: rows[0].id
  });
  res.status(201).json(rows[0]);
}));

// Rename a department. Keeps department updates attached by syncing the
// (name-based) updates.department column inside one transaction.
router.put('/:id', managerOnly, validate({ params: schemas.idParam, body: schemas.createDepartment }), asyncHandler(async (req, res) => {
  const newName = req.body.name;
  const result = await withTransaction(async (client) => {
    const existing = await client.query('SELECT name FROM departments WHERE id = $1', [req.params.id]);
    if (existing.rowCount === 0) return null;
    const oldName = existing.rows[0].name;
    const updated = await client.query(
      'UPDATE departments SET name = $1 WHERE id = $2 RETURNING *',
      [newName, req.params.id]
    );
    if (oldName !== newName) {
      await client.query('UPDATE updates SET department = $1 WHERE department = $2', [newName, oldName]);
    }
    return { row: updated.rows[0], oldName };
  });
  if (!result) throw notFound('Department not found');
  emitEvent('department_updated', result.row);
  emitEvent('update_created', {}); // nudge any open department views to refresh
  await recordActivity({
    userId: req.user.id, userName: req.user.name,
    action: 'renamed a department', module: 'Departments',
    details: `${result.oldName} -> ${result.row.name}`, entityType: 'department', entityId: result.row.id
  });
  res.json(result.row);
}));

// Delete a department. Assigned users are detached automatically
// (users.department_id ON DELETE SET NULL); its update posts are removed.
router.delete('/:id', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const result = await withTransaction(async (client) => {
    const existing = await client.query('SELECT name FROM departments WHERE id = $1', [req.params.id]);
    if (existing.rowCount === 0) return null;
    const name = existing.rows[0].name;
    await client.query('DELETE FROM updates WHERE department = $1', [name]);
    await client.query('DELETE FROM departments WHERE id = $1', [req.params.id]);
    return name;
  });
  if (!result) throw notFound('Department not found');
  emitEvent('department_deleted', { id: Number(req.params.id) });
  await recordActivity({
    userId: req.user.id, userName: req.user.name,
    action: 'deleted a department', module: 'Departments',
    details: result, entityType: 'department', entityId: Number(req.params.id)
  });
  res.json({ success: true });
}));

module.exports = router;
