import CrudPage from '../components/CrudPage';
import { StatusBadge, PriorityBadge } from '../components/ui';
import { TASK_STATUS, TASK_PRIORITY, fmtDate } from '../lib/options';

export default function Tasks() {
  return (
    <CrudPage
      resource="tasks"
      title="Tasks"
      subtitle="Day-to-day work items across all projects."
      createLabel="New Task"
      refreshEvents={['task_created', 'task_updated', 'task_deleted']}
      lookupsNeeded={['projects', 'users']}
      statusOptions={TASK_STATUS}
      getRowTitle={(r) => r.task_name}
      defaults={{ status: 'awaiting', priority: 'medium' }}
      // Managers manage everything; employees may edit tasks assigned to them.
      managerOnlyMutations={false}
      canEditRow={(row, { isManager, userId }) => isManager || row.assigned_to === userId}
      columns={[
        { key: 'task_name', header: 'Task', render: (r) => <span className="font-medium text-slate-900">{r.task_name}</span> },
        { key: 'project_name', header: 'Project', render: (r) => r.project_name || '—' },
        { key: 'assignee_name', header: 'Assignee', render: (r) => r.assigned_to_name || 'Unassigned' },
        { key: 'priority', header: 'Priority', render: (r) => <PriorityBadge value={r.priority} /> },
        { key: 'status', header: 'Status', render: (r) => <StatusBadge value={r.status} /> },
        { key: 'deadline', header: 'Due', render: (r) => fmtDate(r.deadline) }
      ]}
      buildForm={(r) => ({
        id: r.id, task_name: r.task_name, project_id: r.project_id, assigned_to: r.assigned_to,
        priority: r.priority, status: r.status, deadline: r.deadline, description: r.description
      })}
      fields={(lk) => [
        { name: 'task_name', label: 'Task Name', type: 'text', required: true },
        { name: 'project_id', label: 'Project', type: 'select', numeric: true, options: lk.projects.map((p) => ({ value: p.id, label: p.project_name })) },
        { name: 'assigned_to', label: 'Assignee', type: 'select', numeric: true, options: lk.users.map((u) => ({ value: u.id, label: u.name })) },
        { name: 'priority', label: 'Priority', type: 'select', required: true, options: TASK_PRIORITY },
        { name: 'status', label: 'Status', type: 'select', required: true, options: TASK_STATUS },
        { name: 'deadline', label: 'Deadline', type: 'date' },
        { name: 'description', label: 'Description', type: 'textarea', full: true }
      ]}
    />
  );
}
