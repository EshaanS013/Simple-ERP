import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Cpu, Plus, Trash2, History as HistoryIcon, Activity } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PageHeader, LoadingState, ErrorState, EmptyState, Modal, ConfirmDialog, Field, Input } from '../components/ui';

const num = (n) => Number(n || 0).toLocaleString('en-IN');

export default function Machines() {
  const { isManager } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [machines, setMachines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [logFor, setLogFor] = useState(null);
  const [form, setForm] = useState({});
  const [addingMachine, setAddingMachine] = useState(false);
  const [machineForm, setMachineForm] = useState({});
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try { setMachines((await Api.machines()).data || []); }
    catch (e) { setError(e.message); } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const refresh = () => load();
    const evs = ['machine_created', 'machine_deleted', 'machine_usage_created', 'machine_usage_deleted'];
    evs.forEach((e) => socket.on(e, refresh));
    return () => evs.forEach((e) => socket.off(e, refresh));
  }, [load]);

  const openLog = (m) => { setLogFor(m); setForm({ usage_date: new Date().toISOString().slice(0, 10) }); };
  const submitUsage = async () => {
    if (!form.usage_date) { toast.error('Date is required'); return; }
    if (!form.material?.trim()) { toast.error('Material is required'); return; }
    if (!(Number(form.volume_cc) > 0)) { toast.error('Volume must be greater than 0'); return; }
    if (!(Number(form.hours) > 0)) { toast.error('Runtime must be greater than 0'); return; }
    setBusy(true);
    try {
      await Api.logMachineUsage({ machine_id: logFor.id, usage_date: form.usage_date, material: form.material, volume_cc: Number(form.volume_cc), hours: Number(form.hours) });
      toast.success('Usage logged'); setLogFor(null); setForm({}); load();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const addMachine = async () => {
    if (!machineForm.name?.trim() || !machineForm.technology?.trim()) { toast.error('Name and technology are required'); return; }
    setBusy(true);
    try { await Api.createMachine({ name: machineForm.name, technology: machineForm.technology }); toast.success('Machine added'); setAddingMachine(false); setMachineForm({}); load(); }
    catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const confirmDelete = async () => {
    try { await Api.deleteMachine(deleteTarget.id); toast.success('Machine deleted'); setDeleteTarget(null); load(); }
    catch (e) { toast.error(e.message); }
  };

  const groups = machines.reduce((acc, m) => { (acc[m.technology] ||= []).push(m); return acc; }, {});

  return (
    <section>
      <PageHeader title="Machine Utilization" subtitle="Digital logbook — record usage and view month-wise history per machine.">
        {isManager && <button className="btn-primary" onClick={() => { setMachineForm({}); setAddingMachine(true); }}><Plus className="h-4 w-4" /> Add machine</button>}
      </PageHeader>

      {loading ? <LoadingState /> : error ? <ErrorState message={error} onRetry={load} /> : machines.length === 0 ? (
        <div className="card"><EmptyState title="No machines yet" message={isManager ? 'Add your first machine to start logging usage.' : 'No machines have been added.'} /></div>
      ) : (
        <div className="space-y-6">
          {Object.entries(groups).map(([tech, list]) => (
            <div key={tech}>
              <h3 className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-400">{tech}</h3>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {list.map((m) => (
                  <div key={m.id} className="card flex flex-col p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-2">
                        <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-50 text-brand-600"><Cpu className="h-5 w-5" /></span>
                        <div>
                          <p className="font-semibold text-slate-900">{m.name}</p>
                          <p className="text-xs text-slate-400">{m.technology} · {num(m.usage_count)} logs</p>
                        </div>
                      </div>
                      {isManager && <button title="Delete machine" className="text-slate-300 hover:text-red-500" onClick={() => setDeleteTarget(m)}><Trash2 className="h-4 w-4" /></button>}
                    </div>
                    <div className="mt-3 grid grid-cols-2 gap-2">
                      <div className="rounded-lg bg-slate-50 px-3 py-2"><p className="text-[11px] text-slate-400">Total volume</p><p className="text-sm font-semibold text-slate-800">{num(m.total_volume_cc)} cc</p></div>
                      <div className="rounded-lg bg-slate-50 px-3 py-2"><p className="text-[11px] text-slate-400">Total runtime</p><p className="text-sm font-semibold text-slate-800">{num(m.total_runtime)} h</p></div>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <button className="btn-primary btn-sm flex-1" onClick={() => openLog(m)}><Activity className="h-4 w-4" /> Log usage</button>
                      <button className="btn-secondary btn-sm flex-1" onClick={() => navigate(`/machines/${m.id}/history`)}><HistoryIcon className="h-4 w-4" /> History</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Log usage popup */}
      <Modal open={!!logFor} onClose={() => setLogFor(null)} title={logFor ? `Log usage — ${logFor.name}` : ''}
        footer={<><button className="btn-secondary" onClick={() => setLogFor(null)} disabled={busy}>Cancel</button><button className="btn-primary" onClick={submitUsage} disabled={busy}>{busy ? 'Saving…' : 'Log'}</button></>}>
        <div className="space-y-3">
          <Field label="Date" required><Input type="date" value={form.usage_date || ''} onChange={(e) => setForm((f) => ({ ...f, usage_date: e.target.value }))} /></Field>
          <Field label="Material" required><Input value={form.material || ''} placeholder="e.g. Clear Resin" onChange={(e) => setForm((f) => ({ ...f, material: e.target.value }))} /></Field>
          <Field label="Volume (cc)" required><Input type="number" min="0" step="0.1" value={form.volume_cc || ''} onChange={(e) => setForm((f) => ({ ...f, volume_cc: e.target.value }))} /></Field>
          <Field label="Runtime (Hours)" required><Input type="number" min="0" step="0.1" value={form.hours || ''} onChange={(e) => setForm((f) => ({ ...f, hours: e.target.value }))} /></Field>
        </div>
      </Modal>

      {/* Add machine modal — name + technology only */}
      <Modal open={addingMachine} onClose={() => setAddingMachine(false)} title="Add machine"
        footer={<><button className="btn-secondary" onClick={() => setAddingMachine(false)} disabled={busy}>Cancel</button><button className="btn-primary" onClick={addMachine} disabled={busy}>{busy ? 'Adding…' : 'Add machine'}</button></>}>
        <div className="space-y-3">
          <Field label="Machine name" required><Input value={machineForm.name || ''} onChange={(e) => setMachineForm((f) => ({ ...f, name: e.target.value }))} /></Field>
          <Field label="Technology" required><Input value={machineForm.technology || ''} placeholder="SLA / DLP / FDM" onChange={(e) => setMachineForm((f) => ({ ...f, technology: e.target.value }))} /></Field>
        </div>
      </Modal>

      <ConfirmDialog open={!!deleteTarget} onClose={() => setDeleteTarget(null)} onConfirm={confirmDelete}
        title="Delete machine?" message={deleteTarget ? `This permanently deletes "${deleteTarget.name}" and all ${num(deleteTarget.usage_count)} of its usage logs.` : ''} />
    </section>
  );
}
