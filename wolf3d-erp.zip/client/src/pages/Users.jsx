import { useState } from 'react';
import { Plus, Pencil, KeyRound, Trash2 } from 'lucide-react';
import { useList } from '../hooks/useList';
import { useLookups } from '../hooks/useLookups';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Api from '../services/api';
import {
  PageHeader, SearchBar, Select, Pagination, Modal, ConfirmDialog,
  LoadingState, EmptyState, ErrorState, StatusBadge, Field, Input
} from '../components/ui';
import { ROLE } from '../lib/options';

const roleBadge = (role) => (
  <span className={`badge ${role === 'manager' ? 'bg-brand-50 text-brand-700' : 'bg-slate-100 text-slate-600'}`}>
    {role === 'manager' ? 'Manager' : 'Employee'}
  </span>
);

export default function Users() {
  const { user } = useAuth();
  const toast = useToast();
  const list = useList('users', { pageSize: 25, refreshEvents: ['user_created', 'user_updated', 'user_deleted'] });
  const lookups = useLookups(['departments']);

  const [editing, setEditing] = useState(null);
  const [resetting, setResetting] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({});
  const [resetPw, setResetPw] = useState('');

  const openCreate = () => { setForm({ name: '', username: '', password: '', role: 'employee', department_id: '' }); setEditing({}); };
  const openEdit = (u) => { setForm({ name: u.name, role: u.role, status: u.status, department_id: u.department_id || '' }); setEditing(u); };
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = async () => {
    setBusy(true);
    try {
      const deptId = form.department_id === '' ? null : Number(form.department_id);
      if (editing.id) {
        await Api.update('users', editing.id, { name: form.name.trim(), role: form.role, status: form.status, department_id: deptId });
        toast.success('User updated');
      } else {
        if (!form.name.trim() || !form.username.trim() || !form.password) { toast.error('Name, username and password are required'); setBusy(false); return; }
        await Api.create('users', { name: form.name.trim(), username: form.username.trim(), password: form.password, role: form.role, department_id: deptId });
        toast.success('User created');
      }
      setEditing(null);
      list.refetch();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const doReset = async () => {
    if (resetPw.length < 8 || !/[A-Za-z]/.test(resetPw) || !/[0-9]/.test(resetPw)) {
      toast.error('Password must be 8+ chars with a letter and a number'); return;
    }
    setBusy(true);
    try {
      await Api.raw.post(`/api/users/${resetting.id}/reset-password`, { newPassword: resetPw });
      toast.success(`Password reset for ${resetting.name}`);
      setResetting(null); setResetPw('');
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const doDelete = async () => {
    setBusy(true);
    try {
      await Api.remove('users', deleting.id);
      toast.success('User removed');
      setDeleting(null);
      list.refetch();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  return (
    <section>
      <PageHeader title="Team" subtitle="Manage user accounts, roles and access.">
        <button className="btn-primary" onClick={openCreate}><Plus className="h-4 w-4" /> New User</button>
      </PageHeader>

      <div className="card overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-slate-100 p-3 sm:flex-row sm:items-center">
          <div className="flex-1"><SearchBar value={list.search} onChange={list.onSearch} placeholder="Search team members…" /></div>
          <Select value={list.filters.role || ''} onChange={(e) => list.updateFilter('role', e.target.value)} className="sm:w-44">
            <option value="">All roles</option>
            {ROLE.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
          </Select>
        </div>

        {list.loading ? <LoadingState /> : list.error ? <ErrorState message={list.error} onRetry={list.refetch} /> : list.data.length === 0 ? (
          <EmptyState title="No users found" message={list.search ? 'Try a different search.' : 'Create your first team member.'} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-slate-100 bg-slate-50/60">
                <tr>
                  <th className="th">Name</th><th className="th">Username</th><th className="th">Role</th>
                  <th className="th">Department</th><th className="th">Status</th><th className="th text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {list.data.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/60">
                    <td className="td font-medium text-slate-900">{u.name}{u.id === user.id && <span className="ml-2 text-xs text-slate-400">(you)</span>}</td>
                    <td className="td text-slate-500">{u.username}</td>
                    <td className="td">{roleBadge(u.role)}</td>
                    <td className="td">{u.department_name || '—'}</td>
                    <td className="td"><StatusBadge value={u.status} /></td>
                    <td className="td">
                      <div className="flex items-center justify-end gap-1">
                        <button className="btn-ghost btn-sm" title="Edit" onClick={() => openEdit(u)}><Pencil className="h-4 w-4" /></button>
                        <button className="btn-ghost btn-sm" title="Reset password" onClick={() => { setResetPw(''); setResetting(u); }}><KeyRound className="h-4 w-4" /></button>
                        {u.id !== user.id && (
                          <button className="btn-ghost btn-sm text-red-500 hover:bg-red-50" title="Remove" onClick={() => setDeleting(u)}><Trash2 className="h-4 w-4" /></button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <Pagination pagination={list.pagination} onPage={list.setPage} />
          </div>
        )}
      </div>

      {/* Create / edit */}
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Edit User' : 'New User'} size="md"
        footer={<>
          <button className="btn-secondary" onClick={() => setEditing(null)} disabled={busy}>Cancel</button>
          <button className="btn-primary" onClick={save} disabled={busy}>{busy ? 'Saving…' : editing?.id ? 'Save changes' : 'Create user'}</button>
        </>}>
        {editing && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Full Name" required><Input value={form.name || ''} onChange={(e) => set('name', e.target.value)} /></Field>
            {!editing.id && <Field label="Username" required><Input value={form.username || ''} onChange={(e) => set('username', e.target.value)} /></Field>}
            {!editing.id && <Field label="Temporary Password" required><Input type="text" value={form.password || ''} onChange={(e) => set('password', e.target.value)} placeholder="Min 8 chars, letter + number" /></Field>}
            <Field label="Role"><Select value={form.role || 'employee'} onChange={(e) => set('role', e.target.value)}>{ROLE.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}</Select></Field>
            <Field label="Department"><Select value={form.department_id ?? ''} onChange={(e) => set('department_id', e.target.value)}><option value="">None</option>{lookups.departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</Select></Field>
            {editing.id && <Field label="Status"><Select value={form.status || 'active'} onChange={(e) => set('status', e.target.value)}><option value="active">Active</option><option value="inactive">Inactive</option></Select></Field>}
          </div>
        )}
      </Modal>

      {/* Reset password */}
      <Modal open={!!resetting} onClose={() => setResetting(null)} title={`Reset password — ${resetting?.name || ''}`} size="sm"
        footer={<>
          <button className="btn-secondary" onClick={() => setResetting(null)} disabled={busy}>Cancel</button>
          <button className="btn-primary" onClick={doReset} disabled={busy}>{busy ? 'Resetting…' : 'Reset password'}</button>
        </>}>
        <Field label="New temporary password" required>
          <Input type="text" value={resetPw} onChange={(e) => setResetPw(e.target.value)} placeholder="Min 8 chars, letter + number" />
        </Field>
        <p className="mt-2 text-xs text-slate-500">The user will be required to change this password at next sign-in.</p>
      </Modal>

      <ConfirmDialog open={!!deleting} busy={busy} onClose={() => setDeleting(null)} onConfirm={doDelete}
        title="Remove user?" confirmLabel="Remove"
        message={deleting ? `${deleting.name} will lose access to the system.` : ''} />
    </section>
  );
}
