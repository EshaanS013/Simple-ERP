import wolfMark from '../assets/wolf-mark.png';
import { useState, useRef } from 'react';
import { useNavigate, useLocation, Navigate } from 'react-router-dom';
import { LogIn, Loader2, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Login() {
  const { user, login, loading } = useAuth();
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const nameRef = useRef(null);
  const pwRef = useRef(null);
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from?.pathname || '/';

  if (!loading && user) return <Navigate to={from} replace />;

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    // Read straight from the inputs so browser autofill always works
    // (autofilled values don't always fire React onChange).
    const name = (nameRef.current?.value || '').trim();
    const password = pwRef.current?.value || '';
    if (!name) { setError('Please enter your full name.'); nameRef.current?.focus(); return; }
    if (!password) { setError('Please enter your password.'); pwRef.current?.focus(); return; }
    setBusy(true);
    try {
      const u = await login(name, password);
      navigate(u.must_change_password ? '/change-password' : from, { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-50 to-brand-50 px-4">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex flex-col items-center text-center">
          <img src={wolfMark} alt="WOLF3D" className="mb-3 h-16 w-16 object-contain" />
          <h1 className="text-xl font-bold tracking-tight"><span className="text-brand-500">WOLF</span><span className="text-accent-500">3D</span> <span className="text-slate-900">ERP</span></h1>
          <p className="mt-1 text-sm text-slate-500">Sign in to your workspace</p>
        </div>

        <form onSubmit={submit} className="card space-y-4 p-6">
          {error && (
            <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-700">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /><span>{error}</span>
            </div>
          )}
          <div>
            <label className="label" htmlFor="login-name">Full Name</label>
            <input id="login-name" name="name" ref={nameRef} className="input" autoFocus autoComplete="username"
              placeholder="e.g. Ramesh Kumar"
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); pwRef.current?.focus(); } }} />
          </div>
          <div>
            <label className="label" htmlFor="login-password">Password</label>
            <input id="login-password" name="password" ref={pwRef} className="input" type="password" autoComplete="current-password" placeholder="••••••••" />
          </div>
          <button type="submit" className="btn-primary w-full" disabled={busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />}
            {busy ? 'Signing in…' : 'Sign in'}
          </button>
        </form>
        <p className="mt-4 text-center text-xs text-slate-400">WOLF3D Technologies · Internal use only</p>
      </div>
    </div>
  );
}
