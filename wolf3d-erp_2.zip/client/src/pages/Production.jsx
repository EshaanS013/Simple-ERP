import { useState, useMemo } from 'react';
import { useLookups } from '../hooks/useLookups';
import { useAuth } from '../context/AuthContext';
import { PageHeader, StatusBadge } from '../components/ui';
import InlineTable from '../components/InlineTable';
import CommentsDrawer from '../components/CommentsDrawer';
import HistoryDrawer from '../components/HistoryDrawer';
import { YESNO, STEP_STATUS, QUALITY_VERDICT } from '../lib/options';

const TECH = ['SLA - ABS', 'SLA - Resin', 'DLP', 'FDM - PLA', 'FDM - ABS'];
const DISPATCH = ['Pending', 'Ready', 'Dispatched', 'Delivered'];
const PIPELINE = [
  { value: 'work_order', label: 'Work Order' }, { value: 'production', label: 'In Production' },
  { value: 'quality', label: 'In Quality' }, { value: 'dispatch', label: 'Ready for Dispatch' }, { value: 'completed', label: 'Completed' }
];

// Field ownership (must mirror the server).
const SALES = ['work_order_number', 'order_date', 'client_name', 'part_name', 'technology', 'quantity', 'finish', 'paint'];
const PRODUCTION = ['printing', 'clean_and_cure', 'sanding_and_polishing', 'paint_status'];
const QUALITY = ['xyz_dimension', 'critical_dimension', 'surface_finish', 'report_generated', 'rework_verdict', 'dispatch_status', 'dispatch_date'];
const SALES_IDENTITY = ['work_order_number', 'part_name'];

export default function Production() {
  const { user, isManager } = useAuth();
  const { departments } = useLookups(['departments']);
  const [commentRow, setCommentRow] = useState(null);
  const [historyRow, setHistoryRow] = useState(null);

  // Which field-groups can this user edit?
  const deptNames = (user?.departments || []).map((d) => String(d.name).toLowerCase());
  const canEditGroup = useMemo(() => ({
    sales: isManager || deptNames.includes('sales'),
    production: isManager || deptNames.includes('production'),
    quality: isManager || deptNames.includes('quality')
  }), [isManager, deptNames.join(',')]);
  const isSales = isManager || deptNames.includes('sales');

  const editableFields = useMemo(() => {
    const s = new Set();
    if (canEditGroup.sales) SALES.forEach((f) => s.add(f));
    if (canEditGroup.production) PRODUCTION.forEach((f) => s.add(f));
    if (canEditGroup.quality) QUALITY.forEach((f) => s.add(f));
    return s;
  }, [canEditGroup]);

  const columns = useMemo(() => {
    const all = [
      { key: 'work_order_number', label: 'Work Order', width: '120px', group: 'sales' },
      { key: 'order_date', label: 'Date', type: 'date', width: '130px', group: 'sales' },
      { key: 'client_name', label: 'Client', width: '120px', group: 'sales' },
      { key: 'part_name', label: 'Part Name', width: '160px', group: 'sales' },
      { key: 'technology', label: 'Technology', suggestions: TECH, width: '120px', group: 'sales' },
      { key: 'quantity', label: 'Qty', type: 'number', width: '70px', group: 'sales' },
      { key: 'finish', label: 'Finish', suggestions: YESNO, group: 'sales' },
      { key: 'paint', label: 'Paint', suggestions: YESNO, group: 'sales' },
      { key: 'printing', label: 'Printing', suggestions: STEP_STATUS, group: 'production' },
      { key: 'clean_and_cure', label: 'Clean & Cure', suggestions: STEP_STATUS, group: 'production' },
      { key: 'sanding_and_polishing', label: 'Sanding & Polish', suggestions: STEP_STATUS, group: 'production' },
      { key: 'paint_status', label: 'Paint Status', suggestions: STEP_STATUS, group: 'production' },
      { key: 'xyz_dimension', label: 'XYZ Dim', suggestions: QUALITY_VERDICT, group: 'quality' },
      { key: 'critical_dimension', label: 'Critical Dim', suggestions: QUALITY_VERDICT, group: 'quality' },
      { key: 'surface_finish', label: 'Surface Finish', suggestions: QUALITY_VERDICT, group: 'quality' },
      { key: 'report_generated', label: 'Report', suggestions: YESNO, group: 'quality' },
      { key: 'rework_verdict', label: 'Rework Verdict', suggestions: QUALITY_VERDICT, group: 'quality' },
      { key: 'dispatch_status', label: 'Dispatch', suggestions: DISPATCH, group: 'quality' },
      { key: 'dispatch_date', label: 'Dispatch Date', type: 'date', width: '130px', group: 'quality' }
    ];
    // Every employee sees the complete workflow; cells are read-only unless the
    // user's department owns that field (managers/admin can edit all).
    const visible = all.map((c) => ({ ...c, readOnly: !editableFields.has(c.key) }));
    // Read-only derived pipeline indicator (managers + everyone) — never manually edited.
    visible.push({ key: 'pipeline', label: 'Stage', readOnly: true, noSort: true, width: '150px',
      format: (v) => <StatusBadge value={(PIPELINE.find((p) => p.value === v)?.label) || v || '—'} /> });
    return visible;
  }, [editableFields]);

  const defaultDept = user?.department_ids?.[0] || departments.find((d) => d.name === 'Production')?.id || departments[0]?.id || null;

  return (
    <section>
      <PageHeader title="Production" subtitle={isManager ? 'Shared production workflow — everyone sees every stage; each department edits its own columns.' : 'Shared workflow — you can view every stage and edit the columns your department owns.'} />

      <InlineTable
        resource="production"
        columns={columns}
        events={['production_created', 'production_updated', 'production_deleted']}
        filters={{ key: 'stage', label: 'stages', options: PIPELINE }}
        searchPlaceholder="Search work order, client, part, technology…"
        requiredKey="part_name"
        canCreate={isSales}
        newRowDefaults={{ department_id: defaultDept }}
        onOpenComments={(row) => setCommentRow(row)}
        onOpenHistory={isManager ? (row) => setHistoryRow(row) : null}
      />

      <CommentsDrawer
        entity={commentRow ? { type: 'production', id: commentRow.id, label: `${commentRow.work_order_number || ''} ${commentRow.part_name || ''}`.trim() } : null}
        onClose={() => setCommentRow(null)}
      />
      <HistoryDrawer record={historyRow} onClose={() => setHistoryRow(null)} />
    </section>
  );
}
