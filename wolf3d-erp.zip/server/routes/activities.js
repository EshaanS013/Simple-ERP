const express = require('express');
const { pool } = require('../db/pool');
const { authGuard } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler } = require('../middleware/errorHandler');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query, 50);
  const { search } = req.query;
  const where = search ? 'WHERE a.action ILIKE $1 OR a.module ILIKE $1 OR a.details ILIKE $1' : '';
  const values = search ? [`%${search}%`] : [];
  const i = values.length + 1;
  const total = await pool.query(`SELECT COUNT(*)::int c FROM activities a ${where}`, values);
  const rows = await pool.query(
    `SELECT a.id, a.action, a.module, a.details, a.entity_type, a.entity_id, a.project_id, a.created_at, u.name AS user_name
     FROM activities a LEFT JOIN users u ON u.id = a.user_id
     ${where} ORDER BY a.created_at DESC LIMIT $${i} OFFSET $${i + 1}`,
    [...values, pageSize, offset]
  );
  res.json(paginatedResponse(rows.rows, total.rows[0].c, page, pageSize));
}));

module.exports = router;
