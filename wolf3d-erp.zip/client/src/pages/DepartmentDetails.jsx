import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, MessageSquare } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { LoadingState, ErrorState, EmptyState, Textarea } from '../components/ui';

const timeAgo = (d) => {
  const sec = Math.floor((Date.now() - new Date(d)) / 1000);
  if (sec < 60) return 'just now';
  if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  if (sec < 86400) return `${Math.floor(sec / 3600)}h ago`;
  return new Date(d).toLocaleString();
};

export default function DepartmentDetails() {
  const { name } = useParams();
  const navigate = useNavigate();
  const { isManager } = useAuth();
  const toast = useToast();
  const [updates, setUpdates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try {
      const res = await Api.departmentUpdates(name);
      setUpdates(res.data || []);
    } catch (e) { setError(e.message); } finally { setLoading(false); }
  }, [name]);

  useEffect(() => { setLoading(true); load(); }, [load]);
  useEffect(() => {
    const onCreated = (u) => { if (u.department === name) setUpdates((cur) => [u, ...cur]); };
    socket.on('update_created', onCreated);
    return () => socket.off('update_created', onCreated);
  }, [name]);

  const post = async () => {
    if (!message.trim()) return;
    setBusy(true);
    try {
      await Api.createUpdate({ department: name, message: message.trim() });
      setMessage('');
      toast.success('Update posted');
      load();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  return (
    <section>
      <button onClick={() => navigate('/departments')} className="btn-ghost btn-sm mb-3 -ml-2"><ArrowLeft className="h-4 w-4" /> Departments</button>
      <div className="mb-5">
        <h1 className="text-xl font-semibold tracking-tight text-slate-900">{name}</h1>
        <p className="mt-0.5 text-sm text-slate-500">Latest updates and announcements for this department.</p>
      </div>

      {isManager && (
        <div className="card mb-4 p-4">
          <Textarea rows={3} value={message} onChange={(e) => setMessage(e.target.value)} placeholder={`Share an update with ${name}…`} />
          <div className="mt-2 flex justify-end">
            <button className="btn-primary" onClick={post} disabled={busy || !message.trim()}><Send className="h-4 w-4" /> {busy ? 'Posting…' : 'Post Update'}</button>
          </div>
        </div>
      )}

      {loading ? <LoadingState /> : error ? <ErrorState message={error} onRetry={load} /> : updates.length === 0 ? (
        <div className="card"><EmptyState title="No updates yet" message={isManager ? 'Be the first to post an update.' : 'Nothing posted for this department yet.'} /></div>
      ) : (
        <div className="space-y-2.5">
          {updates.map((u) => (
            <div key={u.id} className="card p-4">
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand-50 text-brand-600"><MessageSquare className="h-4 w-4" /></div>
                <div className="min-w-0 flex-1">
                  <p className="whitespace-pre-wrap text-sm text-slate-700">{u.message}</p>
                  <p className="mt-1.5 text-xs text-slate-400">{u.author_name ? `${u.author_name} · ` : ''}{timeAgo(u.created_at)}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
