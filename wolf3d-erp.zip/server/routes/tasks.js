const express = require('express');
const { pool } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound, forbidden } = require('../middleware/errorHandler');
const { emitEvent } = require('../socket/socket');
const { recordActivity } = require('../utils/activity');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

const DETAIL = `
  SELECT t.*, u.name AS assigned_to_name, p.project_name
  FROM tasks t
  LEFT JOIN users u ON u.id = t.assigned_to
  LEFT JOIN projects p ON p.id = t.project_id`;

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query);
  const { search, status, assigned_to, project_id } = req.query;
  const conditions = [];
  const values = [];
  let i = 1;
  if (search) { conditions.push(`t.task_name ILIKE $${i}`); values.push(`%${search}%`); i++; }
  if (status) { conditions.push(`t.status = $${i}`); values.push(status); i++; }
  if (assigned_to) { conditions.push(`t.assigned_to = $${i}`); values.push(assigned_to); i++; }
  if (project_id) { conditions.push(`t.project_id = $${i}`); values.push(project_id); i++; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const total = await pool.query(`SELECT COUNT(*)::int c FROM tasks t ${where}`, values);
  const rows = await pool.query(
    `${DETAIL} ${where} ORDER BY t.deadline ASC NULLS LAST, t.created_at DESC LIMIT $${i} OFFSET $${i + 1}`,
    [...values, pageSize, offset]
  );
  res.json(paginatedResponse(rows.rows, total.rows[0].c, page, pageSize));
}));

router.get('/:id', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rows, rowCount } = await pool.query(`${DETAIL} WHERE t.id = $1`, [req.params.id]);
  if (rowCount === 0) throw notFound('Task not found');
  res.json(rows[0]);
}));

router.post('/', managerOnly, validate({ body: schemas.createTask }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO tasks (task_name, project_id, assigned_to, deadline, priority, status, comments, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [b.task_name, b.project_id || null, b.assigned_to || null, b.deadline || null, b.priority, b.status, b.comments || null, req.user.id]
  );
  const t = rows[0];
  emitEvent('task_created', t);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'created a task', module: 'Tasks', details: t.task_name, entityType: 'task', entityId: t.id, projectId: t.project_id });
  res.status(201).json(t);
}));

// Managers may edit any task; employees may edit only tasks assigned to them.
router.put('/:id', validate({ params: schemas.idParam, body: schemas.updateTask }), asyncHandler(async (req, res) => {
  const existing = await pool.query('SELECT assigned_to FROM tasks WHERE id = $1', [req.params.id]);
  if (existing.rowCount === 0) throw notFound('Task not found');
  if (req.user.role !== 'manager' && existing.rows[0].assigned_to !== req.user.id) {
    throw forbidden('You can only update tasks assigned to you');
  }
  const b = req.body;
  const { rows } = await pool.query(
    `UPDATE tasks SET task_name=$1, project_id=$2, assigned_to=$3, deadline=$4, priority=$5, status=$6, comments=$7
     WHERE id=$8 RETURNING *`,
    [b.task_name, b.project_id || null, b.assigned_to || null, b.deadline || null, b.priority, b.status, b.comments || null, req.params.id]
  );
  emitEvent('task_updated', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'updated a task', module: 'Tasks', details: rows[0].task_name, entityType: 'task', entityId: rows[0].id, projectId: rows[0].project_id });
  res.json(rows[0]);
}));

router.delete('/:id', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rows, rowCount } = await pool.query('DELETE FROM tasks WHERE id = $1 RETURNING task_name', [req.params.id]);
  if (rowCount === 0) throw notFound('Task not found');
  emitEvent('task_deleted', { id: Number(req.params.id) });
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'deleted a task', module: 'Tasks', details: rows[0].task_name });
  res.json({ success: true });
}));

module.exports = router;
