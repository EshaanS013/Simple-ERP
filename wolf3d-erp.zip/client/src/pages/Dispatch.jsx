import CrudPage from '../components/CrudPage';
import { StatusBadge } from '../components/ui';
import { DISPATCH_STATUS, fmtDate } from '../lib/options';

export default function Dispatch() {
  return (
    <CrudPage
      resource="dispatch"
      title="Dispatch"
      subtitle="Outbound deliveries and shipment tracking."
      createLabel="New Dispatch"
      refreshEvents={['dispatch_created', 'dispatch_updated', 'dispatch_deleted']}
      lookupsNeeded={['projects', 'clients']}
      statusOptions={DISPATCH_STATUS}
      getRowTitle={(r) => r.tracking_number || `#${r.id}`}
      defaults={{ status: 'awaiting' }}
      columns={[
        { key: 'tracking_number', header: 'Tracking #', render: (r) => <span className="font-medium text-slate-900">{r.tracking_number || '—'}</span> },
        { key: 'courier', header: 'Courier', render: (r) => r.courier || '—' },
        { key: 'project_name', header: 'Project', render: (r) => r.project_name || '—' },
        { key: 'client_name', header: 'Client', render: (r) => r.client_name || '—' },
        { key: 'status', header: 'Status', render: (r) => <StatusBadge value={r.status} /> },
        { key: 'dispatch_date', header: 'Dispatched', render: (r) => fmtDate(r.dispatch_date) }
      ]}
      buildForm={(r) => ({
        id: r.id, tracking_number: r.tracking_number, courier: r.courier, project_id: r.project_id,
        client_id: r.client_id, status: r.status, dispatch_date: r.dispatch_date, remarks: r.remarks
      })}
      fields={(lk) => [
        { name: 'tracking_number', label: 'Tracking Number', type: 'text' },
        { name: 'courier', label: 'Courier', type: 'text', placeholder: 'BlueDart, DTDC…' },
        { name: 'project_id', label: 'Project', type: 'select', numeric: true, options: lk.projects.map((p) => ({ value: p.id, label: p.project_name })) },
        { name: 'client_id', label: 'Client', type: 'select', numeric: true, options: lk.clients.map((c) => ({ value: c.id, label: c.name })) },
        { name: 'status', label: 'Status', type: 'select', required: true, options: DISPATCH_STATUS },
        { name: 'dispatch_date', label: 'Dispatch Date', type: 'date' },
        { name: 'remarks', label: 'Remarks', type: 'textarea', full: true }
      ]}
    />
  );
}
