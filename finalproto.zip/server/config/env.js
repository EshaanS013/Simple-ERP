require('dotenv').config();

const NODE_ENV = process.env.NODE_ENV || 'development';
const isProd = NODE_ENV === 'production';

function required(name, fallback) {
  const value = process.env[name];
  if (value === undefined || value === '') {
    if (fallback !== undefined) return fallback;
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return value;
}

const WEAK_SECRETS = new Set([
  'supersecretjwtkey',
  'secret',
  'changeme',
  'jwt',
  ''
]);

const JWT_SECRET = required('JWT_SECRET');

if (WEAK_SECRETS.has(JWT_SECRET) || JWT_SECRET.length < 32) {
  const message =
    'JWT_SECRET is weak or too short. Provide a random secret of at least 32 characters ' +
    '(generate with: openssl rand -base64 48).';
  if (isProd) {
    throw new Error(message);
  } else {
    console.warn(`\u26A0  ${message} (allowed in development only)`);
  }
}

// CORS / Socket origins. Comma separated list, or "*" for any (dev only).
const rawOrigins = process.env.CORS_ORIGINS || (isProd ? '' : '*');
const ALLOWED_ORIGINS =
  rawOrigins === '*'
    ? '*'
    : rawOrigins
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

const config = {
  NODE_ENV,
  isProd,
  PORT: Number(process.env.PORT || 4000),
  DATABASE_URL: required('DATABASE_URL'),
  JWT_SECRET,
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
  ALLOWED_ORIGINS,
  BCRYPT_ROUNDS: Number(process.env.BCRYPT_ROUNDS || 10),
  // First-run bootstrap admin. Password must be supplied via env; if absent a
  // random one is generated and printed once to the server log.
  ADMIN_USERNAME: process.env.ADMIN_USERNAME || 'admin',
  ADMIN_NAME: process.env.ADMIN_NAME || 'WOLF3D Administrator',
  ADMIN_PASSWORD: process.env.ADMIN_PASSWORD || null,
  LOGIN_RATE_WINDOW_MS: Number(process.env.LOGIN_RATE_WINDOW_MS || 15 * 60 * 1000),
  LOGIN_RATE_MAX: Number(process.env.LOGIN_RATE_MAX || 50)
};

module.exports = config;
