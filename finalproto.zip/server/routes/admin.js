const express = require('express');
const fs = require('fs');
const { authGuard, adminOnly } = require('../middleware/auth');
const { asyncHandler, badRequest, notFound } = require('../middleware/errorHandler');
const { recordActivity } = require('../utils/activity');
const { emitEvent } = require('../socket/socket');
const backup = require('../services/backup');
const { collectHealth } = require('../services/health');
const logger = require('../utils/logger');

const router = express.Router();
router.use(authGuard, adminOnly);

// ---- System health ----
router.get('/health', asyncHandler(async (req, res) => {
  res.json(await collectHealth());
}));

// ---- Backups: list + stats ----
router.get('/backups', asyncHandler(async (req, res) => {
  res.json({ stats: backup.getStats(), backups: backup.listBackups() });
}));

// ---- Backup now (non-blocking to users) ----
router.post('/backups', asyncHandler(async (req, res) => {
  const result = await backup.createBackup();
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'created a database backup', module: 'System', details: result.name, entityType: 'backup' });
  res.status(201).json(result);
}));

// ---- Download a backup (authenticated stream) ----
router.get('/backups/:name/download', asyncHandler(async (req, res) => {
  let file;
  try { file = backup.backupPath(req.params.name); }
  catch (e) { throw notFound(e.message); }
  res.setHeader('Content-Type', 'application/gzip');
  res.setHeader('Content-Disposition', `attachment; filename="${req.params.name}"`);
  fs.createReadStream(file).pipe(res);
}));

// ---- Restore from a backup (guarded by typed confirmation) ----
router.post('/backups/:name/restore', asyncHandler(async (req, res) => {
  if (req.body?.confirm !== 'RESTORE') throw badRequest('Type RESTORE to confirm this irreversible action');
  let result;
  try { result = await backup.restoreBackup(req.params.name); }
  catch (e) { logger.restore('failed', e.message, { name: req.params.name, by: req.user.name }); throw badRequest(e.message); }
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'restored the database from backup', module: 'System', details: req.params.name, entityType: 'backup' }).catch(() => {});
  // Tell every connected client to refresh — their data has changed underneath them.
  emitEvent('data_restored', { name: result.name, at: new Date().toISOString() });
  res.json({ success: true, name: result.name });
}));

// ---- Delete a backup ----
router.delete('/backups/:name', asyncHandler(async (req, res) => {
  try { backup.deleteBackup(req.params.name); }
  catch (e) { throw notFound(e.message); }
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'deleted a database backup', module: 'System', details: req.params.name, entityType: 'backup' }).catch(() => {});
  res.json({ success: true });
}));

// ================= SYSTEM UPDATES =================
const multer = require('multer');
const update = require('../services/update');
const uploadZip = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 500 * 1024 * 1024 }, // 500 MB ceiling for release packages
  fileFilter: (req, file, cb) => {
    if (/\.zip$/i.test(file.originalname) || file.mimetype === 'application/zip' || file.mimetype === 'application/x-zip-compressed') cb(null, true);
    else cb(badRequest('Update package must be a .zip file'));
  }
}).single('package');

// Version + status overview for the System Updates page.
router.get('/updates/info', asyncHandler(async (req, res) => {
  const info = update.getVersionInfo();
  const last = await update.lastInstalled();
  const health = await update.runHealthChecks();
  res.json({ ...info, last_installed: last, health: health.checks, status: health.ok ? (info.restart_pending ? 'restart_pending' : 'healthy') : 'degraded' });
}));

router.get('/updates/history', asyncHandler(async (req, res) => {
  res.json({ data: await update.listHistory() });
}));

// Validate a package without installing (dry run).
router.post('/updates/validate', (req, res, next) => uploadZip(req, res, (err) => err ? next(err) : next()), asyncHandler(async (req, res) => {
  if (!req.file) throw badRequest('No package uploaded');
  try { const { manifest, notes } = update.validatePackage(req.file.buffer); res.json({ valid: true, manifest, notes }); }
  catch (e) { res.status(422).json({ valid: false, error: e.message }); }
}));

// Upload + install an update package.
router.post('/updates', (req, res, next) => uploadZip(req, res, (err) => err ? next(err) : next()), asyncHandler(async (req, res) => {
  if (!req.file) throw badRequest('No package uploaded');
  const stages = [];
  let result;
  try {
    result = await update.applyUpdate(req.file.buffer, req.user.name, (stage, label) => stages.push({ stage, label }));
  } catch (e) {
    logger.error('update', `install failed: ${e.message}`, { by: req.user.name });
    await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'attempted a system update (failed)', module: 'System', details: e.message.slice(0, 120), entityType: 'update' }).catch(() => {});
    return res.status(422).json({ success: false, error: e.message, stages });
  }
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: `installed system update v${result.version}`, module: 'System', details: `from v${result.from}`, entityType: 'update' }).catch(() => {});
  emitEvent('system_updated', { version: result.version, at: new Date().toISOString() });
  res.json({ success: true, ...result, stages });
}));

module.exports = router;
