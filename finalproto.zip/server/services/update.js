// System Update manager.
//
// Update packages are ZIP files containing compiled release artifacts:
//   frontend/        built frontend assets
//   backend/         production backend
//   migrations/      optional database migrations (*.sql)
//   manifest.json    { version, build, release_date, min_compatible, files{path:sha256} }
//   release-notes.md
//
// Install flow (deterministic, with rollback): validate manifest + checksums +
// compatibility -> create & verify DB backup -> extract package to a versioned
// release dir -> apply new migrations -> health checks -> write the current-release
// pointer (activated on next container restart by the entrypoint). Any failure
// rolls back: staged files removed, copied migrations removed, and if migrations
// had begun, the database is restored from the pre-update backup.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const AdmZip = require('adm-zip');
const { pool } = require('../db/pool');
const logger = require('../utils/logger');
const backupSvc = require('./backup');
const { runMigrations } = require('../db/migrate');

const RELEASES_DIR = process.env.RELEASES_DIR || path.join(__dirname, '..', 'releases');
const MIGRATIONS_DIR = path.join(__dirname, '..', 'db', 'migrations');
const POINTER = path.join(RELEASES_DIR, 'current.json');

function ensureDirs() { fs.mkdirSync(RELEASES_DIR, { recursive: true }); }
function sha256(buf) { return crypto.createHash('sha256').update(buf).digest('hex'); }

function pkg() { try { delete require.cache[require.resolve('../package.json')]; return require('../package.json'); } catch { return {}; } }
function runningVersion() { return pkg().version || '0.0.0'; }

function semverCmp(a, b) {
  const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) > (pb[i] || 0)) return 1; if ((pa[i] || 0) < (pb[i] || 0)) return -1; }
  return 0;
}

// Validate a package buffer. Throws a descriptive error if invalid.
function validatePackage(zipBuffer) {
  let zip;
  try { zip = new AdmZip(zipBuffer); } catch { throw new Error('File is not a valid ZIP archive'); }
  const entries = zip.getEntries();
  if (!entries.length) throw new Error('Package is empty');
  const manifestEntry = entries.find((e) => e.entryName === 'manifest.json' || e.entryName.endsWith('/manifest.json'));
  if (!manifestEntry) throw new Error('Package is missing manifest.json');
  const prefix = manifestEntry.entryName.slice(0, manifestEntry.entryName.length - 'manifest.json'.length);
  let manifest;
  try { manifest = JSON.parse(zip.readAsText(manifestEntry)); } catch { throw new Error('manifest.json is not valid JSON'); }
  for (const k of ['version', 'build', 'min_compatible']) if (!manifest[k]) throw new Error(`manifest.json is missing required field "${k}"`);
  if (!/^\d+\.\d+\.\d+$/.test(manifest.version)) throw new Error(`manifest version "${manifest.version}" is not a valid semver`);

  // Integrity: every file listed in manifest.files must exist and match its sha256.
  if (manifest.files && typeof manifest.files === 'object') {
    for (const [rel, expected] of Object.entries(manifest.files)) {
      const e = zip.getEntry(prefix + rel);
      if (!e) throw new Error(`Integrity check failed: ${rel} listed in manifest but missing from package`);
      if (sha256(e.getData()) !== expected) throw new Error(`Integrity check failed: checksum mismatch for ${rel}`);
    }
  }
  // Compatibility: the running ERP must satisfy the package's minimum.
  const current = runningVersion();
  if (semverCmp(current, manifest.min_compatible) < 0) throw new Error(`This package requires ERP ${manifest.min_compatible} or newer (currently running ${current})`);
  if (semverCmp(manifest.version, current) <= 0) throw new Error(`Package version ${manifest.version} is not newer than the current version ${current}`);

  const notesEntry = entries.find((e) => e.entryName === prefix + 'release-notes.md');
  const notes = notesEntry ? zip.readAsText(notesEntry) : '';
  return { manifest, zip, prefix, notes };
}

async function runHealthChecks() {
  const checks = {};
  try { await pool.query('SELECT 1'); checks.database = true; } catch { checks.database = false; }
  try { const r = await pool.query("SELECT (to_regclass('public.users') IS NOT NULL AND to_regclass('public.production_records') IS NOT NULL) AS ok"); checks.schema = !!r.rows[0].ok; } catch { checks.schema = false; }
  try { const { isSocketReady } = require('../socket/socket'); checks.socket = !!isSocketReady(); } catch { checks.socket = false; }
  checks.backend = true; // we are executing, so the backend process is alive
  const failed = Object.entries(checks).filter(([, v]) => !v).map(([k]) => k);
  return { ok: failed.length === 0, failed, checks };
}

// Apply an update. onProgress(stageKey, label) streams progress to the caller.
async function applyUpdate(zipBuffer, installedBy, onProgress = () => {}) {
  const t0 = Date.now();
  const from = runningVersion();
  let histId = null, version = 'unknown', backupName = null, stagedDir = null;
  const copiedMigrations = [];
  try {
    onProgress('validating', 'Validating update');
    const v = validatePackage(zipBuffer);
    version = v.manifest.version;
    histId = (await pool.query(
      `INSERT INTO update_history(version, from_version, build, installed_by, result) VALUES ($1,$2,$3,$4,'in_progress') RETURNING id`,
      [version, from, String(v.manifest.build), installedBy])).rows[0].id;

    onProgress('backup', 'Creating database backup');
    const backup = await backupSvc.createBackup();
    backupName = backup.name;
    if (!backup.verified) throw new Error('Pre-update backup could not be verified');

    onProgress('installing', 'Extracting and staging release');
    ensureDirs();
    stagedDir = path.join(RELEASES_DIR, version);
    fs.rmSync(stagedDir, { recursive: true, force: true });
    fs.mkdirSync(stagedDir, { recursive: true });
    v.zip.extractAllTo(stagedDir, true);

    onProgress('migrating', 'Running database migrations');
    const pkgMig = path.join(stagedDir, v.prefix, 'migrations');
    if (fs.existsSync(pkgMig)) {
      for (const f of fs.readdirSync(pkgMig).filter((x) => x.endsWith('.sql'))) {
        const dest = path.join(MIGRATIONS_DIR, f);
        if (!fs.existsSync(dest)) { fs.copyFileSync(path.join(pkgMig, f), dest); copiedMigrations.push(dest); }
      }
    }
    await runMigrations();

    onProgress('health', 'Running health checks');
    const health = await runHealthChecks();
    if (!health.ok) throw new Error(`Health checks failed: ${health.failed.join(', ')}`);

    // Activation pointer — the entrypoint serves this release after a restart.
    fs.writeFileSync(POINTER, JSON.stringify({
      version, build: v.manifest.build, release_date: v.manifest.release_date || null,
      installed_at: new Date().toISOString(), installed_by: installedBy, path: stagedDir
    }, null, 2));

    const duration = Date.now() - t0;
    await pool.query(`UPDATE update_history SET result='success', message=$2, duration_ms=$3 WHERE id=$1`,
      [histId, `Updated ${from} → ${version}`, duration]);
    logger.info('update', `Update ${from} -> ${version} staged successfully`, { backup: backupName, duration });
    onProgress('completed', 'Update complete');
    return { ok: true, version, from, build: v.manifest.build, backup: backupName, duration_ms: duration, health: health.checks, restart_required: true };
  } catch (e) {
    onProgress('rollback', `Rolling back: ${e.message}`);
    try { if (stagedDir) fs.rmSync(stagedDir, { recursive: true, force: true }); } catch { /* ignore */ }
    for (const m of copiedMigrations) { try { fs.unlinkSync(m); } catch { /* ignore */ } }
    let restored = false;
    // If migrations had started applying, restore the DB to guarantee a consistent state.
    if (backupName && copiedMigrations.length) {
      try { await backupSvc.restoreBackup(backupName); restored = true; } catch (re) { logger.error('update', `rollback restore failed: ${re.message}`); }
    }
    if (histId) await pool.query(`UPDATE update_history SET result='rolled_back', message=$2, duration_ms=$3 WHERE id=$1`, [histId, String(e.message).slice(0, 400), Date.now() - t0]).catch(() => {});
    logger.error('update', `Update failed and rolled back: ${e.message}`, { restored });
    throw new Error(`${e.message}${restored ? ' — database was restored from the pre-update backup' : ''}`);
  }
}

function getVersionInfo() {
  const p = pkg();
  let pointer = null;
  try { pointer = JSON.parse(fs.readFileSync(POINTER, 'utf8')); } catch { /* none yet */ }
  const restartPending = !!(pointer && semverCmp(pointer.version, p.version) > 0);
  return {
    current_version: p.version || '0.0.0',
    build: p.build || null,
    release_date: p.releaseDate || null,
    staged: restartPending ? { version: pointer.version, build: pointer.build, installed_at: pointer.installed_at } : null,
    restart_pending: restartPending
  };
}

async function listHistory() {
  const { rows } = await pool.query(
    `SELECT id, version, from_version, build, installed_by, result, message, duration_ms, created_at
       FROM update_history ORDER BY created_at DESC LIMIT 50`);
  return rows;
}

async function lastInstalled() {
  const { rows } = await pool.query(`SELECT version, created_at FROM update_history WHERE result='success' ORDER BY created_at DESC LIMIT 1`);
  return rows[0] || null;
}

module.exports = { validatePackage, applyUpdate, runHealthChecks, getVersionInfo, listHistory, lastInstalled, RELEASES_DIR };
