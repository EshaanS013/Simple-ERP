import { useState, useMemo, useRef, useCallback } from 'react';
import { Upload, X } from 'lucide-react';
import { useLookups } from '../hooks/useLookups';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Api from '../services/api';
import { PageHeader, StatusBadge } from '../components/ui';
import InlineTable from '../components/InlineTable';
import CommentsDrawer from '../components/CommentsDrawer';
import HistoryDrawer from '../components/HistoryDrawer';
import ImageViewer from '../components/ImageViewer';
import { YESNO, STEP_STATUS, QUALITY_VERDICT } from '../lib/options';

const TECH = ['SLA - ABS', 'SLA - Resin', 'DLP', 'FDM - PLA', 'FDM - ABS'];
const DISPATCH = ['Pending', 'Ready', 'Dispatched', 'Delivered'];

// Part-image cell: larger aspect-correct thumbnail + upload/replace/remove.
function PartImageCell({ value, rowId, canEdit, onUpload, onRemove, onView }) {
  const inputRef = useRef();
  const src = value ? `/uploads/${value}` : null;
  return (
    <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
      {src
        ? <button type="button" title="Click to enlarge" onClick={() => onView(src)} className="block h-12 w-16 overflow-hidden rounded border border-slate-200 bg-slate-50 hover:border-brand-300">
            <img data-part-image={src} src={src} alt="part" className="h-full w-full object-contain" />
          </button>
        : <span className="text-xs text-slate-300">—</span>}
      {canEdit && (
        <div className="flex flex-col gap-0.5">
          <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onUpload(rowId, f); e.target.value = ''; }} />
          <button className="text-slate-400 hover:text-brand-600" title={src ? 'Replace image' : 'Upload image'} onClick={() => inputRef.current?.click()}><Upload className="h-3.5 w-3.5" /></button>
          {src && <button className="text-slate-400 hover:text-red-500" title="Remove image" onClick={() => onRemove(rowId)}><X className="h-3.5 w-3.5" /></button>}
        </div>
      )}
    </div>
  );
}

const PIPELINE = [
  { value: 'work_order', label: 'Work Order' }, { value: 'production', label: 'In Production' },
  { value: 'quality', label: 'In Quality' }, { value: 'dispatch', label: 'Ready for Dispatch' }, { value: 'completed', label: 'Completed' }
];

// Field ownership (must mirror the server).
const SALES = ['work_order_number', 'order_date', 'client_name', 'part_name', 'technology', 'quantity', 'finish', 'paint'];
const PRODUCTION = ['printing', 'clean_and_cure', 'sanding_and_polishing', 'paint_status'];
const QUALITY = ['xyz_dimension', 'critical_dimension', 'surface_finish', 'report_generated', 'rework_verdict', 'dispatch_status', 'dispatch_date'];
const ACCOUNTS = ['delivery_challan', 'invoice_no'];
const SALES_IDENTITY = ['work_order_number', 'part_name'];

export default function Production() {
  const { user, isManager } = useAuth();
  const { departments } = useLookups(['departments']);
  const toast = useToast();
  const [commentRow, setCommentRow] = useState(null);
  const [historyRow, setHistoryRow] = useState(null);
  const [viewer, setViewer] = useState(null); // { images: string[], index: number }

  // Open the image viewer; gather every visible part-image so prev/next works.
  const openViewer = useCallback((src) => {
    const imgs = [...document.querySelectorAll('img[data-part-image]')].map((el) => el.getAttribute('data-part-image'));
    const list = imgs.length ? imgs : [src];
    setViewer({ images: list, index: Math.max(0, list.indexOf(src)) });
  }, []);

  // Which field-groups can this user edit?
  const deptNames = (user?.departments || []).map((d) => String(d.name).toLowerCase());
  const canEditGroup = useMemo(() => ({
    sales: isManager || deptNames.includes('sales'),
    production: isManager || deptNames.includes('production'),
    quality: isManager || deptNames.includes('quality'),
    accounts: isManager || deptNames.includes('accounts')
  }), [isManager, deptNames.join(',')]);
  const isSales = isManager || deptNames.includes('sales');

  const editableFields = useMemo(() => {
    const s = new Set();
    if (canEditGroup.sales) SALES.forEach((f) => s.add(f));
    if (canEditGroup.production) PRODUCTION.forEach((f) => s.add(f));
    if (canEditGroup.quality) QUALITY.forEach((f) => s.add(f));
    if (canEditGroup.accounts) ACCOUNTS.forEach((f) => s.add(f));
    return s;
  }, [canEditGroup]);

  // Part image is a Sales/BDE input. Upload emits production_updated, which the
  // table already listens for, so the new thumbnail appears automatically.
  const uploadImage = useCallback(async (rowId, file) => {
    if (file.size > 5 * 1024 * 1024) { toast.error('Image is too large (max 5MB)'); return; }
    try { await Api.uploadProductionImage(rowId, file); toast.success('Part image updated'); }
    catch (e) { toast.error(e.message); }
  }, [toast]);
  const removeImage = useCallback(async (rowId) => {
    try { await Api.deleteProductionImage(rowId); toast.success('Part image removed'); }
    catch (e) { toast.error(e.message); }
  }, [toast]);

  const columns = useMemo(() => {
    const all = [
      { key: 'work_order_number', label: 'Work Order', width: '150px', minWidth: '150px', group: 'sales' },
      { key: 'order_date', label: 'Date', type: 'date', width: '150px', minWidth: '150px', group: 'sales' },
      { key: 'client_name', label: 'Client', width: '160px', minWidth: '150px', group: 'sales' },
      { key: 'part_name', label: 'Part Name', width: '200px', minWidth: '180px', group: 'sales' },
      { key: 'part_image', label: 'Part Image', width: '130px', minWidth: '130px', group: 'sales', readOnly: true, noSort: true,
        format: (v, row) => <PartImageCell value={v} rowId={row.id} canEdit={isSales} onUpload={uploadImage} onRemove={removeImage} onView={openViewer} /> },
      { key: 'technology', label: 'Technology', suggestions: TECH, width: '150px', minWidth: '140px', group: 'sales' },
      { key: 'quantity', label: 'Qty', type: 'number', width: '90px', minWidth: '80px', group: 'sales' },
      { key: 'finish', label: 'Finish', suggestions: YESNO, minWidth: '110px', group: 'sales' },
      { key: 'paint', label: 'Paint', suggestions: YESNO, minWidth: '110px', group: 'sales' },
      { key: 'printing', label: 'Printing', suggestions: STEP_STATUS, minWidth: '140px', group: 'production' },
      { key: 'clean_and_cure', label: 'Clean & Cure', suggestions: STEP_STATUS, minWidth: '150px', group: 'production' },
      { key: 'sanding_and_polishing', label: 'Sanding & Polish', suggestions: STEP_STATUS, minWidth: '160px', group: 'production' },
      { key: 'paint_status', label: 'Paint Status', suggestions: STEP_STATUS, minWidth: '140px', group: 'production' },
      { key: 'xyz_dimension', label: 'XYZ Dim', suggestions: QUALITY_VERDICT, minWidth: '130px', group: 'quality' },
      { key: 'critical_dimension', label: 'Critical Dim', suggestions: QUALITY_VERDICT, minWidth: '140px', group: 'quality' },
      { key: 'surface_finish', label: 'Surface Finish', suggestions: QUALITY_VERDICT, minWidth: '150px', group: 'quality' },
      { key: 'report_generated', label: 'Report', suggestions: YESNO, minWidth: '120px', group: 'quality' },
      { key: 'rework_verdict', label: 'Rework Verdict', suggestions: QUALITY_VERDICT, minWidth: '150px', group: 'quality' },
      { key: 'dispatch_status', label: 'Dispatch', suggestions: DISPATCH, minWidth: '140px', group: 'quality' },
      { key: 'dispatch_date', label: 'Dispatch Date', type: 'date', width: '150px', minWidth: '150px', group: 'quality' },
      { key: 'delivery_challan', label: 'Delivery Challan', width: '160px', minWidth: '150px', group: 'accounts' },
      { key: 'invoice_no', label: 'Invoice No.', width: '130px', group: 'accounts' }
    ];
    // Every employee sees the complete workflow; cells are read-only unless the
    // user's department owns that field (managers/admin can edit all).
    const visible = all.map((c) => ({ ...c, readOnly: !editableFields.has(c.key) }));
    // Read-only derived pipeline indicator (managers + everyone) — never manually edited.
    visible.push({ key: 'pipeline', label: 'Stage', readOnly: true, noSort: true, width: '150px',
      format: (v) => <StatusBadge value={(PIPELINE.find((p) => p.value === v)?.label) || v || '—'} /> });
    return visible;
  }, [editableFields, isSales, uploadImage, removeImage, openViewer]);

  const defaultDept = user?.department_ids?.[0] || departments.find((d) => d.name === 'Production')?.id || departments[0]?.id || null;

  return (
    <section>
      <PageHeader title="Production" subtitle={isManager ? 'Shared production workflow — everyone sees every stage; each department edits its own columns.' : 'Shared workflow — you can view every stage and edit the columns your department owns.'} />

      <InlineTable
        resource="production"
        columns={columns}
        events={['production_created', 'production_updated', 'production_deleted']}
        filters={{ key: 'stage', label: 'stages', options: PIPELINE }}
        searchPlaceholder="Search work order, client, part, technology…"
        requiredKey="part_name"
        canCreate={isSales}
        newRowDefaults={{ department_id: defaultDept }}
        onOpenComments={(row) => setCommentRow(row)}
        onOpenHistory={isManager ? (row) => setHistoryRow(row) : null}
      />

      <CommentsDrawer
        entity={commentRow ? { type: 'production', id: commentRow.id, label: `${commentRow.work_order_number || ''} ${commentRow.part_name || ''}`.trim() } : null}
        onClose={() => setCommentRow(null)}
      />
      <HistoryDrawer record={historyRow} onClose={() => setHistoryRow(null)} />
      {viewer && <ImageViewer images={viewer.images} index={viewer.index} onClose={() => setViewer(null)} />}
    </section>
  );
}
