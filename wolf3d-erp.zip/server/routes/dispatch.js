const express = require('express');
const { pool } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound } = require('../middleware/errorHandler');
const { emitEvent } = require('../socket/socket');
const { recordActivity } = require('../utils/activity');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

const DETAIL = `
  SELECT d.*, p.project_name, c.name AS client_name
  FROM dispatch_records d
  LEFT JOIN projects p ON p.id = d.project_id
  LEFT JOIN clients c ON c.id = d.client_id`;

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query);
  const { search, status } = req.query;
  const conditions = [];
  const values = [];
  let i = 1;
  if (search) { conditions.push(`(d.tracking_number ILIKE $${i} OR d.courier ILIKE $${i})`); values.push(`%${search}%`); i++; }
  if (status) { conditions.push(`d.status = $${i}`); values.push(status); i++; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const total = await pool.query(`SELECT COUNT(*)::int c FROM dispatch_records d ${where}`, values);
  const rows = await pool.query(`${DETAIL} ${where} ORDER BY d.dispatch_date DESC NULLS LAST, d.created_at DESC LIMIT $${i} OFFSET $${i + 1}`, [...values, pageSize, offset]);
  res.json(paginatedResponse(rows.rows, total.rows[0].c, page, pageSize));
}));

router.post('/', managerOnly, validate({ body: schemas.createDispatch }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO dispatch_records (project_id, client_id, submission_date, dispatch_date, tracking_number, courier, status, remarks, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *`,
    [b.project_id || null, b.client_id || null, b.submission_date || null, b.dispatch_date || null, b.tracking_number || null, b.courier || null, b.status, b.remarks || null, req.user.id]
  );
  emitEvent('dispatch_created', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'created a dispatch record', module: 'Dispatch', details: rows[0].tracking_number || `#${rows[0].id}`, entityType: 'dispatch', entityId: rows[0].id, projectId: rows[0].project_id });
  res.status(201).json(rows[0]);
}));

router.put('/:id', managerOnly, validate({ params: schemas.idParam, body: schemas.updateDispatch }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows, rowCount } = await pool.query(
    `UPDATE dispatch_records SET project_id=$1, client_id=$2, submission_date=$3, dispatch_date=$4, tracking_number=$5, courier=$6, status=$7, remarks=$8
     WHERE id=$9 RETURNING *`,
    [b.project_id || null, b.client_id || null, b.submission_date || null, b.dispatch_date || null, b.tracking_number || null, b.courier || null, b.status, b.remarks || null, req.params.id]
  );
  if (rowCount === 0) throw notFound('Dispatch record not found');
  emitEvent('dispatch_updated', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'updated a dispatch record', module: 'Dispatch', details: rows[0].tracking_number || `#${rows[0].id}`, entityType: 'dispatch', entityId: rows[0].id, projectId: rows[0].project_id });
  res.json(rows[0]);
}));

router.delete('/:id', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rowCount } = await pool.query('DELETE FROM dispatch_records WHERE id = $1', [req.params.id]);
  if (rowCount === 0) throw notFound('Dispatch record not found');
  emitEvent('dispatch_deleted', { id: Number(req.params.id) });
  res.json({ success: true });
}));

module.exports = router;
