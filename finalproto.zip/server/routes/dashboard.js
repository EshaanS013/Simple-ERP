const express = require('express');
const { pool } = require('../db/pool');
const { authGuard } = require('../middleware/auth');
const { attachScope, departmentFilter } = require('../utils/scope');
const { asyncHandler } = require('../middleware/errorHandler');
const { getOnlineUsers } = require('../socket/socket');

const router = express.Router();
router.use(authGuard, attachScope);

router.get('/', asyncHandler(async (req, res) => {
  const { DERIVED_STAGE } = require('../utils/production');
  const PIPE = DERIVED_STAGE.replace(/\n/g, ' ');

  // Department status (scoped to the user's departments for employees).
  const ds = departmentFilter(req, 'd.id', 1);
  const dWhere = ds.clause ? `WHERE ${ds.clause}` : '';
  const departments = await pool.query(`
    SELECT d.id, d.name,
      (SELECT COUNT(*)::int FROM production_records pr WHERE pr.department_id=d.id) AS active_production,
      (SELECT COUNT(*)::int FROM user_departments ud WHERE ud.department_id=d.id) AS members
    FROM departments d ${dWhere} ORDER BY d.name`, ds.params);

  // Recent activity (scoped).
  const aWhere = []; const aParams = []; let ai = 1;
  if (!req.isManager) {
    const ids = req.deptIds || [];
    if (ids.length) { aWhere.push(`(a.department_id = ANY($${ai}::int[]) OR a.user_id = $${ai + 1})`); aParams.push(ids, req.user.id); ai += 2; }
    else { aWhere.push(`a.user_id = $${ai++}`); aParams.push(req.user.id); }
  }
  const aWhereSql = aWhere.length ? `WHERE ${aWhere.join(' AND ')}` : '';
  const recent = await pool.query(
    `SELECT a.id, a.user_name, a.action, a.module, a.details, a.created_at, a.department_id
       FROM activities a ${aWhereSql} ORDER BY a.created_at DESC LIMIT 12`, aParams);

  const notices = await pool.query("SELECT id, title, urgent, pinned, created_at FROM notices ORDER BY pinned DESC, created_at DESC LIMIT 5");
  const online = getOnlineUsers ? getOnlineUsers().length : 0;

  // ---- Employees get a limited, personal dashboard (no company-wide metrics) ----
  if (!req.isManager) {
    const myUpdates = await pool.query(
      `SELECT id, project_name, work_done, progress_percent, status, entry_date
         FROM design_updates WHERE designer_id = $1 OR lower(designer_name) = lower($2)
         ORDER BY entry_date DESC NULLS LAST, id DESC LIMIT 6`, [req.user.id, req.user.name]);
    const assigned = (departments.rows || []).reduce((s, d) => s + (d.active_production || 0), 0);
    return res.json({
      scope: 'employee',
      myDepartments: departments.rows,
      myUpdates: myUpdates.rows,
      myAssignedWork: { active_production: assigned },
      recentActivities: recent.rows,
      recentNotices: notices.rows,
      onlineUsers: online
    });
  }

  // ---- Managers / admins get the full operational dashboard ----
  const ps = departmentFilter(req, 'department_id', 1);
  const pWhere = ps.clause ? `WHERE ${ps.clause}` : '';
  const production = await pool.query(`
    SELECT
      COUNT(*) FILTER (WHERE pipe='production')::int AS in_production,
      COUNT(*) FILTER (WHERE pipe='quality')::int AS in_quality,
      COUNT(*) FILTER (WHERE pipe='dispatch')::int AS ready_for_dispatch,
      COUNT(*) FILTER (WHERE pipe='completed')::int AS completed,
      COUNT(*) FILTER (WHERE pipe='quality' AND (report_generated IS NULL OR report_generated=''))::int AS pending_reports,
      COUNT(*) FILTER (WHERE pipe='dispatch' AND (dispatch_status IS NULL OR dispatch_status='' OR dispatch_status ILIKE 'pending%'))::int AS pending_dispatch,
      COUNT(*)::int AS total
    FROM (SELECT *, (${PIPE}) AS pipe FROM production_records) q ${pWhere}`, ps.params);
  const stageBreak = await pool.query(`SELECT pipe AS status, COUNT(*)::int AS count FROM (SELECT *, (${PIPE}) AS pipe FROM production_records) q ${pWhere} GROUP BY pipe ORDER BY pipe`, ps.params);
  const payments = await pool.query(`
    SELECT COUNT(*) FILTER (WHERE payment_status IN ('pending','overdue','partial'))::int AS outstanding_count,
           COALESCE(SUM(amount) FILTER (WHERE payment_status IN ('pending','overdue','partial')),0) AS outstanding_amount
    FROM payments`);

  res.json({
    scope: 'full',
    production: production.rows[0],
    payments: payments.rows[0],
    stageBreakdown: stageBreak.rows,
    departments: departments.rows,
    recentActivities: recent.rows,
    recentNotices: notices.rows,
    onlineUsers: online
  });
}));

module.exports = router;
