import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Loader2 } from 'lucide-react';
import Api from '../services/api';

export default function GlobalSearch() {
  const [q, setQ] = useState('');
  const [groups, setGroups] = useState([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const boxRef = useRef();
  const navigate = useNavigate();

  useEffect(() => {
    const onClick = (e) => { if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  useEffect(() => {
    if (!q.trim()) { setGroups([]); return; }
    setLoading(true);
    const t = setTimeout(async () => {
      try {
        const res = await Api.search(q.trim());
        setGroups(res.results || []);
        setOpen(true);
      } catch { /* ignore */ } finally { setLoading(false); }
    }, 250);
    return () => clearTimeout(t);
  }, [q]);

  const go = (route) => { setOpen(false); setQ(''); navigate(route); };

  return (
    <div ref={boxRef} className="relative w-full max-w-md">
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
      <input
        value={q}
        onChange={(e) => setQ(e.target.value)}
        onFocus={() => q && setOpen(true)}
        placeholder="Search projects, work orders, clients…"
        className="input pl-9 pr-8"
      />
      {loading && <Loader2 className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 animate-spin text-slate-400" />}
      {open && groups.length > 0 && (
        <div className="absolute z-40 mt-2 max-h-96 w-full overflow-y-auto card animate-fade-in p-1.5">
          {groups.map((g) => (
            <div key={g.type} className="mb-1">
              <p className="px-2 py-1 text-[11px] font-semibold uppercase tracking-wide text-slate-400">{g.type}</p>
              {g.items.map((item) => (
                <button key={`${g.type}-${item.id}`} onClick={() => go(g.route)}
                  className="flex w-full items-center justify-between gap-3 rounded-md px-2 py-1.5 text-left text-sm hover:bg-slate-50">
                  <span className="truncate font-medium text-slate-700">{item.label}</span>
                  {item.detail != null && item.detail !== '' && (
                    <span className="shrink-0 truncate text-xs text-slate-400">{String(item.detail)}</span>
                  )}
                </button>
              ))}
            </div>
          ))}
        </div>
      )}
      {open && q.trim() && !loading && groups.length === 0 && (
        <div className="absolute z-40 mt-2 w-full card animate-fade-in px-3 py-4 text-center text-sm text-slate-500">
          No results for “{q}”
        </div>
      )}
    </div>
  );
}
