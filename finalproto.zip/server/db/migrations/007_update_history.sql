-- 007_update_history.sql — records every system update attempt.
CREATE TABLE IF NOT EXISTS update_history (
  id           SERIAL PRIMARY KEY,
  version      TEXT NOT NULL,
  from_version TEXT,
  build        TEXT,
  installed_by TEXT,
  result       TEXT NOT NULL DEFAULT 'in_progress',   -- in_progress | success | failed | rolled_back
  message      TEXT,
  duration_ms  INTEGER,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_update_history_created ON update_history(created_at DESC);
