import { useState } from 'react';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useList } from '../hooks/useList';
import { useLookups } from '../hooks/useLookups';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Api from '../services/api';
import ResourceForm from './ResourceForm';
import {
  PageHeader, SearchBar, Select, Pagination, Modal, ConfirmDialog,
  LoadingState, EmptyState, ErrorState
} from './ui';

// Generic list+CRUD screen.
// props: resource, title, subtitle, columns, fields(lookups)->[], buildForm(row), defaults,
//        statusOptions, refreshEvents, lookupsNeeded, createLabel, canMutate(default managerOnly),
//        searchPlaceholder, getRowTitle
export default function CrudPage(cfg) {
  const {
    resource, title, subtitle, columns, fields, defaults = {}, statusOptions,
    refreshEvents = [], lookupsNeeded = [], createLabel = 'New', searchPlaceholder,
    pageSize = 25, getRowTitle = (r) => r.id, managerOnlyMutations = true,
    canEditRow
  } = cfg;

  const { isManager, user } = useAuth();
  const toast = useToast();
  const lookups = useLookups(lookupsNeeded);
  const list = useList(resource, { pageSize, refreshEvents });

  const [editing, setEditing] = useState(null); // null=closed, {}=create, row=edit
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);

  const canCreate = !managerOnlyMutations || isManager;
  const fieldDefs = fields ? fields(lookups) : [];

  const save = async (payload) => {
    setBusy(true);
    try {
      if (editing.id) {
        await Api.update(resource, editing.id, payload);
        toast.success(`${title.replace(/s$/, '')} updated`);
      } else {
        await Api.create(resource, payload);
        toast.success(`${title.replace(/s$/, '')} created`);
      }
      setEditing(null);
      list.refetch();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  };

  const confirmDelete = async () => {
    setBusy(true);
    try {
      await Api.remove(resource, deleting.id);
      toast.success(`${title.replace(/s$/, '')} deleted`);
      setDeleting(null);
      list.refetch();
    } catch (e) {
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  };

  const rowEditable = (row) => (canEditRow ? canEditRow(row, { isManager, userId: user?.id }) : isManager);
  const showActions = list.data.some(rowEditable) || isManager;

  return (
    <section>
      <PageHeader title={title} subtitle={subtitle}>
        {canCreate && (
          <button className="btn-primary" onClick={() => setEditing({ ...defaults })}>
            <Plus className="h-4 w-4" /> {createLabel}
          </button>
        )}
      </PageHeader>

      <div className="card overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-slate-100 p-3 sm:flex-row sm:items-center">
          <div className="flex-1"><SearchBar value={list.search} onChange={list.onSearch} placeholder={searchPlaceholder || `Search ${title.toLowerCase()}…`} /></div>
          {statusOptions && (
            <Select value={list.filters.status || ''} onChange={(e) => list.updateFilter('status', e.target.value)} className="sm:w-48">
              <option value="">All statuses</option>
              {statusOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
            </Select>
          )}
        </div>

        {list.loading ? (
          <LoadingState />
        ) : list.error ? (
          <ErrorState message={list.error} onRetry={list.refetch} />
        ) : list.data.length === 0 ? (
          <EmptyState
            title={`No ${title.toLowerCase()} found`}
            message={list.search ? 'Try a different search term.' : canCreate ? `Get started by creating one.` : 'Nothing to show yet.'}
            action={canCreate && !list.search ? <button className="btn-primary" onClick={() => setEditing({ ...defaults })}><Plus className="h-4 w-4" /> {createLabel}</button> : null}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-slate-100 bg-slate-50/60">
                <tr>
                  {columns.map((c) => <th key={c.key} className="th">{c.header}</th>)}
                  {showActions && <th className="th text-right">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {list.data.map((row) => (
                  <tr key={row.id} className="hover:bg-slate-50/60">
                    {columns.map((c) => <td key={c.key} className="td">{c.render ? c.render(row) : (row[c.key] ?? '—')}</td>)}
                    {showActions && (
                      <td className="td">
                        <div className="flex items-center justify-end gap-1">
                          {fieldDefs.length > 0 && rowEditable(row) && (
                            <button className="btn-ghost btn-sm" title="Edit" onClick={() => setEditing(cfg.buildForm ? cfg.buildForm(row) : row)}>
                              <Pencil className="h-4 w-4" />
                            </button>
                          )}
                          {isManager && cfg.deletable !== false && (
                            <button className="btn-ghost btn-sm text-red-500 hover:bg-red-50" title="Delete" onClick={() => setDeleting(row)}>
                              <Trash2 className="h-4 w-4" />
                            </button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
            <Pagination pagination={list.pagination} onPage={list.setPage} />
          </div>
        )}
      </div>

      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? `Edit ${title.replace(/s$/, '')}` : `New ${title.replace(/s$/, '')}`} size="md">
        {editing && (
          <ResourceForm
            fields={fieldDefs}
            initial={editing}
            busy={busy}
            submitLabel={editing.id ? 'Save changes' : 'Create'}
            onCancel={() => setEditing(null)}
            onSubmit={save}
          />
        )}
      </Modal>

      <ConfirmDialog
        open={!!deleting}
        busy={busy}
        onClose={() => setDeleting(null)}
        onConfirm={confirmDelete}
        title={`Delete ${title.replace(/s$/, '')}?`}
        message={deleting ? `“${getRowTitle(deleting)}” will be permanently removed. This cannot be undone.` : ''}
      />
    </section>
  );
}
