import { useState, useEffect, useCallback } from 'react';
import {
  FolderKanban, CheckSquare, Users, Truck, AlertTriangle, ClipboardList,
  CheckCircle2, Building2, Activity as ActivityIcon, Pin
} from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { LoadingState, ErrorState, StatusBadge } from '../components/ui';

const STAT_CARDS = [
  { key: 'activeProjects', label: 'Active Projects', icon: FolderKanban, color: 'text-brand-600 bg-brand-50' },
  { key: 'openTasks', label: 'Open Tasks', icon: CheckSquare, color: 'text-blue-600 bg-blue-50' },
  { key: 'delayedProjects', label: 'Delayed', icon: AlertTriangle, color: 'text-red-600 bg-red-50' },
  { key: 'todaysDeliveries', label: "Today's Dispatch", icon: Truck, color: 'text-amber-600 bg-amber-50' },
  { key: 'pendingWorkOrders', label: 'Pending WOs', icon: ClipboardList, color: 'text-violet-600 bg-violet-50' },
  { key: 'completedProjects', label: 'Completed', icon: CheckCircle2, color: 'text-emerald-600 bg-emerald-50' },
  { key: 'totalClients', label: 'Clients', icon: Building2, color: 'text-slate-600 bg-slate-100' },
  { key: 'employees', label: 'Team Members', icon: Users, color: 'text-sky-600 bg-sky-50' }
];

const humanize = (s) => String(s).replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
const timeAgo = (d) => {
  const sec = Math.floor((Date.now() - new Date(d)) / 1000);
  if (sec < 60) return 'just now';
  if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  if (sec < 86400) return `${Math.floor(sec / 3600)}h ago`;
  return new Date(d).toLocaleDateString();
};

function Breakdown({ title, rows, total }) {
  return (
    <div className="card p-5">
      <h3 className="mb-3 text-sm font-semibold text-slate-900">{title}</h3>
      {rows.length === 0 ? (
        <p className="py-4 text-center text-sm text-slate-400">No data yet</p>
      ) : (
        <div className="space-y-2.5">
          {rows.map((r) => (
            <div key={r.status}>
              <div className="mb-1 flex items-center justify-between text-xs">
                <span className="text-slate-600">{humanize(r.status)}</span>
                <span className="font-medium text-slate-900">{r.count}</span>
              </div>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-100">
                <div className="h-full rounded-full bg-brand-500" style={{ width: `${total ? (r.count / total) * 100 : 0}%` }} />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setError(null);
    try {
      const d = await Api.dashboard();
      setData(d);
      setActivities(d.recentActivities || []);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  // Live activity feed + refresh KPIs when domain events fire.
  useEffect(() => {
    const onActivity = (a) => setActivities((cur) => [a, ...cur].slice(0, 12));
    const refreshEvents = ['project_created', 'project_updated', 'project_deleted', 'task_created', 'task_updated', 'work_order_created', 'dispatch_updated'];
    socket.on('activity_created', onActivity);
    const refresh = () => load();
    refreshEvents.forEach((e) => socket.on(e, refresh));
    return () => {
      socket.off('activity_created', onActivity);
      refreshEvents.forEach((e) => socket.off(e, refresh));
    };
  }, [load]);

  if (loading) return <LoadingState label="Loading dashboard…" />;
  if (error) return <ErrorState message={error} onRetry={load} />;

  const projTotal = data.projectStatusBreakdown.reduce((s, r) => s + r.count, 0);
  const taskTotal = data.taskStatusBreakdown.reduce((s, r) => s + r.count, 0);

  return (
    <section className="space-y-6">
      <div>
        <h1 className="text-xl font-semibold tracking-tight text-slate-900">Dashboard</h1>
        <p className="mt-0.5 text-sm text-slate-500">Live overview of operations across WOLF3D Technologies.</p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {STAT_CARDS.map(({ key, label, icon: Icon, color }) => (
          <div key={key} className="card p-4">
            <div className={`mb-2 inline-flex h-9 w-9 items-center justify-center rounded-lg ${color}`}><Icon className="h-[18px] w-[18px]" /></div>
            <p className="text-2xl font-semibold text-slate-900">{data.stats[key] ?? 0}</p>
            <p className="text-xs text-slate-500">{label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2 card overflow-hidden">
          <div className="flex items-center gap-2 border-b border-slate-100 px-5 py-3.5">
            <ActivityIcon className="h-4 w-4 text-brand-600" />
            <h3 className="text-sm font-semibold text-slate-900">Recent Activity</h3>
            <span className="ml-auto badge bg-emerald-50 text-emerald-700">Live</span>
          </div>
          {activities.length === 0 ? (
            <p className="py-10 text-center text-sm text-slate-400">No activity yet</p>
          ) : (
            <ul className="divide-y divide-slate-50">
              {activities.map((a) => (
                <li key={a.id} className="flex items-start gap-3 px-5 py-3">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-400" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-slate-700">
                      <span className="font-medium text-slate-900">{a.user_name || 'Someone'}</span> {a.action}
                      {a.details ? <span className="text-slate-500"> — {a.details}</span> : null}
                    </p>
                    <p className="text-xs text-slate-400">{a.module} · {timeAgo(a.created_at)}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="space-y-4">
          <Breakdown title="Projects by status" rows={data.projectStatusBreakdown} total={projTotal} />
          <Breakdown title="Tasks by status" rows={data.taskStatusBreakdown} total={taskTotal} />
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="flex items-center gap-2 border-b border-slate-100 px-5 py-3.5">
          <Pin className="h-4 w-4 text-brand-600" />
          <h3 className="text-sm font-semibold text-slate-900">Latest Notices</h3>
        </div>
        {data.recentNotices.length === 0 ? (
          <p className="py-8 text-center text-sm text-slate-400">No notices posted</p>
        ) : (
          <ul className="divide-y divide-slate-50">
            {data.recentNotices.map((n) => (
              <li key={n.id} className="flex items-center gap-3 px-5 py-3">
                {n.pinned && <Pin className="h-3.5 w-3.5 text-amber-500" />}
                <span className="flex-1 truncate text-sm font-medium text-slate-700">{n.title}</span>
                {n.urgent && <span className="badge bg-red-50 text-red-700">Urgent</span>}
                <span className="text-xs text-slate-400">{timeAgo(n.created_at)}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
