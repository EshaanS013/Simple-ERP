import { useState, useEffect, useRef, useCallback } from 'react';
import { Send, Search, Circle, MessageSquare } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PageHeader, Spinner } from '../components/ui';

export default function Messages() {
  const { user } = useAuth();
  const toast = useToast();
  const [contacts, setContacts] = useState([]);
  const [loadingContacts, setLoadingContacts] = useState(true);
  const [active, setActive] = useState(null); // contact being chatted with
  const [messages, setMessages] = useState([]);
  const [loadingMsgs, setLoadingMsgs] = useState(false);
  const [draft, setDraft] = useState('');
  const [onlineIds, setOnlineIds] = useState(() => new Set());
  const [query, setQuery] = useState('');
  const [results, setResults] = useState(null);
  const endRef = useRef(null);
  const activeRef = useRef(null);
  activeRef.current = active;

  const loadContacts = useCallback(async () => {
    try { setContacts((await Api.messageContacts()).data || []); }
    catch (e) { toast.error(e.message); } finally { setLoadingContacts(false); }
  }, [toast]);

  const openChat = useCallback(async (c) => {
    setActive(c); setResults(null); setQuery(''); setLoadingMsgs(true);
    try { setMessages((await Api.conversation(c.id)).data || []); }
    catch (e) { toast.error(e.message); } finally { setLoadingMsgs(false); }
    loadContacts();
  }, [toast, loadContacts]);

  useEffect(() => { loadContacts(); }, [loadContacts]);

  useEffect(() => {
    const onPresence = (p) => setOnlineIds(new Set(p.onlineUserIds || []));
    const onDm = (m) => {
      const a = activeRef.current;
      if (a && (m.sender_id === a.id || m.recipient_id === a.id)) {
        setMessages((prev) => prev.some((x) => x.id === m.id) ? prev : [...prev, m]);
        if (m.sender_id === a.id) Api.conversation(a.id).catch(() => {}); // mark read
      }
      loadContacts();
    };
    const onRead = () => { setMessages((prev) => prev.map((x) => x.sender_id === user.id ? { ...x, read_at: x.read_at || new Date().toISOString() } : x)); };
    socket.on('presence', onPresence); socket.on('dm', onDm); socket.on('dm_read', onRead);
    return () => { socket.off('presence', onPresence); socket.off('dm', onDm); socket.off('dm_read', onRead); };
  }, [user.id, loadContacts]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages.length]);

  const send = async () => {
    const body = draft.trim();
    if (!body || !active) return;
    setDraft('');
    try {
      const msg = await Api.sendMessage(active.id, body);
      setMessages((prev) => prev.some((x) => x.id === msg.id) ? prev : [...prev, msg]);
    } catch (e) { toast.error(e.message); }
  };

  const runSearch = async (q) => {
    setQuery(q);
    if (!q.trim()) { setResults(null); return; }
    try { setResults((await Api.searchMessages(q)).data || []); } catch (e) { toast.error(e.message); }
  };

  const fmt = (d) => new Date(d).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  const isOnline = (id) => onlineIds.has(id);

  return (
    <section>
      <PageHeader title="Messages" subtitle="Direct messages with your team. History is kept for 30 days." />
      <div className="card grid h-[70vh] grid-cols-1 overflow-hidden md:grid-cols-[300px_1fr]">
        {/* Contacts */}
        <aside className="flex flex-col border-r border-slate-100">
          <div className="border-b border-slate-100 p-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input className="input pl-9" placeholder="Search messages…" value={query} onChange={(e) => runSearch(e.target.value)} />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {loadingContacts ? <div className="flex justify-center py-8"><Spinner /></div>
              : results !== null ? (
                results.length === 0 ? <p className="p-4 text-center text-sm text-slate-400">No matches.</p>
                : results.map((m) => (
                  <div key={m.id} className="border-b border-slate-50 px-4 py-2 text-sm">
                    <div className="flex justify-between text-xs text-slate-400"><span>{m.sender_id === user.id ? `You → ${m.recipient_name}` : m.sender_name}</span><span>{fmt(m.created_at)}</span></div>
                    <p className="text-slate-700">{m.body}</p>
                  </div>
                ))
              ) : contacts.length === 0 ? <p className="p-4 text-center text-sm text-slate-400">No one to message yet.</p>
              : contacts.map((c) => (
                <button key={c.id} onClick={() => openChat(c)}
                  className={`flex w-full items-center gap-3 border-b border-slate-50 px-4 py-3 text-left hover:bg-slate-50 ${active?.id === c.id ? 'bg-brand-50/60' : ''}`}>
                  <div className="relative">
                    <div className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-100 text-xs font-semibold text-brand-700">
                      {c.name.split(' ').map((s) => s[0]).slice(0, 2).join('')}
                    </div>
                    <Circle className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full ${isOnline(c.id) ? 'fill-emerald-500 text-emerald-500' : 'fill-slate-300 text-slate-300'}`} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="truncate text-sm font-medium text-slate-800">{c.name}</span>
                      {c.unread > 0 && <span className="ml-2 inline-flex h-5 min-w-[20px] items-center justify-center rounded-full bg-brand-600 px-1.5 text-[11px] font-semibold text-white">{c.unread}</span>}
                    </div>
                    <p className="truncate text-xs text-slate-400">{c.last_body || 'No messages yet'}</p>
                  </div>
                </button>
              ))}
          </div>
        </aside>

        {/* Conversation */}
        <div className="flex flex-col">
          {!active ? (
            <div className="flex flex-1 flex-col items-center justify-center text-slate-400">
              <MessageSquare className="h-10 w-10" /><p className="mt-2 text-sm">Select a conversation</p>
            </div>
          ) : (
            <>
              <header className="flex items-center gap-2 border-b border-slate-100 px-4 py-3">
                <span className="text-sm font-semibold text-slate-800">{active.name}</span>
                <span className={`text-xs ${isOnline(active.id) ? 'text-emerald-600' : 'text-slate-400'}`}>{isOnline(active.id) ? 'Online' : 'Offline'}</span>
              </header>
              <div className="flex-1 space-y-2 overflow-y-auto bg-slate-50/40 px-4 py-3">
                {loadingMsgs ? <div className="flex justify-center py-8"><Spinner /></div>
                  : messages.length === 0 ? <p className="py-8 text-center text-sm text-slate-400">Say hello 👋</p>
                  : messages.map((m) => {
                    const mine = m.sender_id === user.id;
                    return (
                      <div key={m.id} className={`flex ${mine ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[75%] rounded-2xl px-3 py-2 text-sm ${mine ? 'bg-brand-600 text-white' : 'bg-white text-slate-800 shadow-sm'}`}>
                          <p className="whitespace-pre-wrap break-words">{m.body}</p>
                          <div className={`mt-0.5 text-right text-[10px] ${mine ? 'text-brand-100' : 'text-slate-400'}`}>
                            {fmt(m.created_at)}{mine && (m.read_at ? ' · Read' : ' · Sent')}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                <div ref={endRef} />
              </div>
              <div className="flex items-end gap-2 border-t border-slate-100 p-3">
                <textarea className="input min-h-[42px] flex-1 resize-none" rows={1} placeholder="Type a message…" value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} />
                <button className="btn-primary shrink-0" onClick={send} disabled={!draft.trim()}><Send className="h-4 w-4" /></button>
              </div>
            </>
          )}
        </div>
      </div>
    </section>
  );
}
