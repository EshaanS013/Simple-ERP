import { io } from 'socket.io-client';
import { getToken } from './api';

const URL = import.meta.env.VITE_API_BASE_URL || undefined; // same origin if undefined

// Single shared socket instance. Connects lazily once a token is present.
export const socket = io(URL, {
  autoConnect: false,
  transports: ['websocket', 'polling'],
  reconnection: true,
  reconnectionAttempts: Infinity,
  reconnectionDelay: 1000
});

export function connectSocket() {
  const token = getToken();
  if (!token) return;
  socket.auth = { token };
  if (!socket.connected) socket.connect();
}

export function disconnectSocket() {
  if (socket.connected) socket.disconnect();
}
