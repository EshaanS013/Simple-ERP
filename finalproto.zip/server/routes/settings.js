const express = require('express');
const { pool } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler } = require('../middleware/errorHandler');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

router.get('/', asyncHandler(async (req, res) => {
  const { rows } = await pool.query('SELECT key, value FROM settings ORDER BY key');
  res.json(rows.reduce((acc, r) => ({ ...acc, [r.key]: r.value }), {}));
}));

router.post('/', managerOnly, validate({ body: schemas.upsertSetting }), asyncHandler(async (req, res) => {
  const { key, value } = req.body;
  await pool.query(
    `INSERT INTO settings (key, value) VALUES ($1,$2)
     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`,
    [key, value ?? null]
  );
  res.status(201).json({ success: true });
}));

module.exports = router;
