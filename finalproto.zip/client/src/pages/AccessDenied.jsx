import { Link } from 'react-router-dom';
import { ShieldX, ArrowLeft } from 'lucide-react';

export default function AccessDenied({ module }) {
  return (
    <section className="flex min-h-[60vh] flex-col items-center justify-center text-center">
      <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-red-50 text-red-500">
        <ShieldX className="h-8 w-8" />
      </div>
      <h1 className="text-xl font-semibold text-slate-900">Access Denied</h1>
      <p className="mt-2 max-w-sm text-sm text-slate-500">
        You don't have permission to view {module || 'this module'}. If you believe this is a mistake,
        ask an administrator to add you to the relevant department.
      </p>
      <Link to="/" className="btn-primary mt-5"><ArrowLeft className="h-4 w-4" /> Back to dashboard</Link>
    </section>
  );
}
