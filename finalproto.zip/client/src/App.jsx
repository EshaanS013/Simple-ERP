import { Routes, Route, Navigate } from 'react-router-dom';
import { lazy, Suspense } from 'react';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { AppLayout, ProtectedRoute, RequireAccess } from './components/Layout';
import { useAuth } from './context/AuthContext';
import { LoadingState } from './components/ui';

import Login from './pages/Login';
import ChangePassword from './pages/ChangePassword';
import Dashboard from './pages/Dashboard';
// Heavy / less-frequent pages are code-split to speed up first load.
const Production = lazy(() => import('./pages/Production'));
const DesignUpdates = lazy(() => import('./pages/DesignUpdates'));
const DesignWorkspace = lazy(() => import('./pages/DesignWorkspace'));
const Messages = lazy(() => import('./pages/Messages'));
const Machines = lazy(() => import('./pages/Machines'));
const MachineHistory = lazy(() => import('./pages/MachineHistory'));
const Payments = lazy(() => import('./pages/Payments'));
const Notices = lazy(() => import('./pages/Notices'));
const Departments = lazy(() => import('./pages/Departments'));
const DepartmentWorkspace = lazy(() => import('./pages/DepartmentWorkspace'));
const Activity = lazy(() => import('./pages/Activity'));
const Users = lazy(() => import('./pages/Users'));
const SystemAdmin = lazy(() => import('./pages/SystemAdmin'));


function AccountsRoute() {
  const { canAccessAccounts } = useAuth();
  return <RequireAccess allowed={canAccessAccounts} module="Accounts"><Payments /></RequireAccess>;
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <Routes>
          {/* Public */}
          <Route path="/login" element={<Login />} />

          {/* Authenticated (password-change gate handled inside ProtectedRoute) */}
          <Route element={<ProtectedRoute />}>
            <Route path="/change-password" element={<ChangePassword />} />
          </Route>

          {/* App shell + protected pages (collaborative — employees included) */}
          <Route element={<ProtectedRoute />}>
            <Route element={<AppLayout />}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/production" element={<Production />} />
              <Route path="/design" element={<DesignUpdates />} />
              <Route path="/design/:id" element={<DesignWorkspace />} />
              <Route path="/messages" element={<Messages />} />
              <Route path="/machines" element={<Machines />} />
              <Route path="/machines/:id/history" element={<MachineHistory />} />
              <Route path="/accounts" element={<AccountsRoute />} />
              <Route path="/payments" element={<Navigate to="/accounts" replace />} />
              <Route path="/departments" element={<Departments />} />
              <Route path="/departments/:id" element={<DepartmentWorkspace />} />
              <Route path="/notices" element={<Notices />} />
            </Route>
          </Route>

          {/* Manager / Admin only */}
          <Route element={<ProtectedRoute managerOnly />}>
            <Route element={<AppLayout />}>
              <Route path="/activity" element={<Activity />} />
              <Route path="/users" element={<Users />} />
            </Route>
          </Route>

          {/* Admin only */}
          <Route element={<ProtectedRoute adminOnly />}>
            <Route element={<AppLayout />}>
              <Route path="/system" element={<SystemAdmin />} />
            </Route>
          </Route>

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </ToastProvider>
    </AuthProvider>
  );
}
