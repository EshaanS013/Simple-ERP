// Structured API error and centralized handling.

class ApiError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code || undefined;
  }
}

const badRequest = (msg, code) => new ApiError(400, msg, code);
const unauthorized = (msg = 'Authentication required') => new ApiError(401, msg);
const forbidden = (msg = 'You do not have permission to do that') => new ApiError(403, msg);
const notFound = (msg = 'Resource not found') => new ApiError(404, msg);
const conflict = (msg, code) => new ApiError(409, msg, code);

// Wrap async route handlers so rejected promises reach the error middleware.
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

function notFoundHandler(req, res, next) {
  // Only API paths should 404 as JSON; SPA fallback handles the rest.
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'Endpoint not found' });
  }
  next();
}

// Map common PostgreSQL errors to friendly messages.
function translatePgError(err) {
  switch (err.code) {
    case '23505': // unique_violation
      return new ApiError(409, 'A record with that value already exists', 'duplicate');
    case '23503': // foreign_key_violation
      return new ApiError(400, 'Referenced record does not exist', 'fk_violation');
    case '23502': // not_null_violation
      return new ApiError(400, `Missing required field: ${err.column || 'unknown'}`, 'not_null');
    case '23514': // check_violation
      return new ApiError(400, 'A value is not allowed for one of the fields', 'check_violation');
    case '22P02': // invalid_text_representation
      return new ApiError(400, 'Invalid value supplied for a field', 'invalid_value');
    default:
      return null;
  }
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  let apiError = err;

  if (!(err instanceof ApiError)) {
    const translated = translatePgError(err);
    if (translated) {
      apiError = translated;
    } else if (err && (err.type === 'entity.parse.failed' || err.type === 'entity.too.large' || err.type === 'encoding.unsupported' || err.type === 'request.aborted')) {
      // Body-parser / request errors are client problems (400/413), not 500s.
      const map = { 'entity.parse.failed': [400, 'Invalid JSON in request body'], 'entity.too.large': [413, 'Request body is too large'], 'encoding.unsupported': [415, 'Unsupported content encoding'], 'request.aborted': [400, 'Request aborted'] };
      const [st, msg] = map[err.type];
      apiError = new ApiError(st, msg, err.type);
    } else if (err && err.name === 'MulterError') {
      // File-upload errors (size/count/field) are client problems.
      const msg = err.code === 'LIMIT_FILE_SIZE' ? 'Image is too large (max 5MB)' : 'File upload failed';
      apiError = new ApiError(400, msg, err.code);
    } else if (typeof err?.status === 'number' && err.status >= 400 && err.status < 500) {
      // Any other middleware error that already declares a 4xx status.
      apiError = new ApiError(err.status, err.message || 'Bad request');
    } else {
      apiError = new ApiError(500, 'Something went wrong on our end');
      console.error(`[${req.method} ${req.originalUrl}]`, err);
      try { require('../utils/logger').error('app_error', err.message, { path: `${req.method} ${req.originalUrl}`, stack: err.stack }); } catch { /* ignore */ }
    }
  }

  const body = { error: apiError.message };
  if (apiError.code) body.code = apiError.code;
  res.status(apiError.status || 500).json(body);
}

module.exports = {
  ApiError,
  badRequest,
  unauthorized,
  forbidden,
  notFound,
  conflict,
  asyncHandler,
  notFoundHandler,
  errorHandler
};
