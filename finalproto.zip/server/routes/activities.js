const express = require('express');
const { pool } = require('../db/pool');
const { authGuard } = require('../middleware/auth');
const { attachScope } = require('../utils/scope');
const { validate } = require('../middleware/validate');
const { asyncHandler } = require('../middleware/errorHandler');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard, attachScope);

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query, 30);
  const { search } = req.query;
  const where = []; const params = []; let i = 1;
  // Employees: only activity in their departments (or that they performed).
  if (!req.isManager) {
    const ids = req.deptIds || [];
    if (ids.length) { where.push(`(a.department_id = ANY($${i}::int[]) OR a.user_id = $${i + 1})`); params.push(ids, req.user.id); i += 2; }
    else { where.push(`a.user_id = $${i++}`); params.push(req.user.id); }
  }
  if (search) { where.push(`(a.action ILIKE $${i} OR a.details ILIKE $${i} OR a.user_name ILIKE $${i})`); params.push(`%${search}%`); i++; }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = await pool.query(`SELECT COUNT(*)::int c FROM activities a ${whereSql}`, params);
  const rows = await pool.query(
    `SELECT a.*, d.name AS department_name FROM activities a
       LEFT JOIN departments d ON d.id = a.department_id
       ${whereSql} ORDER BY a.created_at DESC LIMIT $${i++} OFFSET $${i++}`,
    [...params, pageSize, offset]
  );
  res.json(paginatedResponse(rows.rows, total.rows[0].c, page, pageSize));
}));

module.exports = router;
