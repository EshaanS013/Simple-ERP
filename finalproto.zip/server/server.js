const path = require('path');
const fs = require('fs');
const http = require('http');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const config = require('./config/env');
const { runMigrations } = require('./db/migrate');
const { seed } = require('./db/seed');
const { healthcheck } = require('./db/pool');
const { initSocket } = require('./socket/socket');
const { apiLimiter } = require('./middleware/rateLimit');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');

const app = express();
app.set('trust proxy', 1);

// Allow the SPA bundle (served from same origin) to load; relax CSP for assets.
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: false }));

const corsOptions = {
  origin: config.ALLOWED_ORIGINS,
  credentials: true
};
app.use(cors(corsOptions));
app.use(express.json({ limit: '1mb' }));
app.use(morgan(config.isProd ? 'combined' : 'dev'));

// Health/readiness endpoints (used by Docker healthchecks).
app.get('/api/health', async (req, res) => {
  try {
    await healthcheck();
    res.json({ status: 'ok', uptime: process.uptime() });
  } catch (err) {
    res.status(503).json({ status: 'degraded', error: 'database unavailable' });
  }
});

app.use('/api', apiLimiter);

// Uploaded part images (public, obscure filenames) — served before the SPA
// catch-all so /uploads/<file> resolves to the file, not index.html.
const UPLOADS_DIR = process.env.UPLOADS_DIR || path.join(__dirname, 'uploads');
try { fs.mkdirSync(UPLOADS_DIR, { recursive: true }); } catch { /* exists */ }
app.use('/uploads', express.static(UPLOADS_DIR, { index: false, maxAge: '7d', fallthrough: true }));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/departments', require('./routes/departments'));
app.use('/api/production', require('./routes/production'));
app.use('/api/design', require('./routes/design'));
app.use('/api/machines', require('./routes/machines'));
app.use('/api/payments', require('./routes/payments'));
app.use('/api/notices', require('./routes/notices'));
app.use('/api/activities', require('./routes/activities'));
app.use('/api/comments', require('./routes/comments'));
app.use('/api/messages', require('./routes/messages'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/admin', require('./routes/admin'));

// Unmatched API routes return JSON 404 (never the SPA HTML).
app.use(notFoundHandler);

// Serve the built SPA when present (single-container production deployment).
const clientDist = path.resolve(__dirname, '..', 'client', 'dist');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get('*', (req, res) => res.sendFile(path.join(clientDist, 'index.html')));
}

app.use(errorHandler);

const server = http.createServer(app);

async function start() {
  await runMigrations();
  await seed();
  await autoImportExcel();
  initSocket(server);
  // 30-day DM retention: purge on boot, then hourly.
  const { purgeOldMessages } = require('./routes/messages');
  await purgeOldMessages().catch((e) => console.error('Message purge failed:', e.message));
  setInterval(() => purgeOldMessages().catch((e) => console.error('Message purge failed:', e.message)), 60 * 60 * 1000).unref();

  // Nightly automated database backup (2:00 AM), runs without stopping the ERP.
  try {
    const backupSvc = require('./services/backup');
    const next = backupSvc.scheduleNightly();
    console.log(`Automated backups scheduled — next run ${next}`);
    backupSvc.checkTools().then((r) => { if (!r.ok) console.error('WARNING: pg_dump unavailable — backups will fail. Ensure postgresql-client is in the image.'); });
  } catch (e) { console.error('Backup scheduler failed to start:', e.message); }
  server.listen(config.PORT, '0.0.0.0', () => {
    console.log(`WOLF3D ERP server running on http://0.0.0.0:${config.PORT} (${config.NODE_ENV})`);
  });
}

// On first launch (empty production table), pull in any spreadsheets the user
// dropped into db/excel/ so their real data is ready without manual entry.
async function autoImportExcel() {
  try {
    const { pool } = require('./db/pool');
    const { runImport } = require('./db/import_excel');
    const { rows } = await pool.query('SELECT COUNT(*)::int AS c FROM production_records');
    if (rows[0].c > 0) return; // already has data — never auto-touch it
    const t = await runImport();
    const total = t.production + t.payments + t.machines;
    if (total > 0) console.log(`Auto-imported from db/excel: ${t.production} production, ${t.payments} payments, ${t.machines} machine-usage rows.`);
  } catch (e) {
    console.warn('Excel auto-import skipped:', e.message);
  }
}

start().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

// Graceful shutdown
let shuttingDown = false;
function shutdown(sig, code = 0) {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log(`\n${sig} received, shutting down...`);
  // Force-exit if connections don't drain in time, so Docker can restart cleanly.
  const t = setTimeout(() => process.exit(code), 10000);
  t.unref();
  server.close(() => { clearTimeout(t); process.exit(code); });
}
['SIGINT', 'SIGTERM'].forEach((sig) => process.on(sig, () => shutdown(sig, 0)));

// Last-resort process guards so a stray async error never silently kills the
// service. We log, then exit so Docker's restart policy brings us back in a
// known-good state (an unhandled rejection can leave state inconsistent).
process.on('unhandledRejection', (reason) => {
  console.error('UNHANDLED REJECTION:', reason);
  try { require('./utils/logger').critical('unhandled_rejection', reason && reason.message ? reason.message : String(reason)); } catch { /* ignore */ }
});
process.on('uncaughtException', (err) => {
  console.error('UNCAUGHT EXCEPTION:', err);
  try { require('./utils/logger').critical('uncaught_exception', err.message, { stack: err.stack }); } catch { /* ignore */ }
  shutdown('uncaughtException', 1);
});

module.exports = app;
