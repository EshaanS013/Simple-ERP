import { Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { AppLayout, ProtectedRoute } from './components/Layout';

import Login from './pages/Login';
import ChangePassword from './pages/ChangePassword';
import Dashboard from './pages/Dashboard';
import Projects from './pages/Projects';
import WorkOrders from './pages/WorkOrders';
import Tasks from './pages/Tasks';
import Quality from './pages/Quality';
import Dispatch from './pages/Dispatch';
import Clients from './pages/Clients';
import Notices from './pages/Notices';
import Departments from './pages/Departments';
import DepartmentDetails from './pages/DepartmentDetails';
import Activity from './pages/Activity';
import Reports from './pages/Reports';
import Users from './pages/Users';

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <Routes>
          {/* Public */}
          <Route path="/login" element={<Login />} />

          {/* Authenticated (password-change gate handled inside ProtectedRoute) */}
          <Route element={<ProtectedRoute />}>
            <Route path="/change-password" element={<ChangePassword />} />
          </Route>

          {/* App shell + protected pages */}
          <Route element={<ProtectedRoute />}>
            <Route element={<AppLayout />}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/projects" element={<Projects />} />
              <Route path="/work-orders" element={<WorkOrders />} />
              <Route path="/tasks" element={<Tasks />} />
              <Route path="/quality" element={<Quality />} />
              <Route path="/dispatch" element={<Dispatch />} />
              <Route path="/clients" element={<Clients />} />
              <Route path="/notices" element={<Notices />} />
              <Route path="/departments" element={<Departments />} />
              <Route path="/departments/:name" element={<DepartmentDetails />} />
              <Route path="/activity" element={<Activity />} />
              <Route path="/reports" element={<Reports />} />
            </Route>
          </Route>

          {/* Manager-only */}
          <Route element={<ProtectedRoute managerOnly />}>
            <Route element={<AppLayout />}>
              <Route path="/users" element={<Users />} />
            </Route>
          </Route>

          {/* Fallback */}
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </ToastProvider>
    </AuthProvider>
  );
}
