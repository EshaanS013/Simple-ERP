-- 006_production_part_image.sql
-- Optional reference image per production part (BDE input, set by Sales/managers).
-- Stores only the filename; the file lives on the uploads volume.
ALTER TABLE production_records ADD COLUMN IF NOT EXISTS part_image TEXT;
