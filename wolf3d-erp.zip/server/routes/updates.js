const express = require('express');
const { pool } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler } = require('../middleware/errorHandler');
const { emitEvent } = require('../socket/socket');
const { recordActivity } = require('../utils/activity');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

router.get('/', asyncHandler(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT up.*, u.name AS created_by_name FROM updates up
     LEFT JOIN users u ON u.id = up.created_by ORDER BY up.created_at DESC`
  );
  res.json({ data: rows });
}));

router.get('/:department', asyncHandler(async (req, res) => {
  const { rows } = await pool.query(
    `SELECT up.*, u.name AS created_by_name FROM updates up
     LEFT JOIN users u ON u.id = up.created_by
     WHERE up.department = $1 ORDER BY up.created_at DESC`,
    [req.params.department]
  );
  res.json({ data: rows });
}));

router.post('/', managerOnly, validate({ body: schemas.createUpdate }), asyncHandler(async (req, res) => {
  const { department, message } = req.body;
  const { rows } = await pool.query(
    `INSERT INTO updates (department, message, created_by) VALUES ($1,$2,$3) RETURNING *`,
    [department, message, req.user.id]
  );
  const update = { ...rows[0], created_by_name: req.user.name };
  emitEvent('update_created', update);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'posted an update', module: 'Departments', details: `${department}: ${message.slice(0, 60)}` });
  res.status(201).json(update);
}));

module.exports = router;
