import { createContext, useContext, useState, useCallback, useMemo, useRef } from 'react';
import { CheckCircle2, AlertCircle, Info, X } from 'lucide-react';

const ToastContext = createContext(null);
let idCounter = 0;

const ICONS = { success: CheckCircle2, error: AlertCircle, info: Info };
const STYLES = {
  success: 'border-emerald-200 bg-emerald-50 text-emerald-800',
  error: 'border-red-200 bg-red-50 text-red-800',
  info: 'border-slate-200 bg-white text-slate-800'
};

const MAX_TOASTS = 4;       // never show more than this many at once
const DEDUPE_MS = 4000;     // ignore an identical message seen within this window

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const recent = useRef(new Map()); // message -> last shown timestamp (storm guard)

  const dismiss = useCallback((id) => setToasts((t) => t.filter((x) => x.id !== id)), []);

  const push = useCallback((type, message) => {
    const msg = String(message ?? '').slice(0, 300);
    const now = Date.now();
    // Storm guard: drop a message identical to one shown very recently.
    const last = recent.current.get(msg);
    if (last && now - last < DEDUPE_MS) return;
    recent.current.set(msg, now);
    if (recent.current.size > 50) recent.current.clear();

    const id = ++idCounter;
    setToasts((t) => {
      const next = [...t, { id, type, message: msg }];
      return next.length > MAX_TOASTS ? next.slice(next.length - MAX_TOASTS) : next;
    });
    setTimeout(() => dismiss(id), 4000);
  }, [dismiss]);

  // Stable references — critical so consumers' useCallback/useEffect deps don't
  // change every render (a render loop here can flood the app with toasts).
  const success = useCallback((m) => push('success', m), [push]);
  const error = useCallback((m) => push('error', m), [push]);
  const info = useCallback((m) => push('info', m), [push]);
  const value = useMemo(() => ({ success, error, info }), [success, error, info]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="fixed bottom-4 right-4 z-[100] flex w-80 max-w-[calc(100vw-2rem)] flex-col gap-2">
        {toasts.map((t) => {
          const Icon = ICONS[t.type] || Info;
          return (
            <div key={t.id} className={`animate-fade-in flex items-start gap-2.5 rounded-lg border px-3.5 py-3 shadow-pop ${STYLES[t.type]}`}>
              <Icon className="mt-0.5 h-4 w-4 shrink-0" />
              <p className="flex-1 text-sm">{t.message}</p>
              <button onClick={() => dismiss(t.id)} className="text-current/60 hover:text-current"><X className="h-4 w-4" /></button>
            </div>
          );
        })}
      </div>
    </ToastContext.Provider>
  );
}

export const useToast = () => {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast must be used within ToastProvider');
  return ctx;
};
