const express = require('express');
const { pool } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound } = require('../middleware/errorHandler');
const { recordActivity } = require('../utils/activity');
const { emitEvent } = require('../socket/socket');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

// ---- Machine list (main page cards: logs, volume, runtime) --------------
router.get('/', asyncHandler(async (req, res) => {
  const { rows } = await pool.query(`
    SELECT m.id, m.name, m.technology,
      (SELECT COUNT(*)::int FROM machine_usage u WHERE u.machine_id = m.id) AS usage_count,
      COALESCE((SELECT SUM(u.volume_cc) FROM machine_usage u WHERE u.machine_id = m.id), 0)::float AS total_volume_cc,
      COALESCE((SELECT SUM(u.hours) FROM machine_usage u WHERE u.machine_id = m.id), 0)::float AS total_runtime
    FROM machines m ORDER BY m.technology, m.name`);
  res.json({ data: rows.map((r) => ({ ...r, total_volume_cc: Math.round(r.total_volume_cc), total_runtime: Math.round(r.total_runtime * 10) / 10 })) });
}));

// ---- Add a machine (manager only) — name + technology only -------------
router.post('/', managerOnly, validate({ body: schemas.createMachine }), asyncHandler(async (req, res) => {
  const b = req.body;
  // measure column retained in schema for back-compat; logbook standardises on volume+runtime.
  const { rows } = await pool.query('INSERT INTO machines (name, technology, measure) VALUES ($1,$2,$3) RETURNING *', [b.name, b.technology, 'volume_cc']);
  emitEvent('machine_created', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'added a machine', module: 'Machines', details: b.name, entityType: 'machine', entityId: rows[0].id });
  res.status(201).json(rows[0]);
}));

// ---- Delete a machine (manager only) — cascades usage logs -------------
router.delete('/:id(\\d+)', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const ex = await pool.query('SELECT name FROM machines WHERE id=$1', [req.params.id]);
  if (ex.rowCount === 0) throw notFound('Machine not found');
  await pool.query('DELETE FROM machines WHERE id = $1', [req.params.id]); // ON DELETE CASCADE clears usage
  emitEvent('machine_deleted', { id: Number(req.params.id) });
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'deleted a machine', module: 'Machines', details: ex.rows[0].name, entityType: 'machine', entityId: Number(req.params.id) });
  res.json({ success: true });
}));

// ---- History page data: summary + monthly + chart ----------------------
router.get('/:id(\\d+)/dashboard', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const id = Number(req.params.id);
  const m = await pool.query('SELECT id, name, technology FROM machines WHERE id=$1', [id]);
  if (m.rowCount === 0) throw notFound('Machine not found');
  const sum = await pool.query(`
    SELECT COUNT(*)::int AS total_jobs,
           COALESCE(SUM(volume_cc),0)::float AS total_volume,
           COALESCE(SUM(hours),0)::float AS total_runtime
      FROM machine_usage WHERE machine_id=$1`, [id]);
  const monthly = await pool.query(`
    SELECT to_char(date_trunc('month', usage_date),'YYYY-MM') AS month,
           COALESCE(SUM(volume_cc),0)::float AS volume_cc,
           COALESCE(SUM(hours),0)::float AS runtime,
           COUNT(*)::int AS jobs,
           COUNT(DISTINCT usage_date)::int AS active_days,
           EXTRACT(DAY FROM (date_trunc('month', MAX(usage_date)) + INTERVAL '1 month' - INTERVAL '1 day'))::int AS days_in_month
      FROM machine_usage WHERE machine_id=$1
     GROUP BY 1 ORDER BY 1 DESC`, [id]);
  const monthlyRows = monthly.rows.map((r) => ({
    month: r.month,
    volume_cc: Math.round(r.volume_cc),
    runtime: Math.round(r.runtime * 10) / 10,
    jobs: r.jobs,
    avg_daily_runtime: r.active_days > 0 ? Math.round((r.runtime / r.active_days) * 10) / 10 : 0,
    idle_days: Math.max(0, r.days_in_month - r.active_days)
  }));
  res.json({
    machine: m.rows[0],
    summary: {
      total_jobs: sum.rows[0].total_jobs,
      total_volume: Math.round(sum.rows[0].total_volume),
      total_runtime: Math.round(sum.rows[0].total_runtime * 10) / 10
    },
    monthly: monthlyRows,
    chart: [...monthlyRows].reverse() // oldest -> newest for the bar chart
  });
}));

// ---- Usage log list (search + filter by month) -------------------------
router.get('/:id(\\d+)/usage', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query, 25);
  const { search, month } = req.query;
  const where = ['u.machine_id = $1']; const params = [req.params.id]; let i = 2;
  if (month) { where.push(`to_char(u.usage_date,'YYYY-MM') = $${i++}`); params.push(month); }
  if (search) { where.push(`(u.material ILIKE $${i} OR to_char(u.usage_date,'YYYY-MM-DD') ILIKE $${i})`); params.push(`%${search}%`); i++; }
  const whereSql = `WHERE ${where.join(' AND ')}`;
  const machine = await pool.query('SELECT id, name, technology FROM machines WHERE id = $1', [req.params.id]);
  if (machine.rowCount === 0) throw notFound('Machine not found');
  const total = await pool.query(`SELECT COUNT(*)::int c FROM machine_usage u ${whereSql}`, params);
  const history = await pool.query(
    `SELECT u.id, u.usage_date, u.material, u.volume_cc, u.hours, us.name AS logged_by
       FROM machine_usage u LEFT JOIN users us ON us.id = u.created_by
       ${whereSql} ORDER BY u.usage_date DESC, u.id DESC LIMIT $${i++} OFFSET $${i++}`,
    [...params, pageSize, offset]);
  // distinct months for the filter dropdown
  const months = await pool.query(
    `SELECT DISTINCT to_char(usage_date,'YYYY-MM') AS month FROM machine_usage WHERE machine_id=$1 ORDER BY 1 DESC`, [req.params.id]);
  res.json({ machine: machine.rows[0], months: months.rows.map((r) => r.month), ...paginatedResponse(history.rows, total.rows[0].c, page, pageSize) });
}));

// ---- Log usage ----------------------------------------------------------
router.post('/usage', validate({ body: schemas.createMachineUsage }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO machine_usage (machine_id, usage_date, material, hours, volume_cc, created_by)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [b.machine_id, b.usage_date, b.material, b.hours, b.volume_cc, req.user.id]);
  emitEvent('machine_usage_created', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'logged machine usage', module: 'Machines', details: b.material || '', entityType: 'machine_usage', entityId: rows[0].id });
  res.status(201).json(rows[0]);
}));

// ---- Edit a usage log ---------------------------------------------------
router.put('/usage/:id(\\d+)', validate({ params: schemas.idParam, body: schemas.updateMachineUsage }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `UPDATE machine_usage SET usage_date=$1, material=$2, volume_cc=$3, hours=$4 WHERE id=$5 RETURNING *`,
    [b.usage_date, b.material, b.volume_cc, b.hours, req.params.id]);
  if (rows.length === 0) throw notFound('Usage entry not found');
  emitEvent('machine_usage_created', rows[0]); // generic refresh signal
  res.json(rows[0]);
}));

// ---- Delete a usage log -------------------------------------------------
router.delete('/usage/:id(\\d+)', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rowCount } = await pool.query('DELETE FROM machine_usage WHERE id = $1', [req.params.id]);
  if (rowCount === 0) throw notFound('Usage entry not found');
  emitEvent('machine_usage_deleted', { id: Number(req.params.id) });
  res.json({ success: true });
}));

module.exports = router;
