/**
 * WOLF3D Excel importer
 * ---------------------
 * Loads your real spreadsheets straight into the database so you never have to
 * re-enter them. Drop your files in server/db/excel/ and they import
 * AUTOMATICALLY the first time the app starts with an empty database.
 *
 * You can also run it manually any time (from the server folder):
 *   npm run import              add rows from db/excel/*.xlsx
 *   npm run import -- --reset   clear existing production/payment/usage rows first
 *
 * Columns are matched by header text (case / spacing / punctuation ignored),
 * so small differences between sheet versions are tolerated.
 */
const fs = require('fs');
const path = require('path');
const XLSX = require('xlsx');
const { pool } = require('./pool');

const DEFAULT_DIR = path.join(__dirname, 'excel');
const norm = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]/g, '');
const clean = (v) => (v === undefined || v === null || String(v).trim() === '' ? null : String(v).trim());
const num = (v) => { if (v == null || v === '') return null; const n = Number(String(v).replace(/[₹,\s]/g, '')); return Number.isFinite(n) ? n : null; };
const toDate = (v) => {
  if (v == null || v === '') return null;
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  if (typeof v === 'number') { const d = XLSX.SSF.parse_date_code(v); return d ? `${d.y}-${String(d.m).padStart(2, '0')}-${String(d.d).padStart(2, '0')}` : null; }
  const d = new Date(v); return isNaN(d) ? null : d.toISOString().slice(0, 10);
};

function readRows(file) {
  const wb = XLSX.readFile(file, { cellDates: true });
  const out = [];
  for (const name of wb.SheetNames) {
    const raw = XLSX.utils.sheet_to_json(wb.Sheets[name], { defval: null, raw: true });
    for (const r of raw) {
      const obj = {};
      for (const [k, v] of Object.entries(r)) obj[norm(k)] = v;
      out.push(obj);
    }
  }
  return out;
}

const pick = (row, ...keys) => { for (const k of keys) if (row[k] !== undefined) return row[k]; return null; };

function classify(rows) {
  if (!rows.length) return 'unknown';
  const keys = new Set(Object.keys(rows[0]));
  if (keys.has('partname') || keys.has('workorderno') || keys.has('workordernumber')) return 'production';
  if (keys.has('invoiceno') || keys.has('invoicenumber') || (keys.has('amount') && keys.has('clientname'))) return 'payments';
  if (keys.has('machine') || keys.has('machinename')) return 'machines';
  return 'unknown';
}

function inferStage(r) {
  const has = (...k) => k.some((x) => clean(r[x]) !== null);
  const ds = norm(pick(r, 'dispatchstatus'));
  if (['dispatched', 'delivered', 'completed'].includes(ds)) return 'completed';
  if (has('dispatchstatus') || clean(pick(r, 'reportgenerated'))) return 'dispatch';
  if (has('xyzdimension', 'criticaldimension', 'surfacefinish', 'reportgenerated', 'reworkverdict')) return 'quality';
  if (has('finish', 'paint', 'printing', 'cleanandcure', 'sandingandpolishing', 'paintstatus')) return 'production';
  return 'work_order';
}

const mapPaymentStatus = (v) => {
  const n = norm(v);
  if (['received', 'recieved', 'paid', 'done'].includes(n)) return 'received';
  if (['overdue', 'late'].includes(n)) return 'overdue';
  if (['partial', 'part'].includes(n)) return 'partial';
  return 'pending';
};

async function importProduction(client, rows, deptId) {
  let n = 0;
  for (const r of rows) {
    const part = clean(pick(r, 'partname', 'part'));
    const wo = clean(pick(r, 'workorderno', 'workordernumber', 'workorder'));
    if (!part && !wo) continue;
    await client.query(
      `INSERT INTO production_records
       (department_id, work_order_number, order_date, client_name, dispatch_date, part_name, technology, quantity,
        finish, paint, printing, clean_and_cure, sanding_and_polishing, paint_status,
        xyz_dimension, critical_dimension, surface_finish, report_generated, rework_verdict, dispatch_status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20)`,
      [deptId, wo, toDate(pick(r, 'date', 'orderdate')), clean(pick(r, 'clientname', 'client')),
       toDate(pick(r, 'dispatchdate')), part || '(unnamed part)', clean(pick(r, 'technology', 'tech')), num(pick(r, 'quantity', 'qty')),
       clean(pick(r, 'finish')), clean(pick(r, 'paint')), clean(pick(r, 'printing')), clean(pick(r, 'cleanandcure')),
       clean(pick(r, 'sandingandpolishing')), clean(pick(r, 'paintstatus')),
       clean(pick(r, 'xyzdimension')), clean(pick(r, 'criticaldimension')), clean(pick(r, 'surfacefinish')),
       clean(pick(r, 'reportgenerated')), clean(pick(r, 'reworkverdict')), clean(pick(r, 'dispatchstatus')), inferStage(r)]
    );
    n++;
  }
  return n;
}

async function importPayments(client, rows) {
  let n = 0;
  for (const r of rows) {
    const cn = clean(pick(r, 'clientname', 'client'));
    const inv = clean(pick(r, 'invoiceno', 'invoicenumber'));
    if (!cn && !inv) continue;
    await client.query(
      `INSERT INTO payments
       (invoice_date, client_name, contact_number, invoice_number, amount, gst_status, payment_terms, payment_status, action, comments)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
      [toDate(pick(r, 'date', 'invoicedate')), cn || '(unknown client)', clean(pick(r, 'contactnumber', 'contact')),
       inv, num(pick(r, 'amount')), clean(pick(r, 'gstworking', 'gststatus', 'gst')),
       clean(pick(r, 'paymentterms', 'terms')), mapPaymentStatus(pick(r, 'status', 'paymentstatus')),
       clean(pick(r, 'action')), clean(pick(r, 'comment', 'comments'))]
    );
    n++;
  }
  return n;
}

async function importMachines(client, rows) {
  const { rows: existing } = await client.query('SELECT id, name, measure FROM machines');
  const byName = new Map(existing.map((m) => [norm(m.name), m]));
  let n = 0;
  for (const r of rows) {
    const mname = clean(pick(r, 'machine', 'machinename'));
    if (!mname) continue;
    const vol = num(pick(r, 'volume', 'volumecc', 'volcc'));
    const wt = num(pick(r, 'weight', 'weightgms', 'weightg'));
    const material = clean(pick(r, 'material'));
    // Nothing usable to record (e.g. a pivot-style row with date columns) — skip, don't fail.
    if (vol == null && wt == null && material == null) continue;
    let m = byName.get(norm(mname));
    if (!m) {
      const measure = wt != null && vol == null ? 'weight_gms' : 'volume_cc';
      const tech = clean(pick(r, 'technology', 'tech')) || 'Other';
      const ins = await client.query('INSERT INTO machines (name, technology, measure) VALUES ($1,$2,$3) RETURNING id, name, measure', [mname, tech, measure]);
      m = ins.rows[0]; byName.set(norm(mname), m);
    }
    const usageDate = toDate(pick(r, 'date', 'usagedate')) || new Date().toISOString().slice(0, 10);
    await client.query(
      'INSERT INTO machine_usage (machine_id, usage_date, material, volume_cc, weight_gms) VALUES ($1,$2,$3,$4,$5)',
      [m.id, usageDate, material, vol, wt]
    );
    n++;
  }
  return n;
}

/**
 * Run the import using the shared pool. Returns counts. Never exits the process.
 * Safe to call on startup — if the folder is missing/empty it just returns zeros.
 */
async function runImport({ dir = DEFAULT_DIR, reset = false, log = () => {} } = {}) {
  const totals = { production: 0, payments: 0, machines: 0, skipped: [], files: 0 };
  if (!fs.existsSync(dir)) return totals;
  const files = fs.readdirSync(dir).filter((f) => /\.(xlsx|xlsm|xls)$/i.test(f) && !f.startsWith('~'));
  if (!files.length) return totals;
  totals.files = files.length;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    if (reset) { await client.query('TRUNCATE machine_usage, production_records, payments RESTART IDENTITY CASCADE'); log('• Cleared existing production, payment and machine-usage rows (--reset).'); }
    const dept = await client.query("SELECT id FROM departments WHERE name = 'Production' LIMIT 1");
    const prodDeptId = dept.rows[0]?.id || null;
    for (const f of files) {
      const rows = readRows(path.join(dir, f));
      const kind = classify(rows);
      if (kind === 'production') totals.production += await importProduction(client, rows, prodDeptId);
      else if (kind === 'payments') totals.payments += await importPayments(client, rows);
      else if (kind === 'machines') totals.machines += await importMachines(client, rows);
      else totals.skipped.push(f);
      log(`• ${f} → ${kind}`);
    }
    await client.query('COMMIT');
  } catch (e) {
    await client.query('ROLLBACK');
    throw e;
  } finally {
    client.release();
  }
  return totals;
}

module.exports = { runImport };

// CLI entry point
if (require.main === module) {
  const dirIdx = process.argv.indexOf('--dir');
  const opts = { dir: dirIdx > -1 ? process.argv[dirIdx + 1] : DEFAULT_DIR, reset: process.argv.includes('--reset'), log: console.log };
  runImport(opts)
    .then((t) => {
      console.log(`\nImported: ${t.production} production, ${t.payments} payments, ${t.machines} machine-usage rows.`);
      if (t.skipped.length) console.log(`Skipped (unrecognised headers): ${t.skipped.join(', ')}`);
      if (!t.files) console.log('No Excel files found in the import folder.');
      return pool.end();
    })
    .then(() => process.exit(0))
    .catch((e) => { console.error('Import failed, no changes made:', e.message); pool.end().finally(() => process.exit(1)); });
}
