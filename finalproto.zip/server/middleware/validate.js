const { ApiError } = require('./errorHandler');

// validate({ body: schema, query: schema, params: schema })
// Replaces req[part] with the parsed/coerced value on success.
function validate(schemas) {
  return (req, res, next) => {
    try {
      for (const part of ['body', 'query', 'params']) {
        if (schemas[part]) {
          const result = schemas[part].safeParse(req[part]);
          if (!result.success) {
            const issue = result.error.issues[0];
            const field = issue.path.join('.') || part;
            throw new ApiError(400, `${field}: ${issue.message}`, 'validation');
          }
          // req.query/params are read-only getters on newer Express — assign defensively.
          if (part === 'body') req.body = result.data;
          else req.validated = { ...(req.validated || {}), [part]: result.data };
        }
      }
      next();
    } catch (err) {
      next(err);
    }
  };
}

module.exports = { validate };
