const B = 'http://127.0.0.1:4000';
let pass = 0, fail = 0;
const results = [];
function check(name, cond, detail) {
  if (cond) { pass++; results.push(`  PASS: ${name}`); }
  else { fail++; results.push(`  FAIL: ${name}${detail ? ' -> ' + detail : ''}`); }
}
async function j(method, path, token, body) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(B + path, { method, headers, body: body ? JSON.stringify(body) : undefined });
  let data = null;
  try { data = await res.json(); } catch (e) {}
  return { status: res.status, data };
}

(async () => {
  // AUTH
  const login = await j('POST', '/api/auth/login', null, { username: 'admin', password: 'Wolf3dAdmin#2026' });
  const token = login.data && login.data.token;
  results.push('[AUTH]');
  check('login returns token', !!token);
  check('login returns user with must_change_password flag', login.data.user && login.data.user.must_change_password === false);
  check('wrong password 401', (await j('POST', '/api/auth/login', null, { username: 'admin', password: 'x' })).status === 401);
  check('no-token 401', (await j('GET', '/api/projects', null)).status === 401);
  check('GET /me works', (await j('GET', '/api/auth/me', token)).data.username === 'admin');

  // CLIENTS
  results.push('[CLIENTS]');
  const cl = await j('POST', '/api/clients', token, { name: 'Tata Motors', contact_person: 'R. Sharma', email: 'rs@tata.test', phone: '9999' });
  check('create client', cl.data.name === 'Tata Motors', JSON.stringify(cl.data).slice(0, 120));
  const clid = cl.data.id;
  check('bad email rejected (400)', (await j('POST', '/api/clients', token, { name: 'X', email: 'bad' })).status === 400);
  const clist = await j('GET', '/api/clients?pageSize=5', token);
  check('clients list paginated', clist.data.pagination && Array.isArray(clist.data.data));

  // WORK ORDERS
  results.push('[WORK ORDERS]');
  const wo = await j('POST', '/api/work-orders', token, { work_order_number: 'WO-1001', client_id: clid, service_type: '3D Scan', part_name: 'Bracket', quantity: 5 });
  check('create work order', wo.data.work_order_number === 'WO-1001');
  const woDup = await j('POST', '/api/work-orders', token, { work_order_number: 'WO-1001', service_type: 'x' });
  check('duplicate WO -> 409 conflict', woDup.status === 409, JSON.stringify(woDup.data));
  const woid = wo.data.id;
  check('update work order', (await j('PUT', `/api/work-orders/${woid}`, token, { service_type: 'CMM', quantity: 3, status: 'in_progress' })).data.status === 'in_progress');

  // PROJECTS
  results.push('[PROJECTS]');
  const pr = await j('POST', '/api/projects', token, { project_number: 'PRJ-501', project_name: 'Engine Reverse Eng', client_id: clid, work_order_id: woid, status: 'in_progress', progress_percent: 40, deadline: '2026-08-01', assigned_to: [] });
  check('create project', pr.data.project_name === 'Engine Reverse Eng', JSON.stringify(pr.data).slice(0,150));
  const prid = pr.data.id;
  const plist = await j('GET', '/api/projects', token);
  check('project list has open_tasks + activity_count', plist.data?.data?.[0] && 'activity_count' in plist.data?.data?.[0] && 'open_tasks' in plist.data?.data?.[0]);
  check('update project progress', (await j('PUT', `/api/projects/${prid}`, token, { project_name: 'Engine RE', status: 'in_progress', progress_percent: 75, assigned_to: [] })).data.progress_percent === 75);
  check('progress > 100 rejected', (await j('PUT', `/api/projects/${prid}`, token, { project_name: 'x', status: 'in_progress', progress_percent: 150, assigned_to: [] })).status === 400);

  // TASKS
  results.push('[TASKS]');
  const tk = await j('POST', '/api/tasks', token, { task_name: 'Mesh cleanup', project_id: prid, priority: 'high', status: 'in_progress' });
  check('create task', tk.data.task_name === 'Mesh cleanup');
  check('invalid priority rejected', (await j('POST', '/api/tasks', token, { task_name: 'x', priority: 'ultra' })).status === 400);
  check('update task', (await j('PUT', `/api/tasks/${tk.data.id}`, token, { task_name: 'Mesh cleanup', project_id: prid, priority: 'high', status: 'completed' })).data.status === 'completed');

  // QUALITY / DISPATCH
  results.push('[QUALITY/DISPATCH]');
  check('create quality', (await j('POST', '/api/quality', token, { project_id: prid, part_name: 'Bracket', report_number: 'QC-1', quality_status: 'in_review' })).data.report_number === 'QC-1');
  check('create dispatch', (await j('POST', '/api/dispatch', token, { project_id: prid, client_id: clid, tracking_number: 'TRK-9', courier: 'BlueDart', status: 'ready' })).data.tracking_number === 'TRK-9');

  // NOTICES / UPDATES / ACTIVITIES
  results.push('[NOTICES/UPDATES/ACTIVITIES]');
  check('create notice', (await j('POST', '/api/notices', token, { title: 'Maintenance', content: 'Server down 6pm', urgent: true })).data.title === 'Maintenance');
  check('notices list wrapped', Array.isArray((await j('GET','/api/notices',token)).data?.data));
  check('create dept update', (await j('POST', '/api/updates', token, { department: 'Quality', message: 'New CMM calibrated' })).data.message === 'New CMM calibrated');
  const acts = await j('GET', '/api/activities', token);
  check('activities recorded with normalized shape', acts.data?.data?.[0] && 'action' in acts.data?.data?.[0] && 'user_name' in acts.data?.data?.[0]);
  check('departments include updates_count', (await j('GET','/api/departments',token)).data?.data||[].some(d => 'updates_count' in d));

  // REPORTS / SEARCH / DASHBOARD
  results.push('[REPORTS/SEARCH/DASHBOARD]');
  check('reports summary has totals', !!(await j('GET', '/api/reports/summary', token)).data.totals);
  check('reports root works too', !!(await j('GET', '/api/reports', token)).data.totals);
  check('search finds project', JSON.stringify((await j('GET', '/api/search?q=Engine', token)).data).includes('Engine'));
  check('users lookup (non-sensitive)', ((await j('GET','/api/users/lookup',token)).data||[]).some(u => u.name));
  const dash = await j('GET', '/api/dashboard', token);
  check('dashboard stats + breakdowns', dash.data.stats && dash.data.projectStatusBreakdown && Array.isArray(dash.data.recentActivities));

  // USERS / AUTHORIZATION
  results.push('[USERS/AUTHZ]');
  const emp = await j('POST', '/api/users', token, { name: 'Asha Worker', username: 'asha', password: 'Worker123', role: 'employee' });
  check('manager creates employee', emp.data.username === 'asha', JSON.stringify(emp.data));
  check('weak password rejected', (await j('POST', '/api/users', token, { name: 'Y', username: 'y1', password: 'short', role: 'employee' })).status === 400);
  const empLogin = await j('POST', '/api/auth/login', null, { username: 'asha', password: 'Worker123' });
  const empToken = empLogin.data.token;
  check('new employee must_change_password=true', empLogin.data.user.must_change_password === true);
  check('employee CANNOT create project (403)', (await j('POST', '/api/projects', empToken, { project_number: 'P9', project_name: 'x', status: 'pending', assigned_to: [] })).status === 403);
  check('employee CANNOT list users (403)', (await j('GET', '/api/users', empToken)).status === 403);
  check('employee CANNOT edit unassigned task (403)', (await j('PUT', `/api/tasks/${tk.data.id}`, empToken, { task_name: 'hack', project_id: prid, priority: 'low', status: 'blocked' })).status === 403);
  check('employee change-password works', (await j('POST', '/api/auth/change-password', empToken, { currentPassword: 'Worker123', newPassword: 'NewPass123' })).status === 200);

  // 404
  results.push('[MISC]');
  check('api 404 returns json', (await j('GET', '/api/nope', token)).status === 404);

  console.log(results.join('\n'));
  console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
  process.exit(fail > 0 ? 1 : 0);
})().catch(e => { console.error('TEST CRASH', e); process.exit(2); });
