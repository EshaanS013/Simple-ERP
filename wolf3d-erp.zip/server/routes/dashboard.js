const express = require('express');
const { pool } = require('../db/pool');
const { authGuard } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');
const { getOnlineUsers } = require('../socket/socket');

const router = express.Router();
router.use(authGuard);

router.get('/', asyncHandler(async (req, res) => {
  const [
    activeProjects, openTasks, employees, todaysDeliveries, delayedProjects,
    inProgress, completedProjects, workOrders, pendingWorkOrders, clients,
    projectStatus, taskStatus, recentNotices, recentActivities
  ] = await Promise.all([
    pool.query("SELECT COUNT(*)::int c FROM projects WHERE status != 'cancelled'"),
    pool.query("SELECT COUNT(*)::int c FROM tasks WHERE status NOT IN ('completed','cancelled')"),
    pool.query("SELECT COUNT(*)::int c FROM users WHERE status = 'active'"),
    pool.query("SELECT COUNT(*)::int c FROM dispatch_records WHERE dispatch_date = CURRENT_DATE AND status != 'delivered'"),
    pool.query("SELECT COUNT(*)::int c FROM projects WHERE deadline < CURRENT_DATE AND status NOT IN ('completed','delivered','cancelled')"),
    pool.query("SELECT COUNT(*)::int c FROM projects WHERE status = 'in_progress'"),
    pool.query("SELECT COUNT(*)::int c FROM projects WHERE status IN ('completed','delivered')"),
    pool.query('SELECT COUNT(*)::int c FROM work_orders'),
    pool.query("SELECT COUNT(*)::int c FROM work_orders WHERE status = 'pending'"),
    pool.query('SELECT COUNT(*)::int c FROM clients'),
    pool.query('SELECT status, COUNT(*)::int count FROM projects GROUP BY status'),
    pool.query('SELECT status, COUNT(*)::int count FROM tasks GROUP BY status'),
    pool.query('SELECT id, title, urgent, pinned, created_at FROM notices ORDER BY pinned DESC, created_at DESC LIMIT 5'),
    pool.query(`SELECT a.id, a.action, a.module, a.details, a.entity_type, a.entity_id, a.project_id,
                       a.created_at, u.name AS user_name
                FROM activities a LEFT JOIN users u ON u.id = a.user_id
                ORDER BY a.created_at DESC LIMIT 12`)
  ]);

  res.json({
    stats: {
      activeProjects: activeProjects.rows[0].c,
      openTasks: openTasks.rows[0].c,
      employees: employees.rows[0].c,
      todaysDeliveries: todaysDeliveries.rows[0].c,
      delayedProjects: delayedProjects.rows[0].c,
      projectsInProgress: inProgress.rows[0].c,
      completedProjects: completedProjects.rows[0].c,
      totalWorkOrders: workOrders.rows[0].c,
      pendingWorkOrders: pendingWorkOrders.rows[0].c,
      totalClients: clients.rows[0].c,
      onlineUsers: getOnlineUsers()
    },
    projectStatusBreakdown: projectStatus.rows,
    taskStatusBreakdown: taskStatus.rows,
    recentNotices: recentNotices.rows,
    recentActivities: recentActivities.rows
  });
}));

module.exports = router;
