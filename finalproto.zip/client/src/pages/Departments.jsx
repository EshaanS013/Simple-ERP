import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Network, MessageSquare, Users, FolderKanban, Factory, Plus, Pencil, Trash2, ChevronRight } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PageHeader, LoadingState, ErrorState, EmptyState, Modal, ConfirmDialog, Field, Input, Textarea } from '../components/ui';

export default function Departments() {
  const navigate = useNavigate();
  const { isManager } = useAuth();
  const toast = useToast();
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editing, setEditing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [form, setForm] = useState({ name: '', description: '' });
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try { setDepartments((await Api.departments()).data || []); }
    catch (e) { setError(e.message); } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const refresh = () => load();
    const evs = ['department_created', 'department_updated', 'department_deleted', 'update_created'];
    evs.forEach((e) => socket.on(e, refresh));
    return () => evs.forEach((e) => socket.off(e, refresh));
  }, [load]);

  const openCreate = () => { setForm({ name: '', description: '' }); setEditing({}); };
  const openRename = (e, d) => { e.stopPropagation(); setForm({ name: d.name, description: d.description || '' }); setEditing(d); };
  const openDelete = (e, d) => { e.stopPropagation(); setDeleting(d); };

  const save = async () => {
    const name = form.name.trim();
    if (!name) { toast.error('Workspace name is required'); return; }
    setBusy(true);
    try {
      if (editing.id) { await Api.update('departments', editing.id, { name, description: form.description }); toast.success('Workspace updated'); }
      else { await Api.create('departments', { name, description: form.description }); toast.success('Workspace created'); }
      setEditing(null); load();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const confirmDelete = async () => {
    setBusy(true);
    try { await Api.remove('departments', deleting.id); toast.success('Workspace deleted'); setDeleting(null); load(); }
    catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const Stat = ({ icon: Icon, n }) => <span className="flex items-center gap-1"><Icon className="h-3.5 w-3.5" /> {n || 0}</span>;

  return (
    <section>
      <PageHeader title="Workspaces" subtitle="Each department is an operational workspace — production, projects, tasks, and its own feed.">
        {isManager && <button className="btn-primary" onClick={openCreate}><Plus className="h-4 w-4" /> Add workspace</button>}
      </PageHeader>

      {loading ? <LoadingState /> : error ? <ErrorState message={error} onRetry={load} /> : departments.length === 0 ? (
        <div className="card"><EmptyState title="No workspaces" message={isManager ? 'Create your first workspace.' : 'You are not a member of any workspace yet. Ask a manager to add you.'}
          action={isManager ? <button className="btn-primary" onClick={openCreate}><Plus className="h-4 w-4" /> Add workspace</button> : null} /></div>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {departments.map((d) => (
            <div key={d.id} onClick={() => navigate(`/departments/${d.id}`)}
              className="card group cursor-pointer p-4 transition hover:border-brand-200 hover:shadow-pop">
              <div className="flex items-start gap-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-brand-600"><Network className="h-5 w-5" /></div>
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold text-slate-900">{d.name}</p>
                  {d.description && <p className="truncate text-xs text-slate-500">{d.description}</p>}
                </div>
                {isManager ? (
                  <div className="flex items-center gap-1 opacity-0 transition group-hover:opacity-100">
                    <button title="Edit" onClick={(e) => openRename(e, d)} className="btn-ghost btn-sm"><Pencil className="h-4 w-4" /></button>
                    <button title="Delete" onClick={(e) => openDelete(e, d)} className="btn-ghost btn-sm text-red-500 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                  </div>
                ) : <ChevronRight className="h-4 w-4 text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-brand-500" />}
              </div>
              <div className="mt-3 flex items-center gap-4 border-t border-slate-100 pt-3 text-xs text-slate-500">
                <Stat icon={Factory} n={d.production_count} />
                <Stat icon={Users} n={d.member_count} />
                <Stat icon={MessageSquare} n={d.updates_count} />
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Edit workspace' : 'Add workspace'} size="sm"
        footer={<><button className="btn-secondary" onClick={() => setEditing(null)} disabled={busy}>Cancel</button><button className="btn-primary" onClick={save} disabled={busy}>{busy ? 'Saving…' : editing?.id ? 'Save' : 'Create'}</button></>}>
        <div className="space-y-3">
          <Field label="Workspace name" required><Input value={form.name} autoFocus onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} onKeyDown={(e) => e.key === 'Enter' && save()} placeholder="e.g. Production" /></Field>
          <Field label="Description"><Textarea rows={2} value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} placeholder="Optional" /></Field>
        </div>
      </Modal>

      <ConfirmDialog open={!!deleting} busy={busy} onClose={() => setDeleting(null)} onConfirm={confirmDelete}
        title="Delete workspace?" message={deleting ? `“${deleting.name}” will be removed. Its feed is deleted and its production, projects and tasks become unassigned (records are not deleted).` : ''} />
    </section>
  );
}
