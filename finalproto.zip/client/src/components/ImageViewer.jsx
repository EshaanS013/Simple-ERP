import { useState, useEffect, useCallback, useRef } from 'react';
import { X, ZoomIn, ZoomOut, ChevronLeft, ChevronRight, RotateCcw } from 'lucide-react';

// Lightweight image viewer: centered modal (~90% of screen), zoom (buttons +
// wheel), pan while zoomed, prev/next across multiple images, close via button,
// ESC, or clicking the backdrop. Aspect ratio is always preserved.
export default function ImageViewer({ images = [], index = 0, onClose }) {
  const [i, setI] = useState(index);
  const [scale, setScale] = useState(1);
  const [tx, setTx] = useState(0);
  const [ty, setTy] = useState(0);
  const drag = useRef(null);

  const reset = useCallback(() => { setScale(1); setTx(0); setTy(0); }, []);
  const clampScale = (s) => Math.min(6, Math.max(1, s));
  const go = useCallback((delta) => { setI((p) => { const n = (p + delta + images.length) % images.length; return n; }); reset(); }, [images.length, reset]);

  useEffect(() => { setI(index); reset(); }, [index, reset]);
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
      else if (e.key === 'ArrowRight' && images.length > 1) go(1);
      else if (e.key === 'ArrowLeft' && images.length > 1) go(-1);
      else if (e.key === '+' || e.key === '=') setScale((s) => clampScale(s + 0.3));
      else if (e.key === '-') setScale((s) => clampScale(s - 0.3));
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose, go, images.length]);

  const onWheel = (e) => { e.preventDefault(); setScale((s) => clampScale(s + (e.deltaY < 0 ? 0.25 : -0.25))); };
  const onDown = (e) => { if (scale <= 1) return; drag.current = { x: e.clientX - tx, y: e.clientY - ty }; };
  const onMove = (e) => { if (!drag.current) return; setTx(e.clientX - drag.current.x); setTy(e.clientY - drag.current.y); };
  const onUp = () => { drag.current = null; };

  if (!images.length) return null;
  const src = images[i];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm"
      onClick={onClose} onMouseMove={onMove} onMouseUp={onUp} onMouseLeave={onUp}>
      {/* Toolbar */}
      <div className="absolute right-3 top-3 z-10 flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
        <button className="rounded-full bg-white/10 p-2 text-white hover:bg-white/20" title="Zoom out" onClick={() => setScale((s) => clampScale(s - 0.3))}><ZoomOut className="h-5 w-5" /></button>
        <span className="min-w-[3rem] text-center text-sm font-medium text-white/90">{Math.round(scale * 100)}%</span>
        <button className="rounded-full bg-white/10 p-2 text-white hover:bg-white/20" title="Zoom in" onClick={() => setScale((s) => clampScale(s + 0.3))}><ZoomIn className="h-5 w-5" /></button>
        <button className="rounded-full bg-white/10 p-2 text-white hover:bg-white/20" title="Reset" onClick={reset}><RotateCcw className="h-5 w-5" /></button>
        <button className="ml-1 rounded-full bg-white/10 p-2 text-white hover:bg-white/20" title="Close (Esc)" onClick={onClose}><X className="h-5 w-5" /></button>
      </div>

      {/* Prev / Next */}
      {images.length > 1 && (
        <>
          <button className="absolute left-3 top-1/2 z-10 -translate-y-1/2 rounded-full bg-white/10 p-2.5 text-white hover:bg-white/20" title="Previous (←)" onClick={(e) => { e.stopPropagation(); go(-1); }}><ChevronLeft className="h-6 w-6" /></button>
          <button className="absolute right-3 top-1/2 z-10 -translate-y-1/2 rounded-full bg-white/10 p-2.5 text-white hover:bg-white/20" title="Next (→)" onClick={(e) => { e.stopPropagation(); go(1); }}><ChevronRight className="h-6 w-6" /></button>
          <div className="absolute bottom-4 left-1/2 z-10 -translate-x-1/2 rounded-full bg-white/10 px-3 py-1 text-xs text-white/90">{i + 1} / {images.length}</div>
        </>
      )}

      {/* Image stage (~90% of screen) */}
      <div className="flex h-[90vh] w-[90vw] items-center justify-center overflow-hidden" onClick={(e) => e.stopPropagation()} onWheel={onWheel}>
        <img
          src={src}
          alt="Part preview"
          draggable={false}
          onMouseDown={onDown}
          className="max-h-full max-w-full select-none object-contain transition-transform duration-75"
          style={{ transform: `translate(${tx}px, ${ty}px) scale(${scale})`, cursor: scale > 1 ? (drag.current ? 'grabbing' : 'grab') : 'default' }}
        />
      </div>
    </div>
  );
}
