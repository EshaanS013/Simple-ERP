const express = require('express');
const { pool } = require('../db/pool');
const { authGuard } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler } = require('../middleware/errorHandler');
const { emitEvent } = require('../socket/socket');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { project_id, task_id, production_id, department_id } = req.query;
  const conditions = []; const values = []; let i = 1;
  if (project_id) { conditions.push(`c.project_id = $${i++}`); values.push(project_id); }
  if (task_id) { conditions.push(`c.task_id = $${i++}`); values.push(task_id); }
  if (production_id) { conditions.push(`c.production_id = $${i++}`); values.push(production_id); }
  if (department_id) { conditions.push(`c.department_id = $${i++}`); values.push(department_id); }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const { rows } = await pool.query(
    `SELECT c.*, u.name AS author_name FROM comments c
     LEFT JOIN users u ON u.id = c.author_id ${where} ORDER BY c.created_at ASC`, values);
  res.json({ data: rows });
}));

router.post('/', validate({ body: schemas.createComment }), asyncHandler(async (req, res) => {
  const { project_id, task_id, production_id, department_id, body } = req.body;
  const { rows } = await pool.query(
    `INSERT INTO comments (author_id, project_id, task_id, production_id, department_id, body)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [req.user.id, project_id || null, task_id || null, production_id || null, department_id || null, body]
  );
  const comment = { ...rows[0], author_name: req.user.name };
  emitEvent('comment_added', comment);
  res.status(201).json(comment);
}));

// Delete a comment — the author or any manager.
router.delete('/:id', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rows } = await pool.query('SELECT author_id FROM comments WHERE id = $1', [req.params.id]);
  if (!rows.length) return res.status(404).json({ error: 'Comment not found' });
  if (rows[0].author_id !== req.user.id && req.user.role !== 'manager') {
    return res.status(403).json({ error: 'You can only delete your own comments' });
  }
  await pool.query('DELETE FROM comments WHERE id = $1', [req.params.id]);
  emitEvent('comment_deleted', { id: Number(req.params.id) });
  res.json({ success: true });
}));

module.exports = router;
