import { useState, Suspense } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import { useAuth } from '../context/AuthContext';
import { LoadingState } from './ui';
import AccessDenied from '../pages/AccessDenied';

// Full-screen loader while the session is being restored.
function SessionGate({ children }) {
  const { loading } = useAuth();
  if (loading) {
    return <div className="flex h-screen items-center justify-center"><LoadingState label="Loading WOLF3D ERP…" /></div>;
  }
  return children;
}

// Requires an authenticated session; redirects to login otherwise.
export function ProtectedRoute({ managerOnly = false }) {
  const { user, loading, isManager, mustChangePassword } = useAuth();
  const location = useLocation();
  if (loading) return <div className="flex h-screen items-center justify-center"><LoadingState /></div>;
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  // Force first-login password change before anything else.
  if (mustChangePassword && location.pathname !== '/change-password') {
    return <Navigate to="/change-password" replace />;
  }
  if (managerOnly && !isManager) return <Navigate to="/" replace />;
  return <Outlet />;
}

// Renders children only when `allowed`; otherwise shows an Access Denied page
// (so a manually-typed URL is blocked rather than silently redirected).
export function RequireAccess({ allowed, module, children }) {
  if (!allowed) return <AccessDenied module={module} />;
  return children;
}

export function AppLayout() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  return (
    <SessionGate>
      <div className="flex h-screen overflow-hidden bg-slate-50">
        {/* Desktop sidebar */}
        <div className="hidden lg:block"><Sidebar /></div>

        {/* Mobile drawer */}
        {drawerOpen && (
          <div className="fixed inset-0 z-40 lg:hidden">
            <div className="absolute inset-0 bg-slate-900/40" onClick={() => setDrawerOpen(false)} />
            <div className="absolute left-0 top-0 h-full animate-scale-in"><Sidebar onNavigate={() => setDrawerOpen(false)} /></div>
          </div>
        )}

        <div className="flex min-w-0 flex-1 flex-col">
          <Topbar onOpenSidebar={() => setDrawerOpen(true)} />
          <main className="flex-1 overflow-y-auto px-4 py-6 sm:px-6 lg:px-8">
            <div className="mx-auto max-w-7xl">
              <Suspense fallback={<div className="py-16"><LoadingState /></div>}>
                <Outlet />
              </Suspense>
            </div>
          </main>
        </div>
      </div>
    </SessionGate>
  );
}
