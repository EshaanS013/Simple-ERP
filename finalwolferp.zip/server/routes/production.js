const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { pool, withTransaction } = require('../db/pool');
const { authGuard } = require('../middleware/auth');
const { attachScope } = require('../utils/scope');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound, forbidden, badRequest, ApiError } = require('../middleware/errorHandler');
const { recordActivity } = require('../utils/activity');
const { emitEvent } = require('../socket/socket');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const prod = require('../utils/production');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard, attachScope);

// ---- Part-image uploads (stored on the uploads volume) -----------------
const UPLOADS_DIR = process.env.UPLOADS_DIR || path.join(__dirname, '..', 'uploads');
try { fs.mkdirSync(UPLOADS_DIR, { recursive: true }); } catch { /* exists */ }
const imageUpload = multer({
  storage: multer.diskStorage({
    destination: (req, file, cb) => cb(null, UPLOADS_DIR),
    filename: (req, file, cb) => {
      const ext = (path.extname(file.originalname || '').toLowerCase().match(/^\.[a-z0-9]{1,5}$/) || ['.img'])[0];
      cb(null, `prod_${req.params.id}_${Date.now()}${ext}`);
    }
  }),
  limits: { fileSize: 5 * 1024 * 1024, files: 1 },
  fileFilter: (req, file, cb) => {
    if (/^image\/(png|jpe?g|gif|webp|bmp)$/.test(file.mimetype)) cb(null, true);
    else cb(new ApiError(400, 'Only image files (png, jpg, gif, webp) are allowed'));
  }
});
// Part image is a BDE/Sales input — Sales or managers/admins may set it.
function canEditImage(req, res, next) {
  if (req.isManager || prod.editableFields(req).has('part_name')) return next();
  next(new ApiError(403, 'Only Sales or managers can set the part image'));
}

// Field-permission metadata for the current user (drives read-only cells in the UI).
router.get('/meta', asyncHandler(async (req, res) => {
  res.json({
    all: prod.ALL,
    sales: prod.SALES,
    production: prod.PRODUCTION,
    quality: prod.QUALITY,
    accounts: prod.ACCOUNTS,
    editable: [...prod.editableFields(req)]
  });
}));

const SORTABLE = new Set(['work_order_number', 'client_name', 'part_name', 'technology', 'order_date', 'dispatch_date', 'created_at']);

// Strip fields a user isn't allowed to see from a record.
function project(row, visible) {
  const out = { id: row.id, department_id: row.department_id, department_name: row.department_name,
    pipeline: row.pipeline, last_updated_by_name: row.last_updated_by_name, updated_at: row.updated_at, created_at: row.created_at };
  for (const f of prod.ALL) if (visible.has(f)) out[f] = row[f];
  return out;
}

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  if (!prod.canSeeProduction(req)) return res.json(paginatedResponse([], 0, 1, 50));
  const { page, pageSize, offset } = getPagination(req.query, 50);
  const { search, stage, department_id } = req.query;
  const where = []; const params = []; let i = 1;
  if (department_id) { where.push(`p.department_id = $${i++}`); params.push(department_id); }
  if (search) {
    where.push(`(p.work_order_number ILIKE $${i} OR p.client_name ILIKE $${i} OR p.part_name ILIKE $${i} OR p.technology ILIKE $${i})`);
    params.push(`%${search}%`); i++;
  }
  // Filter by derived pipeline position.
  if (stage) { where.push(`(${prod.DERIVED_STAGE.replace(/\n/g, ' ')}) = $${i++}`); params.push(stage); }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const sortCol = SORTABLE.has(req.query.sort) ? req.query.sort : 'created_at';
  const dir = req.query.dir === 'asc' ? 'ASC' : 'DESC';

  const total = await pool.query(`SELECT COUNT(*)::int c FROM production_records p ${whereSql}`, params);
  const rows = await pool.query(
    `SELECT p.*, d.name AS department_name, (${prod.DERIVED_STAGE}) AS pipeline
       FROM production_records p LEFT JOIN departments d ON d.id = p.department_id
       ${whereSql} ORDER BY p.${sortCol} ${dir} NULLS LAST, p.id DESC LIMIT $${i++} OFFSET $${i++}`,
    [...params, pageSize, offset]
  );
  const visible = prod.visibleFields(req);
  res.json(paginatedResponse(rows.rows.map((r) => project(r, visible)), total.rows[0].c, page, pageSize));
}));

router.post('/', validate({ body: schemas.createProduction }), asyncHandler(async (req, res) => {
  if (!prod.canCreate(req)) throw forbidden('Only Sales or managers can create a new work order');
  const editable = prod.editableFields(req);
  const b = req.body;
  // Only accept fields the user is allowed to edit (plus part_name which is required).
  const cols = ['department_id', 'part_name'];
  const vals = [b.department_id ?? null, b.part_name];
  for (const f of prod.ALL) {
    if (f === 'part_name') continue;
    if (f in b && b[f] !== undefined) {
      if (!editable.has(f)) throw forbidden(`You don't have permission to set "${f}"`);
      cols.push(f); vals.push(b[f] === '' ? null : b[f]);
    }
  }
  const placeholders = cols.map((_, idx) => `$${idx + 1}`).join(',');
  const { rows } = await pool.query(
    `INSERT INTO production_records (${cols.join(',')}, created_by, last_updated_by, last_updated_by_name)
     VALUES (${placeholders}, $${cols.length + 1}, $${cols.length + 1}, $${cols.length + 2}) RETURNING *, (${prod.DERIVED_STAGE}) AS pipeline`,
    [...vals, req.user.id, req.user.name]
  );
  emitEvent('production_created', { id: rows[0].id });
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'added a production record', module: 'Production', details: rows[0].part_name, entityType: 'production', entityId: rows[0].id, departmentId: rows[0].department_id });
  res.status(201).json(project(rows[0], prod.visibleFields(req)));
}));

router.put('/:id', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  if (!prod.canSeeProduction(req)) throw forbidden('You are not part of the production workflow');
  const editable = prod.editableFields(req);
  const result = await withTransaction(async (client) => {
    const ex = await client.query('SELECT * FROM production_records WHERE id = $1 FOR UPDATE', [req.params.id]);
    if (ex.rowCount === 0) return null;
    const before = ex.rows[0];
    const changes = [];
    for (const f of prod.ALL) {
      if (f in req.body) {
        if (!editable.has(f)) throw forbidden(`You don't have permission to edit "${f}"`);
        const nv = req.body[f] === '' ? null : req.body[f];
        const ov = before[f] === undefined ? null : before[f];
        if (String(ov ?? '') !== String(nv ?? '')) changes.push({ field: f, old: ov, new: nv });
      }
    }
    if (changes.length === 0) {
      const same = await client.query(`SELECT *, (${prod.DERIVED_STAGE}) AS pipeline FROM production_records WHERE id=$1`, [req.params.id]);
      return { row: same.rows[0], changes: [] };
    }
    const sets = changes.map((c, idx) => `${c.field} = $${idx + 1}`);
    const params = changes.map((c) => c.new);
    params.push(req.user.id, req.user.name, req.params.id);
    const upd = await client.query(
      `UPDATE production_records SET ${sets.join(', ')}, last_updated_by=$${params.length - 2}, last_updated_by_name=$${params.length - 1}
       WHERE id=$${params.length} RETURNING *, (${prod.DERIVED_STAGE}) AS pipeline`, params
    );
    for (const c of changes) {
      await client.query(
        'INSERT INTO production_audit (production_id, field, old_value, new_value, changed_by, changed_by_name) VALUES ($1,$2,$3,$4,$5,$6)',
        [req.params.id, c.field, c.old, c.new, req.user.id, req.user.name]
      );
    }
    return { row: upd.rows[0], changes };
  });
  if (!result) throw notFound('Production record not found');
  emitEvent('production_updated', { id: Number(req.params.id) });
  if (result.changes.length) {
    await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'updated a production record', module: 'Production', details: result.row.part_name, entityType: 'production', entityId: result.row.id, departmentId: result.row.department_id });
  }
  res.json(project(result.row, prod.visibleFields(req)));
}));

// ---- Part image: upload / replace ----
router.post('/:id(\\d+)/image', validate({ params: schemas.idParam }), canEditImage, imageUpload.single('image'), asyncHandler(async (req, res) => {
  if (!req.file) throw badRequest('No image uploaded');
  const ex = await pool.query('SELECT part_image FROM production_records WHERE id = $1', [req.params.id]);
  if (ex.rowCount === 0) { fs.unlink(req.file.path, () => {}); throw notFound('Production record not found'); }
  const old = ex.rows[0].part_image;
  if (old && old !== req.file.filename) fs.unlink(path.join(UPLOADS_DIR, path.basename(old)), () => {});
  await pool.query('UPDATE production_records SET part_image = $1, updated_at = NOW() WHERE id = $2', [req.file.filename, req.params.id]);
  emitEvent('production_updated', { id: Number(req.params.id) });
  res.json({ part_image: req.file.filename });
}));

// ---- Part image: remove ----
router.delete('/:id(\\d+)/image', validate({ params: schemas.idParam }), canEditImage, asyncHandler(async (req, res) => {
  const ex = await pool.query('SELECT part_image FROM production_records WHERE id = $1', [req.params.id]);
  if (ex.rowCount === 0) throw notFound('Production record not found');
  if (ex.rows[0].part_image) fs.unlink(path.join(UPLOADS_DIR, path.basename(ex.rows[0].part_image)), () => {});
  await pool.query('UPDATE production_records SET part_image = NULL WHERE id = $1', [req.params.id]);
  emitEvent('production_updated', { id: Number(req.params.id) });
  res.json({ success: true });
}));

router.delete('/:id', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  // Only managers/admins (or Sales, who own the work order) may delete a row.
  if (!req.isManager && !prod.editableFields(req).has('work_order_number')) throw forbidden('Only Sales, managers or admins can delete a production row');
  const ex = await pool.query('SELECT part_name, department_id FROM production_records WHERE id = $1', [req.params.id]);
  if (ex.rowCount === 0) throw notFound('Production record not found');
  await pool.query('DELETE FROM production_records WHERE id = $1', [req.params.id]);
  emitEvent('production_deleted', { id: Number(req.params.id) });
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'deleted a production record', module: 'Production', details: ex.rows[0].part_name, entityType: 'production', entityId: Number(req.params.id), departmentId: ex.rows[0].department_id });
  res.json({ success: true });
}));

// Change history for a record (managers/admins).
router.get('/:id/history', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  if (!req.isManager) throw forbidden('Only managers and admins can view change history');
  const { rows } = await pool.query(
    'SELECT field, old_value, new_value, changed_by_name, changed_at FROM production_audit WHERE production_id=$1 ORDER BY changed_at DESC LIMIT 200',
    [req.params.id]
  );
  res.json({ data: rows });
}));

module.exports = router;
