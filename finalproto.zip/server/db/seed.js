const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { pool } = require('./pool');
const config = require('../config/env');

// Operational workspaces (rename/add/remove later in the app).
const DEFAULT_DEPARTMENTS = ['Sales', 'Production', 'Design', 'Quality', 'Dispatch', 'Accounts'];

// Machines from the machine-utilisation sheet.
const DEFAULT_MACHINES = [
  { name: 'Uniontech Lite 600', technology: 'SLA', measure: 'volume_cc' },
  { name: 'ELEGOO 1', technology: 'DLP', measure: 'volume_cc' },
  { name: 'ELEGOO 2', technology: 'DLP', measure: 'volume_cc' },
  { name: 'ELEGOO 3', technology: 'DLP', measure: 'volume_cc' },
  { name: 'ELEGOO 4', technology: 'DLP', measure: 'volume_cc' },
  { name: 'Centauri Carbon 1', technology: 'FDM', measure: 'weight_gms' },
  { name: 'Centauri Carbon 2', technology: 'FDM', measure: 'weight_gms' },
  { name: 'Neptune 1', technology: 'FDM', measure: 'weight_gms' },
  { name: 'Neptune 2', technology: 'FDM', measure: 'weight_gms' }
];

async function seedDepartments() {
  for (const name of DEFAULT_DEPARTMENTS) {
    await pool.query('INSERT INTO departments (name) VALUES ($1) ON CONFLICT (name) DO NOTHING', [name]);
  }
}

async function seedMachines() {
  for (const m of DEFAULT_MACHINES) {
    await pool.query(
      'INSERT INTO machines (name, technology, measure) VALUES ($1,$2,$3) ON CONFLICT (name) DO NOTHING',
      [m.name, m.technology, m.measure]
    );
  }
}

async function seedAdmin() {
  const { rowCount } = await pool.query("SELECT id FROM users WHERE role IN ('admin','manager') LIMIT 1");
  if (rowCount > 0) return;

  let password = config.ADMIN_PASSWORD;
  let generated = false;
  if (!password) {
    password = crypto.randomBytes(12).toString('base64').replace(/[^a-zA-Z0-9]/g, '').slice(0, 16) + 'A1!';
    generated = true;
  }

  const passwordHash = await bcrypt.hash(password, config.BCRYPT_ROUNDS);
  const { rows } = await pool.query(
    `INSERT INTO users (name, username, password_hash, role, status, must_change_password)
     VALUES ($1,$2,$3,'admin','active',$4) RETURNING id`,
    [config.ADMIN_NAME || 'Administrator', config.ADMIN_USERNAME || 'admin', passwordHash, generated]
  );
  const adminId = rows[0].id;

  // Managers see everything, but assign membership to all departments anyway.
  await pool.query(
    `INSERT INTO user_departments (user_id, department_id)
       SELECT $1, id FROM departments ON CONFLICT DO NOTHING`,
    [adminId]
  );

  console.log('====================================================');
  console.log(' WOLF3D ERP — bootstrap administrator account created');
  console.log(`   username: ${config.ADMIN_USERNAME || 'admin'}`);
  if (generated) console.log(`   password: ${password}  (CHANGE ON FIRST LOGIN)`);
  else console.log('   password: (from ADMIN_PASSWORD env var)');
  console.log('====================================================');
}

async function seed() {
  await seedDepartments();
  await seedMachines();
  await seedAdmin();
}

module.exports = { seed };
