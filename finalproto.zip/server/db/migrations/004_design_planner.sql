-- 004_design_planner.sql
-- Daily Design Planner: each design_updates row is a per-designer, per-day
-- planner entry (mirrors the company's Design Daily Update spreadsheet).
-- Idempotent (safe to re-run / apply to existing databases).

ALTER TABLE design_updates ADD COLUMN IF NOT EXISTS target TEXT;
ALTER TABLE design_updates ADD COLUMN IF NOT EXISTS target_status TEXT NOT NULL DEFAULT 'awaiting';
ALTER TABLE design_updates ADD COLUMN IF NOT EXISTS delivery_status TEXT NOT NULL DEFAULT 'awaiting';

CREATE INDEX IF NOT EXISTS idx_design_updates_date ON design_updates(entry_date DESC);
CREATE INDEX IF NOT EXISTS idx_design_updates_designer ON design_updates(designer_id);
