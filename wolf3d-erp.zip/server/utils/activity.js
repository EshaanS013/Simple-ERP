const { pool } = require('../db/pool');
const { emitEvent } = require('../socket/socket');

// Records a business activity to the DB and broadcasts it to all clients as a
// single, consistently shaped `activity_created` event. This is the ONLY source
// of activity-feed events (socket connect/disconnect no longer pollute the feed).
async function recordActivity({ userId, userName, action, module, details, entityType, entityId, projectId }) {
  const { rows } = await pool.query(
    `INSERT INTO activities (user_id, action, module, details, entity_type, entity_id, project_id)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING id, user_id, action, module, details, entity_type, entity_id, project_id, created_at`,
    [userId || null, action, module, details || null, entityType || null, entityId || null, projectId || null]
  );

  const activity = { ...rows[0], user_name: userName || null };

  try {
    emitEvent('activity_created', activity);
  } catch (err) {
    // Socket not ready yet (e.g. during boot) — persistence already succeeded.
  }

  return activity;
}

module.exports = { recordActivity };
