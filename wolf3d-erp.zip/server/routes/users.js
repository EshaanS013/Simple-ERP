const express = require('express');
const bcrypt = require('bcryptjs');
const { pool } = require('../db/pool');
const config = require('../config/env');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound, badRequest } = require('../middleware/errorHandler');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

// Lightweight lookup for assignee dropdowns — available to all authenticated
// users, exposes only id/name/role (not usernames or login data).
router.get('/lookup', asyncHandler(async (req, res) => {
  const { rows } = await pool.query(
    "SELECT id, name, role FROM users WHERE status = 'active' ORDER BY name"
  );
  res.json(rows);
}));

router.get('/me', asyncHandler(async (req, res) => {
  res.json(req.user);
}));

router.get('/', managerOnly, validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query);
  const { search, status } = req.query;
  const conditions = [];
  const values = [];
  let i = 1;
  if (search) { conditions.push(`(u.name ILIKE $${i} OR u.username ILIKE $${i})`); values.push(`%${search}%`); i++; }
  if (status) { conditions.push(`u.status = $${i}`); values.push(status); i++; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  const totalRes = await pool.query(`SELECT COUNT(*)::int AS count FROM users u ${where}`, values);
  const rows = await pool.query(
    `SELECT u.id, u.name, u.username, u.role, u.status, u.last_login, u.department_id, d.name AS department
     FROM users u LEFT JOIN departments d ON d.id = u.department_id
     ${where} ORDER BY u.name LIMIT $${i} OFFSET $${i + 1}`,
    [...values, pageSize, offset]
  );
  res.json(paginatedResponse(rows.rows, totalRes.rows[0].count, page, pageSize));
}));

router.post('/', managerOnly, validate({ body: schemas.createUser }), asyncHandler(async (req, res) => {
  const { name, username, password, role, department_id } = req.body;
  const passwordHash = await bcrypt.hash(password, config.BCRYPT_ROUNDS);
  const { rows } = await pool.query(
    `INSERT INTO users (name, username, password_hash, role, department_id, must_change_password)
     VALUES ($1, $2, $3, $4, $5, TRUE)
     RETURNING id, name, username, role, status, department_id`,
    [name, username, passwordHash, role, department_id || null]
  );
  res.status(201).json(rows[0]);
}));

router.put('/:id', managerOnly, validate({ params: schemas.idParam, body: schemas.updateUser }), asyncHandler(async (req, res) => {
  const { id } = req.params;
  const { name, role, status, department_id } = req.body;
  // Prevent locking out the last active manager.
  if (Number(id) === req.user.id && (role !== 'manager' || status !== 'active')) {
    throw badRequest('You cannot remove your own manager access while signed in');
  }
  const { rows, rowCount } = await pool.query(
    `UPDATE users SET name = $1, role = $2, status = $3, department_id = $4
     WHERE id = $5 RETURNING id, name, username, role, status, department_id`,
    [name, role, status, department_id || null, id]
  );
  if (rowCount === 0) throw notFound('User not found');
  res.json(rows[0]);
}));

router.post('/:id/reset-password', managerOnly, validate({ params: schemas.idParam, body: schemas.resetPassword }), asyncHandler(async (req, res) => {
  const passwordHash = await bcrypt.hash(req.body.password, config.BCRYPT_ROUNDS);
  const { rowCount } = await pool.query(
    'UPDATE users SET password_hash = $1, must_change_password = TRUE WHERE id = $2',
    [passwordHash, req.params.id]
  );
  if (rowCount === 0) throw notFound('User not found');
  res.json({ success: true });
}));

router.delete('/:id', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  if (Number(req.params.id) === req.user.id) throw badRequest('You cannot deactivate your own account');
  const { rowCount } = await pool.query("UPDATE users SET status = 'inactive' WHERE id = $1", [req.params.id]);
  if (rowCount === 0) throw notFound('User not found');
  res.json({ success: true });
}));

module.exports = router;
