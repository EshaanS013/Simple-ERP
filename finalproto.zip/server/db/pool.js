const { Pool } = require('pg');
const config = require('../config/env');

// Single shared PostgreSQL pool. Sized for 10-50 concurrent LAN users.
const pool = new Pool({
  connectionString: config.DATABASE_URL,
  max: Number(process.env.PG_POOL_MAX || 20),
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 10000
});

pool.on('error', (err) => {
  console.error('Unexpected error on idle PostgreSQL client', err);
});

async function query(text, params) {
  return pool.query(text, params);
}

// Run a set of statements inside a single transaction.
async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

async function healthcheck() {
  await pool.query('SELECT 1');
  return true;
}

module.exports = { pool, query, withTransaction, healthcheck };
