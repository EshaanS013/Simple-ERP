import { useState, useEffect, useCallback, useRef } from 'react';
import { X, Send, Trash2, MessageSquare } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { Spinner } from './ui';

// Slide-over comment thread for a project / task / production record.
// entity: { type: 'project'|'task'|'production', id, label }
export default function CommentsDrawer({ entity, onClose }) {
  const { user, isManager } = useAuth();
  const toast = useToast();
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [body, setBody] = useState('');
  const [busy, setBusy] = useState(false);
  const endRef = useRef(null);
  const open = !!entity;
  const param = entity ? { [`${entity.type}_id`]: entity.id } : null;

  const load = useCallback(async () => {
    if (!entity) return;
    setLoading(true);
    try { setComments((await Api.comments(param)).data || []); }
    catch (e) { toast.error(e.message); } finally { setLoading(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [entity?.type, entity?.id]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!open) return;
    const refresh = () => load();
    socket.on('comment_added', refresh); socket.on('comment_deleted', refresh);
    return () => { socket.off('comment_added', refresh); socket.off('comment_deleted', refresh); };
  }, [open, load]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [comments.length]);

  const post = async () => {
    const text = body.trim();
    if (!text) return;
    setBusy(true);
    try {
      await Api.addComment({ ...param, body: text });
      setBody(''); load();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const del = async (id) => {
    try { await Api.deleteComment(id); load(); } catch (e) { toast.error(e.message); }
  };

  const fmt = (d) => new Date(d).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });

  return (
    <>
      <div className={`fixed inset-0 z-40 bg-slate-900/30 transition-opacity ${open ? 'opacity-100' : 'pointer-events-none opacity-0'}`} onClick={onClose} />
      <aside className={`fixed right-0 top-0 z-50 flex h-full w-full max-w-md flex-col border-l border-slate-200 bg-white shadow-xl transition-transform duration-200 ${open ? 'translate-x-0' : 'translate-x-full'}`}>
        <header className="flex items-start justify-between gap-3 border-b border-slate-200 px-5 py-4">
          <div className="min-w-0">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-900"><MessageSquare className="h-4 w-4 text-brand-600" /> Comments</h2>
            {entity?.label && <p className="mt-0.5 truncate text-xs text-slate-500">{entity.label}</p>}
          </div>
          <button className="btn-ghost btn-sm" onClick={onClose}><X className="h-5 w-5" /></button>
        </header>

        <div className="flex-1 space-y-3 overflow-y-auto px-5 py-4">
          {loading ? <div className="flex justify-center py-10"><Spinner /></div>
            : comments.length === 0 ? <p className="py-10 text-center text-sm text-slate-400">No comments yet. Start the thread below.</p>
            : comments.map((c) => (
              <div key={c.id} className="group rounded-lg border border-slate-100 bg-slate-50/60 px-3 py-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-slate-700">{c.author_name || 'Unknown'}</span>
                  <span className="flex items-center gap-2">
                    <span className="text-[11px] text-slate-400">{fmt(c.created_at)}</span>
                    {(c.author_id === user?.id || isManager) && (
                      <button onClick={() => del(c.id)} className="text-slate-300 opacity-0 transition group-hover:opacity-100 hover:text-red-500" title="Delete">
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    )}
                  </span>
                </div>
                <p className="mt-1 whitespace-pre-wrap break-words text-sm text-slate-700">{c.body}</p>
              </div>
            ))}
          <div ref={endRef} />
        </div>

        <div className="border-t border-slate-200 p-3">
          <div className="flex items-end gap-2">
            <textarea className="input min-h-[42px] flex-1 resize-none" rows={1} placeholder="Write a comment…" value={body}
              onChange={(e) => setBody(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); post(); } }} />
            <button className="btn-primary shrink-0" onClick={post} disabled={busy || !body.trim()}><Send className="h-4 w-4" /></button>
          </div>
          <p className="mt-1 px-1 text-[11px] text-slate-400">Enter to send · Shift+Enter for a new line</p>
        </div>
      </aside>
    </>
  );
}
