// Lightweight dependency-free charts (CSS bars). Robust against empty/zero data.

export function StatTile({ label, value, sub, accent = 'brand' }) {
  const ring = { brand: 'text-brand-700', emerald: 'text-emerald-600', amber: 'text-amber-600', red: 'text-red-600', slate: 'text-slate-700' }[accent] || 'text-brand-700';
  return (
    <div className="rounded-xl border border-slate-100 bg-white p-4">
      <p className="text-xs font-medium uppercase tracking-wide text-slate-400">{label}</p>
      <p className={`mt-1 text-2xl font-semibold ${ring}`}>{value}</p>
      {sub != null && <p className="mt-0.5 text-xs text-slate-400">{sub}</p>}
    </div>
  );
}

export function GroupedBars({ data, height = 160, aLabel, bLabel, aColor = 'bg-brand-500', bColor = 'bg-emerald-400', valueFmt = (v) => v }) {
  const max = Math.max(1, ...data.flatMap((d) => [Number(d.a) || 0, Number(d.b) || 0]));
  if (!data.length) return <p className="py-8 text-center text-sm text-slate-400">No data yet.</p>;
  return (
    <div>
      <div className="mb-2 flex items-center gap-4 text-xs text-slate-500">
        <span className="flex items-center gap-1.5"><span className={`h-2.5 w-2.5 rounded-sm ${aColor}`} />{aLabel}</span>
        <span className="flex items-center gap-1.5"><span className={`h-2.5 w-2.5 rounded-sm ${bColor}`} />{bLabel}</span>
      </div>
      <div className="flex items-end gap-2" style={{ height }}>
        {data.map((d, i) => (
          <div key={i} className="flex flex-1 flex-col items-center justify-end gap-1">
            <div className="flex h-full w-full items-end justify-center gap-0.5">
              <div className={`w-1/2 rounded-t ${aColor}`} style={{ height: Math.max(2, Math.round(((Number(d.a) || 0) / max) * (height - 24))) }} title={`${aLabel}: ${valueFmt(d.a)}`} />
              <div className={`w-1/2 rounded-t ${bColor}`} style={{ height: Math.max(2, Math.round(((Number(d.b) || 0) / max) * (height - 24))) }} title={`${bLabel}: ${valueFmt(d.b)}`} />
            </div>
            <span className="text-[10px] text-slate-400">{d.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function HBarList({ items, valueFmt = (v) => v, color = 'bg-brand-500' }) {
  const max = Math.max(1, ...items.map((it) => Number(it.value) || 0));
  if (!items.length) return <p className="py-8 text-center text-sm text-slate-400">No data yet.</p>;
  return (
    <ul className="space-y-2">
      {items.map((it, i) => (
        <li key={i}>
          <div className="mb-0.5 flex items-center justify-between text-xs">
            <span className="truncate font-medium text-slate-700">{it.label}</span>
            <span className="text-slate-500">{valueFmt(it.value)}{it.sub ? ` · ${it.sub}` : ''}</span>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
            <div className={`h-full rounded-full ${color}`} style={{ width: `${Math.round(((Number(it.value) || 0) / max) * 100)}%` }} />
          </div>
        </li>
      ))}
    </ul>
  );
}
