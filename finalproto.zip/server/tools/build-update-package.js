#!/usr/bin/env node
// Build a WOLF3D ERP update package.
//
//   node tools/build-update-package.js --version 1.3.0 --build 1030 \
//        --frontend ../client/dist --backend . --migrations db/migrations \
//        --min-compatible 1.2.0 --notes RELEASE_NOTES.md --out ./dist-packages
//
// Produces wolf3d_update_v<version>.zip containing frontend/, backend/,
// migrations/, manifest.json (with per-file sha256 checksums) and release-notes.md.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const AdmZip = require('adm-zip');

function arg(name, def) { const i = process.argv.indexOf(`--${name}`); return i > -1 ? process.argv[i + 1] : def; }
const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

const version = arg('version');
const build = arg('build', String(Date.now()));
if (!version) { console.error('--version is required'); process.exit(1); }
const minCompatible = arg('min-compatible', '1.0.0');
const frontendDir = arg('frontend', path.join(__dirname, '..', '..', 'client', 'dist'));
const backendDir = arg('backend', path.join(__dirname, '..'));
const migrationsDir = arg('migrations', path.join(__dirname, '..', 'db', 'migrations'));
const notesFile = arg('notes', '');
const outDir = arg('out', path.join(__dirname, '..', 'dist-packages'));

const zip = new AdmZip();
const files = {};

function addDir(absDir, zipFolder) {
  if (!fs.existsSync(absDir)) return;
  for (const entry of fs.readdirSync(absDir, { withFileTypes: true })) {
    if (entry.name === 'node_modules' || entry.name === '.git' || entry.name === 'releases' ||
        entry.name === 'backups' || entry.name === 'logs' || entry.name === 'dist-packages' ||
        entry.name.endsWith('.log') || entry.name === '.env') continue;
    const abs = path.join(absDir, entry.name);
    const rel = `${zipFolder}/${entry.name}`;
    if (entry.isDirectory()) addDir(abs, rel);
    else { const data = fs.readFileSync(abs); zip.addFile(rel, data); files[rel] = sha256(data); }
  }
}

console.log('Packaging frontend…'); addDir(frontendDir, 'frontend');
console.log('Packaging backend…'); addDir(backendDir, 'backend');
console.log('Packaging migrations…'); addDir(migrationsDir, 'migrations');

const notes = notesFile && fs.existsSync(notesFile) ? fs.readFileSync(notesFile, 'utf8') : `# WOLF3D ERP ${version}\n\nRelease ${version} (build ${build}).\n`;
zip.addFile('release-notes.md', Buffer.from(notes));

const manifest = {
  name: 'WOLF3D ERP', version, build: String(build),
  release_date: new Date().toISOString().slice(0, 10),
  min_compatible: minCompatible,
  files
};
zip.addFile('manifest.json', Buffer.from(JSON.stringify(manifest, null, 2)));

fs.mkdirSync(outDir, { recursive: true });
const outPath = path.join(outDir, `wolf3d_update_v${version}.zip`);
zip.writeZip(outPath);
console.log(`\n✓ Built ${outPath}`);
console.log(`  version ${version} · build ${build} · ${Object.keys(files).length} files · min-compatible ${minCompatible}`);
