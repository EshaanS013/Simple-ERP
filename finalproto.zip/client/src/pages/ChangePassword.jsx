import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { KeyRound, Loader2, AlertCircle, ShieldAlert } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Api from '../services/api';

export default function ChangePassword() {
  const { mustChangePassword, refresh, logout } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    if (form.newPassword !== form.confirm) { setError('New passwords do not match'); return; }
    if (form.newPassword.length < 8 || !/[A-Za-z]/.test(form.newPassword) || !/[0-9]/.test(form.newPassword)) {
      setError('Password must be at least 8 characters and include a letter and a number'); return;
    }
    setBusy(true);
    try {
      await Api.changePassword({ currentPassword: form.currentPassword, newPassword: form.newPassword });
      await refresh();
      toast.success('Password changed');
      navigate('/', { replace: true });
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-sm">
        <form onSubmit={submit} className="card space-y-4 p-6">
          <div className="flex items-center gap-2 text-slate-900">
            <KeyRound className="h-5 w-5 text-brand-600" />
            <h1 className="text-lg font-semibold">Change password</h1>
          </div>
          {mustChangePassword && (
            <div className="flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2.5 text-sm text-amber-800">
              <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
              <span>For security, please set a new password before continuing.</span>
            </div>
          )}
          {error && (
            <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-700">
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /><span>{error}</span>
            </div>
          )}
          <div>
            <label className="label">Current password</label>
            <input className="input" type="password" value={form.currentPassword} onChange={(e) => set('currentPassword', e.target.value)} autoFocus />
          </div>
          <div>
            <label className="label">New password</label>
            <input className="input" type="password" value={form.newPassword} onChange={(e) => set('newPassword', e.target.value)} />
          </div>
          <div>
            <label className="label">Confirm new password</label>
            <input className="input" type="password" value={form.confirm} onChange={(e) => set('confirm', e.target.value)} />
          </div>
          <button type="submit" className="btn-primary w-full" disabled={busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
            {busy ? 'Updating…' : 'Update password'}
          </button>
          {!mustChangePassword && (
            <button type="button" className="btn-ghost w-full" onClick={() => navigate(-1)}>Cancel</button>
          )}
          {mustChangePassword && (
            <button type="button" className="btn-ghost w-full text-slate-400" onClick={logout}>Sign out instead</button>
          )}
        </form>
      </div>
    </div>
  );
}
