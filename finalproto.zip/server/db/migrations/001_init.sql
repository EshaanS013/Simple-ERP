-- WOLF3D ERP — schema aligned to the real Excel workflow.
-- Departments are operational workspaces. Production is one unified
-- Work Order -> Production -> Quality -> Dispatch -> Completed flow.

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

-- ---------- Departments (workspaces) ----------
CREATE TABLE IF NOT EXISTS departments (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------- Users ----------
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  username TEXT UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'employee' CHECK (role IN ('admin','manager','employee')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
  must_change_password BOOLEAN NOT NULL DEFAULT false,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
DROP TRIGGER IF EXISTS trg_users_updated ON users;
CREATE TRIGGER trg_users_updated BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------- Department membership (many-to-many) ----------
CREATE TABLE IF NOT EXISTS user_departments (
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  department_id INTEGER NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, department_id)
);
CREATE UNIQUE INDEX IF NOT EXISTS users_name_lower_unique ON users (lower(name));
CREATE INDEX IF NOT EXISTS idx_user_departments_dept ON user_departments(department_id);

-- ---------- Projects (inside a department) ----------
CREATE TABLE IF NOT EXISTS projects (
  id SERIAL PRIMARY KEY,
  department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL,
  project_number TEXT,
  project_name TEXT NOT NULL,
  client_name TEXT,
  status TEXT NOT NULL DEFAULT 'in_production'
    CHECK (status IN ('work_order','in_production','in_quality','ready_for_dispatch','completed','on_hold','cancelled')),
  progress_percent INTEGER NOT NULL DEFAULT 0 CHECK (progress_percent BETWEEN 0 AND 100),
  start_date DATE,
  deadline DATE,
  remarks TEXT,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
DROP TRIGGER IF EXISTS trg_projects_updated ON projects;
CREATE TRIGGER trg_projects_updated BEFORE UPDATE ON projects FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE INDEX IF NOT EXISTS idx_projects_department ON projects(department_id);

-- ---------- Tasks (inside a department) ----------
CREATE TABLE IF NOT EXISTS tasks (
  id SERIAL PRIMARY KEY,
  department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL,
  project_id INTEGER REFERENCES projects(id) ON DELETE SET NULL,
  task_name TEXT NOT NULL,
  assigned_to INTEGER REFERENCES users(id) ON DELETE SET NULL,
  priority TEXT NOT NULL DEFAULT 'medium' CHECK (priority IN ('low','medium','high','critical')),
  status TEXT NOT NULL DEFAULT 'awaiting'
    CHECK (status IN ('awaiting','in_progress','partially_complete','completed','blocked','cancelled')),
  deadline DATE,
  description TEXT,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
DROP TRIGGER IF EXISTS trg_tasks_updated ON tasks;
CREATE TRIGGER trg_tasks_updated BEFORE UPDATE ON tasks FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE INDEX IF NOT EXISTS idx_tasks_department ON tasks(department_id);
CREATE INDEX IF NOT EXISTS idx_tasks_project ON tasks(project_id);

-- ---------- Production records (the BDE sheet, unified workflow) ----------
CREATE TABLE IF NOT EXISTS production_records (
  id SERIAL PRIMARY KEY,
  department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL,
  -- BDE inputs
  work_order_number TEXT,
  order_date DATE,
  client_name TEXT,
  dispatch_date DATE,
  part_name TEXT NOT NULL,
  technology TEXT,
  quantity INTEGER,
  -- Production inputs
  finish TEXT,
  paint TEXT,
  printing TEXT,
  clean_and_cure TEXT,
  sanding_and_polishing TEXT,
  paint_status TEXT,
  -- Quality inputs
  xyz_dimension TEXT,
  critical_dimension TEXT,
  surface_finish TEXT,
  report_generated TEXT,
  rework_verdict TEXT,
  -- Dispatch
  dispatch_status TEXT,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  last_updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  last_updated_by_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Per-field audit trail for production records (who changed what, old -> new).
CREATE TABLE IF NOT EXISTS production_audit (
  id SERIAL PRIMARY KEY,
  production_id INTEGER NOT NULL REFERENCES production_records(id) ON DELETE CASCADE,
  field TEXT NOT NULL,
  old_value TEXT,
  new_value TEXT,
  changed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  changed_by_name TEXT,
  changed_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_production_audit_pid ON production_audit(production_id, changed_at DESC);
DROP TRIGGER IF EXISTS trg_production_updated ON production_records;
CREATE TRIGGER trg_production_updated BEFORE UPDATE ON production_records FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE INDEX IF NOT EXISTS idx_production_department ON production_records(department_id);

-- ---------- Machines + usage (machine utilisation sheet) ----------
CREATE TABLE IF NOT EXISTS machines (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  technology TEXT NOT NULL,                -- SLA / DLP / FDM
  measure TEXT NOT NULL CHECK (measure IN ('volume_cc','weight_gms')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS machine_usage (
  id SERIAL PRIMARY KEY,
  machine_id INTEGER NOT NULL REFERENCES machines(id) ON DELETE CASCADE,
  usage_date DATE NOT NULL,
  material TEXT,
  volume_cc NUMERIC,
  weight_gms NUMERIC,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_machine_usage_machine ON machine_usage(machine_id);
CREATE INDEX IF NOT EXISTS idx_machine_usage_date ON machine_usage(usage_date);

-- ---------- Payments (accounts sheet) ----------
CREATE TABLE IF NOT EXISTS payments (
  id SERIAL PRIMARY KEY,
  invoice_date DATE,
  client_name TEXT NOT NULL,
  contact_number TEXT,
  invoice_number TEXT,
  amount NUMERIC,
  gst_status TEXT,
  payment_terms TEXT,
  payment_status TEXT NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending','received','overdue','partial')),
  action TEXT,
  comments TEXT,
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
DROP TRIGGER IF EXISTS trg_payments_updated ON payments;
CREATE TRIGGER trg_payments_updated BEFORE UPDATE ON payments FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------- Department feed: updates ----------
CREATE TABLE IF NOT EXISTS updates (
  id SERIAL PRIMARY KEY,
  department_id INTEGER NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  parent_id INTEGER REFERENCES updates(id) ON DELETE CASCADE,
  message TEXT NOT NULL,
  author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_updates_department ON updates(department_id);

-- ---------- Comments (attach to project / task / production) ----------
CREATE TABLE IF NOT EXISTS comments (
  id SERIAL PRIMARY KEY,
  body TEXT NOT NULL,
  author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  project_id INTEGER REFERENCES projects(id) ON DELETE CASCADE,
  task_id INTEGER REFERENCES tasks(id) ON DELETE CASCADE,
  production_id INTEGER REFERENCES production_records(id) ON DELETE CASCADE,
  department_id INTEGER REFERENCES departments(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------- Notices (company-wide) ----------
CREATE TABLE IF NOT EXISTS notices (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  urgent BOOLEAN NOT NULL DEFAULT false,
  pinned BOOLEAN NOT NULL DEFAULT false,
  author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ---------- Activity feed (department-scoped) ----------
CREATE TABLE IF NOT EXISTS activities (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  user_name TEXT,
  action TEXT NOT NULL,
  module TEXT,
  details TEXT,
  entity_type TEXT,
  entity_id INTEGER,
  department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_activities_created ON activities(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_activities_department ON activities(department_id);

-- ---------- Settings ----------
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Design Daily Updates (Design department): daily designer progress reporting.
CREATE TABLE IF NOT EXISTS design_updates (
  id SERIAL PRIMARY KEY,
  entry_date DATE,
  project_name TEXT,
  designer_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  designer_name TEXT,
  work_done TEXT,
  comment TEXT,
  progress_percent INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'not_started' CHECK (status IN ('not_started','in_progress','completed')),
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_design_updates_date ON design_updates(entry_date DESC);
DROP TRIGGER IF EXISTS trg_design_updates_updated ON design_updates;
CREATE TRIGGER trg_design_updates_updated BEFORE UPDATE ON design_updates FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- Direct messages between users (30-day retention, enforced by cleanup job).
CREATE TABLE IF NOT EXISTS messages (
  id SERIAL PRIMARY KEY,
  sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_messages_pair ON messages(sender_id, recipient_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_recipient ON messages(recipient_id, read_at);
