const rateLimit = require('express-rate-limit');
const config = require('../config/env');

// Brute-force protection for the login endpoint.
const loginLimiter = rateLimit({
  windowMs: config.LOGIN_RATE_WINDOW_MS,
  max: config.LOGIN_RATE_MAX,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many login attempts. Please try again later.' }
});

// Generous limiter for the rest of the API to absorb accidental loops.
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: Number(process.env.API_RATE_MAX || 600),
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests. Please slow down.' }
});

module.exports = { loginLimiter, apiLimiter };
