import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import Api, { getToken, setToken, clearToken } from '../services/api';
import { connectSocket, disconnectSocket } from '../services/socket';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadSession = useCallback(async () => {
    if (!getToken()) { setLoading(false); return; }
    try {
      const me = await Api.me();
      setUser(me);
      connectSocket();
    } catch {
      clearToken();
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadSession(); }, [loadSession]);

  // Global session-expiry handler fired by the API interceptor.
  useEffect(() => {
    const onExpired = () => { setUser(null); disconnectSocket(); };
    window.addEventListener('auth:expired', onExpired);
    return () => window.removeEventListener('auth:expired', onExpired);
  }, []);

  const login = useCallback(async (name, password) => {
    const { token, user: u } = await Api.login({ name, password });
    setToken(token);
    setUser(u);
    connectSocket();
    return u;
  }, []);

  const logout = useCallback(() => {
    clearToken();
    setUser(null);
    disconnectSocket();
  }, []);

  // Refresh the cached user (e.g. after a forced password change).
  const refresh = useCallback(async () => {
    const me = await Api.me();
    setUser(me);
    return me;
  }, []);

  const deptNames = (user?.departments || []).map((d) => String(d.name).toLowerCase());
  const isManager = user?.role === 'manager' || user?.role === 'admin';
  const hasDepartment = (name) => deptNames.includes(String(name).toLowerCase());
  const value = {
    user,
    loading,
    login,
    logout,
    refresh,
    isManager,
    isAdmin: user?.role === 'admin',
    hasDepartment,
    // Module access: admins/managers always; otherwise must be in the department.
    canAccessAccounts: isManager || deptNames.includes('accounts'),
    mustChangePassword: !!user?.must_change_password
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
};
