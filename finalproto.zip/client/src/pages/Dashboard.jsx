import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { Factory, ClipboardCheck, Truck, CheckCircle2, FileWarning, PackageX, IndianRupee, Activity as ActivityIcon, Network, Pin, PenTool, Briefcase, FolderKanban } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { LoadingState, ErrorState } from '../components/ui';
import { fmtMoney } from '../lib/options';

const timeAgo = (d) => {
  const sec = Math.floor((Date.now() - new Date(d)) / 1000);
  if (sec < 60) return 'just now';
  if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  if (sec < 86400) return `${Math.floor(sec / 3600)}h ago`;
  return new Date(d).toLocaleDateString();
};

function Stat({ icon: Icon, label, value, tint, to }) {
  const body = (
    <div className="card flex items-center gap-3 p-4 transition hover:shadow-pop">
      <div className={`flex h-11 w-11 items-center justify-center rounded-lg ${tint}`}><Icon className="h-5 w-5" /></div>
      <div><p className="text-2xl font-semibold text-slate-900">{value}</p><p className="text-xs text-slate-500">{label}</p></div>
    </div>
  );
  return to ? <Link to={to}>{body}</Link> : body;
}

function ActivityList({ items, title = 'Recent activity' }) {
  return (
    <div className="card p-5">
      <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-900"><ActivityIcon className="h-4 w-4" /> {title}</h3>
      {(!items || items.length === 0) ? <p className="py-4 text-center text-sm text-slate-400">No activity yet.</p> : (
        <ul className="space-y-3">
          {items.map((a) => (
            <li key={a.id} className="text-sm">
              <span className="font-medium text-slate-800">{a.user_name || 'Someone'}</span>{' '}
              <span className="text-slate-500">{a.action}{a.details ? ` · ${a.details}` : ''}</span>
              <span className="block text-xs text-slate-400">{timeAgo(a.created_at)}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function NoticeList({ items }) {
  if (!items?.length) return null;
  return (
    <div className="mt-4 border-t border-slate-100 pt-3">
      <h4 className="mb-2 text-xs font-semibold uppercase text-slate-500">Notices</h4>
      <ul className="space-y-1.5">
        {items.map((n) => (
          <li key={n.id} className="flex items-center gap-2 text-sm text-slate-700">
            {n.pinned && <Pin className="h-3 w-3 text-amber-500" />}{n.title}
            {n.urgent && <span className="rounded bg-red-50 px-1.5 text-xs text-red-600">urgent</span>}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setError(null);
    try { setData(await Api.dashboard()); }
    catch (e) { setError(e.message); } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const refresh = () => load();
    const evs = ['production_created', 'production_updated', 'production_deleted', 'payment_created', 'payment_updated', 'activity_created', 'design_created', 'design_updated', 'update_created', 'notice_created'];
    evs.forEach((e) => socket.on(e, refresh));
    return () => evs.forEach((e) => socket.off(e, refresh));
  }, [load]);

  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} onRetry={load} />;

  // ---------- Employee dashboard ----------
  if (data.scope === 'employee') {
    const status = { not_started: 'Not started', in_progress: 'In progress', completed: 'Completed' };
    return (
      <section className="space-y-5">
        <div>
          <h1 className="text-xl font-semibold tracking-tight text-slate-900">My Workspace</h1>
          <p className="mt-0.5 text-sm text-slate-500">Welcome back, {user?.name?.split(' ')[0]}. Here's what's relevant to you.</p>
        </div>

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <Stat icon={Network} label="My Departments" value={data.myDepartments?.length || 0} tint="bg-brand-50 text-brand-600" />
          <Stat icon={Briefcase} label="Active Production" value={data.myAssignedWork?.active_production || 0} tint="bg-blue-50 text-blue-600" to="/production" />
          <Stat icon={PenTool} label="My Design Updates" value={data.myUpdates?.length || 0} tint="bg-violet-50 text-violet-600" to="/design" />
          <Stat icon={CheckCircle2} label="My Completed" value={(data.myUpdates || []).filter((u) => u.status === 'completed').length} tint="bg-emerald-50 text-emerald-600" to="/design" />
        </div>


        <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
          <div className="card p-5 lg:col-span-2">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-900"><Network className="h-4 w-4" /> My Departments</h3>
            {(!data.myDepartments || data.myDepartments.length === 0) ? <p className="py-4 text-center text-sm text-slate-400">You are not assigned to a department yet.</p> : (
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                {data.myDepartments.map((d) => (
                  <Link key={d.id} to={`/departments/${d.id}`} className="flex items-center justify-between rounded-lg border border-slate-100 px-4 py-3 hover:bg-slate-50">
                    <span className="font-medium text-slate-800">{d.name}</span>
                    <span className="text-xs text-slate-500">{d.active_production} production · {d.members} members</span>
                  </Link>
                ))}
              </div>
            )}

            {data.myUpdates?.length > 0 && (
              <div className="mt-5">
                <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-900"><PenTool className="h-4 w-4" /> My Updates</h3>
                <ul className="divide-y divide-slate-50">
                  {data.myUpdates.map((u) => (
                    <li key={u.id} className="flex items-center justify-between py-2 text-sm">
                      <span className="text-slate-700">{u.project_name || 'Untitled'} <span className="text-slate-400">— {u.work_done || '—'}</span></span>
                      <span className="ml-3 shrink-0 text-xs text-slate-500">{u.progress_percent || 0}% · {status[u.status] || u.status}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div>
            <ActivityList items={data.recentActivities} title="Recent Department Activity" />
            <div className="card mt-5 p-5"><NoticeList items={data.recentNotices} /></div>
          </div>
        </div>
      </section>
    );
  }

  // ---------- Manager / admin dashboard ----------
  const p = data.production || {};
  const pay = data.payments || {};
  return (
    <section className="space-y-5">
      <div>
        <h1 className="text-xl font-semibold tracking-tight text-slate-900">Operations</h1>
        <p className="mt-0.5 text-sm text-slate-500">Live view of production, dispatch and payments.</p>
      </div>

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat icon={Factory} label="In Production" value={p.in_production || 0} tint="bg-blue-50 text-blue-600" to="/production" />
        <Stat icon={Truck} label="Ready for Dispatch" value={p.ready_for_dispatch || 0} tint="bg-amber-50 text-amber-600" to="/production" />
        <Stat icon={CheckCircle2} label="Completed" value={p.completed || 0} tint="bg-emerald-50 text-emerald-600" to="/production" />
        <Stat icon={IndianRupee} label="Outstanding Payments" value={pay.outstanding_count || 0} tint="bg-red-50 text-red-600" to="/accounts" />
      </div>


      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="card p-5 lg:col-span-2">
          <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-900"><Network className="h-4 w-4" /> Department status</h3>
          {(!data.departments || data.departments.length === 0) ? <p className="py-4 text-center text-sm text-slate-400">No workspaces yet.</p> : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead><tr className="text-left text-xs uppercase text-slate-500"><th className="py-2">Workspace</th><th className="py-2">Active Production</th><th className="py-2">Members</th></tr></thead>
                <tbody>
                  {data.departments.map((d) => (
                    <tr key={d.id} className="border-t border-slate-100">
                      <td className="py-2"><Link to={`/departments/${d.id}`} className="font-medium text-brand-600 hover:underline">{d.name}</Link></td>
                      <td className="py-2">{d.active_production}</td>
                      <td className="py-2">{d.members}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="mt-4 flex items-center justify-between rounded-lg bg-red-50 px-4 py-3">
            <span className="text-sm font-medium text-red-700">Outstanding payments</span>
            <span className="text-lg font-semibold text-red-700">{fmtMoney(pay.outstanding_amount)}</span>
          </div>
        </div>

        <div>
          <ActivityList items={data.recentActivities} />
        </div>
      </div>
    </section>
  );
}
