const express = require('express');
const { pool } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound } = require('../middleware/errorHandler');
const { emitEvent } = require('../socket/socket');
const { recordActivity } = require('../utils/activity');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

const DETAIL = `
  SELECT q.*, p.project_name, u.name AS inspector_name
  FROM quality_records q
  LEFT JOIN projects p ON p.id = q.project_id
  LEFT JOIN users u ON u.id = q.inspector`;

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query);
  const { search, status } = req.query;
  const conditions = [];
  const values = [];
  let i = 1;
  if (search) { conditions.push(`(q.report_number ILIKE $${i} OR q.part_name ILIKE $${i})`); values.push(`%${search}%`); i++; }
  if (status) { conditions.push(`q.quality_status = $${i}`); values.push(status); i++; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const total = await pool.query(`SELECT COUNT(*)::int c FROM quality_records q ${where}`, values);
  const rows = await pool.query(`${DETAIL} ${where} ORDER BY q.created_at DESC LIMIT $${i} OFFSET $${i + 1}`, [...values, pageSize, offset]);
  res.json(paginatedResponse(rows.rows, total.rows[0].c, page, pageSize));
}));

router.post('/', managerOnly, validate({ body: schemas.createQuality }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO quality_records (project_id, part_name, xyz_dimension, critical_dimensions, inspection_notes, report_number, quality_status, inspector, date, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [b.project_id || null, b.part_name || null, b.xyz_dimension || null, b.critical_dimensions || null, b.inspection_notes || null, b.report_number || null, b.quality_status, b.inspector || null, b.date || null, req.user.id]
  );
  emitEvent('quality_created', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'logged a quality record', module: 'Quality', details: rows[0].report_number || rows[0].part_name, entityType: 'quality', entityId: rows[0].id, projectId: rows[0].project_id });
  res.status(201).json(rows[0]);
}));

router.put('/:id', managerOnly, validate({ params: schemas.idParam, body: schemas.updateQuality }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows, rowCount } = await pool.query(
    `UPDATE quality_records SET project_id=$1, part_name=$2, xyz_dimension=$3, critical_dimensions=$4, inspection_notes=$5, report_number=$6, quality_status=$7, inspector=$8, date=$9
     WHERE id=$10 RETURNING *`,
    [b.project_id || null, b.part_name || null, b.xyz_dimension || null, b.critical_dimensions || null, b.inspection_notes || null, b.report_number || null, b.quality_status, b.inspector || null, b.date || null, req.params.id]
  );
  if (rowCount === 0) throw notFound('Quality record not found');
  emitEvent('quality_updated', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'updated a quality record', module: 'Quality', details: rows[0].report_number || rows[0].part_name, entityType: 'quality', entityId: rows[0].id, projectId: rows[0].project_id });
  res.json(rows[0]);
}));

router.delete('/:id', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rowCount } = await pool.query('DELETE FROM quality_records WHERE id = $1', [req.params.id]);
  if (rowCount === 0) throw notFound('Quality record not found');
  emitEvent('quality_deleted', { id: Number(req.params.id) });
  res.json({ success: true });
}));

module.exports = router;
