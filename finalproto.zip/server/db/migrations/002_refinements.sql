-- 002_refinements.sql
-- v2 refinements: central multi-department projects + machine run-hours.
-- All statements are idempotent (IF NOT EXISTS) so this is safe to apply
-- to both fresh and already-initialised databases.

-- ===== Project rework: projects are the central multi-department object =====
ALTER TABLE projects ADD COLUMN IF NOT EXISTS work_order_number TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS technology TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS part_name TEXT;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS quantity INTEGER;
ALTER TABLE projects ADD COLUMN IF NOT EXISTS stage TEXT NOT NULL DEFAULT 'sales';

CREATE TABLE IF NOT EXISTS project_departments (
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  department_id INTEGER NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
  PRIMARY KEY (project_id, department_id)
);
CREATE TABLE IF NOT EXISTS project_members (
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (project_id, user_id)
);
CREATE TABLE IF NOT EXISTS project_stage_progress (
  id SERIAL PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  stage TEXT NOT NULL,
  percent INTEGER NOT NULL DEFAULT 0 CHECK (percent BETWEEN 0 AND 100),
  note TEXT,
  updated_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  updated_by_name TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (project_id, stage)
);
CREATE TABLE IF NOT EXISTS project_events (
  id SERIAL PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  kind TEXT,
  message TEXT NOT NULL,
  user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  user_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_project_events_project ON project_events(project_id, created_at DESC);
CREATE TABLE IF NOT EXISTS project_comments (
  id SERIAL PRIMARY KEY,
  project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  parent_id INTEGER REFERENCES project_comments(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  author_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_project_comments_project ON project_comments(project_id, created_at ASC);

-- Machine utilisation: track run hours per usage entry for analytics.
ALTER TABLE machine_usage ADD COLUMN IF NOT EXISTS hours NUMERIC DEFAULT 0;

-- Performance: indexes for project visibility filters and machine analytics.
CREATE INDEX IF NOT EXISTS idx_project_departments_dept ON project_departments(department_id);
CREATE INDEX IF NOT EXISTS idx_project_members_user ON project_members(user_id);
CREATE INDEX IF NOT EXISTS idx_projects_updated ON projects(updated_at DESC);
CREATE INDEX IF NOT EXISTS idx_machine_usage_machine_date ON machine_usage(machine_id, usage_date);
CREATE INDEX IF NOT EXISTS idx_machine_usage_date ON machine_usage(usage_date);
CREATE INDEX IF NOT EXISTS idx_machine_usage_material ON machine_usage(material);
