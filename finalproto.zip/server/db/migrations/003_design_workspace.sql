-- 003_design_workspace.sql
-- Design Daily Updates becomes the central project workspace. Each design
-- assignment is one customer project with accumulating daily updates,
-- discussion, and an activity timeline. Idempotent (safe to re-run).

CREATE TABLE IF NOT EXISTS design_assignments (
  id SERIAL PRIMARY KEY,
  work_order_number TEXT,
  client_name TEXT,
  part_name TEXT NOT NULL,
  technology TEXT,
  quantity INTEGER,
  start_date DATE,
  deadline DATE,
  progress_percent INTEGER NOT NULL DEFAULT 0 CHECK (progress_percent BETWEEN 0 AND 100),
  status TEXT NOT NULL DEFAULT 'not_started' CHECK (status IN ('not_started','in_progress','completed','on_hold')),
  created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS design_assignment_members (
  assignment_id INTEGER NOT NULL REFERENCES design_assignments(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  PRIMARY KEY (assignment_id, user_id)
);

-- Link daily updates to an assignment so progress history accumulates per project.
ALTER TABLE design_updates ADD COLUMN IF NOT EXISTS assignment_id INTEGER REFERENCES design_assignments(id) ON DELETE CASCADE;
CREATE INDEX IF NOT EXISTS idx_design_updates_assignment ON design_updates(assignment_id, entry_date DESC, id DESC);

CREATE TABLE IF NOT EXISTS design_comments (
  id SERIAL PRIMARY KEY,
  assignment_id INTEGER NOT NULL REFERENCES design_assignments(id) ON DELETE CASCADE,
  parent_id INTEGER REFERENCES design_comments(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  author_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_design_comments_assignment ON design_comments(assignment_id, created_at ASC);
CREATE INDEX IF NOT EXISTS idx_design_assignment_members_user ON design_assignment_members(user_id);
