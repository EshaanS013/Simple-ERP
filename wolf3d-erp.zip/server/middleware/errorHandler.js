// Structured API error and centralized handling.

class ApiError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code || undefined;
  }
}

const badRequest = (msg, code) => new ApiError(400, msg, code);
const unauthorized = (msg = 'Authentication required') => new ApiError(401, msg);
const forbidden = (msg = 'You do not have permission to do that') => new ApiError(403, msg);
const notFound = (msg = 'Resource not found') => new ApiError(404, msg);
const conflict = (msg, code) => new ApiError(409, msg, code);

// Wrap async route handlers so rejected promises reach the error middleware.
const asyncHandler = (fn) => (req, res, next) =>
  Promise.resolve(fn(req, res, next)).catch(next);

function notFoundHandler(req, res, next) {
  // Only API paths should 404 as JSON; SPA fallback handles the rest.
  if (req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'Endpoint not found' });
  }
  next();
}

// Map common PostgreSQL errors to friendly messages.
function translatePgError(err) {
  switch (err.code) {
    case '23505': // unique_violation
      return new ApiError(409, 'A record with that value already exists', 'duplicate');
    case '23503': // foreign_key_violation
      return new ApiError(400, 'Referenced record does not exist', 'fk_violation');
    case '23502': // not_null_violation
      return new ApiError(400, `Missing required field: ${err.column || 'unknown'}`, 'not_null');
    case '23514': // check_violation
      return new ApiError(400, 'A value is not allowed for one of the fields', 'check_violation');
    case '22P02': // invalid_text_representation
      return new ApiError(400, 'Invalid value supplied for a field', 'invalid_value');
    default:
      return null;
  }
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  let apiError = err;

  if (!(err instanceof ApiError)) {
    const translated = translatePgError(err);
    apiError = translated || new ApiError(500, 'Something went wrong on our end');
    if (!translated) {
      console.error(`[${req.method} ${req.originalUrl}]`, err);
    }
  }

  const body = { error: apiError.message };
  if (apiError.code) body.code = apiError.code;
  res.status(apiError.status || 500).json(body);
}

module.exports = {
  ApiError,
  badRequest,
  unauthorized,
  forbidden,
  notFound,
  conflict,
  asyncHandler,
  notFoundHandler,
  errorHandler
};
