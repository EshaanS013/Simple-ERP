import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Search, Pencil, Trash2, Cpu, Download } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { LoadingState, EmptyState, Pagination, Select, Spinner, PageHeader, Modal, Field, Input, ConfirmDialog } from '../components/ui';
import { fmtDate } from '../lib/options';
import { downloadCsv } from '../lib/csv';

const num = (n) => Number(n || 0).toLocaleString('en-IN');
const monthLabel = (m) => { const [y, mo] = m.split('-'); return `${new Date(y, mo - 1).toLocaleString('en', { month: 'short' })} ${y}`; };
const monthShort = (m) => { const [y, mo] = m.split('-'); return new Date(y, mo - 1).toLocaleString('en', { month: 'short' }); };

// Compact two-series chart; each series scaled to its own max so both are visible.
function RuntimeVolumeChart({ data }) {
  if (!data.length) return <p className="py-8 text-center text-sm text-slate-400">No usage logged yet.</p>;
  const maxR = Math.max(1, ...data.map((d) => d.runtime));
  const maxV = Math.max(1, ...data.map((d) => d.volume_cc));
  const H = 150;
  return (
    <div>
      <div className="mb-2 flex items-center gap-4 text-xs text-slate-500">
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-brand-500" />Runtime (h)</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-sm bg-emerald-400" />Volume (cc)</span>
      </div>
      <div className="flex items-end gap-2" style={{ height: H }}>
        {data.map((d, i) => (
          <div key={i} className="flex flex-1 flex-col items-center justify-end gap-1">
            <div className="flex h-full w-full items-end justify-center gap-0.5">
              <div className="w-1/2 rounded-t bg-brand-500" style={{ height: Math.max(2, Math.round((d.runtime / maxR) * (H - 24))) }} title={`Runtime: ${num(d.runtime)} h`} />
              <div className="w-1/2 rounded-t bg-emerald-400" style={{ height: Math.max(2, Math.round((d.volume_cc / maxV) * (H - 24))) }} title={`Volume: ${num(d.volume_cc)} cc`} />
            </div>
            <span className="text-[10px] text-slate-400">{monthShort(d.month)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function MachineHistory() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isManager } = useAuth();
  const toast = useToast();
  const [data, setData] = useState(null);
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [month, setMonth] = useState('');
  const [editLog, setEditLog] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [delLog, setDelLog] = useState(null);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    try { setData(await Api.machineUsage(id, { page, pageSize: 25, search: search || undefined, month: month || undefined })); }
    catch (e) { toast.error(e.message); } finally { setLoading(false); }
  }, [id, page, search, month, toast]);
  const loadReport = useCallback(async () => { try { setReport(await Api.machineDashboard(id)); } catch { /* ignore */ } }, [id]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { loadReport(); }, [loadReport]);
  useEffect(() => {
    const r = () => { load(); loadReport(); };
    socket.on('machine_usage_created', r); socket.on('machine_usage_deleted', r);
    return () => { socket.off('machine_usage_created', r); socket.off('machine_usage_deleted', r); };
  }, [load, loadReport]);

  const openEdit = (l) => { setEditLog(l); setEditForm({ usage_date: String(l.usage_date).slice(0, 10), material: l.material || '', volume_cc: l.volume_cc, hours: l.hours }); };
  const saveEdit = async () => {
    if (!editForm.material?.trim()) { toast.error('Material is required'); return; }
    if (!(Number(editForm.volume_cc) > 0)) { toast.error('Volume must be greater than 0'); return; }
    if (!(Number(editForm.hours) > 0)) { toast.error('Runtime must be greater than 0'); return; }
    setBusy(true);
    try { await Api.updateMachineUsage(editLog.id, { usage_date: editForm.usage_date, material: editForm.material, volume_cc: Number(editForm.volume_cc), hours: Number(editForm.hours) }); toast.success('Log updated'); setEditLog(null); load(); loadReport(); }
    catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };
  const confirmDel = async () => { try { await Api.deleteMachineUsage(delLog.id); setDelLog(null); load(); loadReport(); } catch (e) { toast.error(e.message); } };

  const exportCsv = async () => {
    try {
      const all = await Api.machineUsage(id, { page: 1, pageSize: 100000, search: search || undefined, month: month || undefined });
      const list = all.data || [];
      if (!list.length) { toast.error('No usage to export'); return; }
      const headers = ['Date', 'Material', 'Volume (cc)', 'Runtime (Hours)', 'Logged By'];
      const data = list.map((h) => [String(h.usage_date).slice(0, 10), h.material || '', h.volume_cc ?? '', h.hours ?? '', h.logged_by || '']);
      const name = (machine?.name || 'machine').replace(/[^a-z0-9]+/gi, '-').toLowerCase();
      downloadCsv(`${name}-usage-log`, headers, data);
    } catch (e) { toast.error(e.message); }
  };

  const machine = report?.machine || data?.machine;
  const summary = report?.summary || { total_volume: 0, total_runtime: 0, total_jobs: 0 };
  const monthly = report?.monthly || [];

  return (
    <section>
      <button className="mb-3 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-800" onClick={() => navigate('/machines')}>
        <ArrowLeft className="h-4 w-4" /> Back to machines
      </button>

      {/* SECTION 1 — Machine summary */}
      <div className="card mb-4 p-4">
        <div className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-50 text-brand-600"><Cpu className="h-5 w-5" /></span>
          <div><p className="text-lg font-semibold text-slate-900">{machine?.name || 'Machine'}</p><p className="text-xs text-slate-400">{machine?.technology}</p></div>
        </div>
        <div className="mt-3 grid grid-cols-3 gap-3">
          <div className="rounded-lg bg-slate-50 px-3 py-2"><p className="text-[11px] text-slate-400">Total volume</p><p className="text-sm font-semibold text-slate-800">{num(summary.total_volume)} cc</p></div>
          <div className="rounded-lg bg-slate-50 px-3 py-2"><p className="text-[11px] text-slate-400">Total runtime</p><p className="text-sm font-semibold text-slate-800">{num(summary.total_runtime)} h</p></div>
          <div className="rounded-lg bg-slate-50 px-3 py-2"><p className="text-[11px] text-slate-400">Jobs logged</p><p className="text-sm font-semibold text-slate-800">{num(summary.total_jobs)}</p></div>
        </div>
      </div>

      {/* Single chart — Monthly Runtime & Volume */}
      <div className="card mb-4 p-4">
        <h3 className="mb-3 text-sm font-semibold text-slate-700">Monthly runtime &amp; volume</h3>
        <RuntimeVolumeChart data={report?.chart || []} />
      </div>

      {/* SECTION 2 — Monthly usage summary */}
      <div className="card mb-4 overflow-hidden">
        <h3 className="border-b border-slate-100 p-4 text-sm font-semibold text-slate-700">Monthly usage summary</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-slate-50/60 text-left text-xs uppercase text-slate-500">
              <tr><th className="px-4 py-2.5">Month</th><th className="px-4 py-2.5">Volume (cc)</th><th className="px-4 py-2.5">Runtime (h)</th><th className="px-4 py-2.5">Jobs</th><th className="px-4 py-2.5">Avg daily runtime</th><th className="px-4 py-2.5">Idle days</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {monthly.length === 0 ? <tr><td colSpan="6" className="px-4 py-6 text-center text-slate-400">No usage logged yet.</td></tr> :
                monthly.map((r) => (
                  <tr key={r.month} className="hover:bg-slate-50/60">
                    <td className="px-4 py-2.5 font-medium text-slate-800">{monthLabel(r.month)}</td>
                    <td className="px-4 py-2.5">{num(r.volume_cc)}</td>
                    <td className="px-4 py-2.5">{num(r.runtime)}</td>
                    <td className="px-4 py-2.5">{num(r.jobs)}</td>
                    <td className="px-4 py-2.5">{num(r.avg_daily_runtime)} h</td>
                    <td className="px-4 py-2.5">{num(r.idle_days)}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* SECTION 3 — Usage log history */}
      <div className="card overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-slate-100 p-3 sm:flex-row sm:items-center">
          <h3 className="text-sm font-semibold text-slate-700">Usage log</h3>
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input className="input pl-9" placeholder="Search by material or date…" value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} />
          </div>
          <Select value={month} onChange={(e) => { setMonth(e.target.value); setPage(1); }} className="sm:w-44">
            <option value="">All months</option>
            {(data?.months || []).map((mm) => <option key={mm} value={mm}>{monthLabel(mm)}</option>)}
          </Select>
          <button className="btn-secondary whitespace-nowrap" onClick={exportCsv}><Download className="h-4 w-4" /> Export CSV</button>
        </div>

        {loading && !data ? <LoadingState /> : (data?.data?.length === 0) ? (
          <EmptyState title="No usage found" message={search || month ? 'Try a different search or filter.' : 'No usage has been logged for this machine yet.'} />
        ) : (
          <div className="overflow-x-auto">
            {loading && <div className="flex justify-center py-2"><Spinner /></div>}
            <table className="w-full text-sm">
              <thead className="border-b border-slate-100 bg-slate-50/60 text-left text-xs uppercase text-slate-500">
                <tr><th className="px-4 py-2.5">Date</th><th className="px-4 py-2.5">Material</th><th className="px-4 py-2.5">Volume (cc)</th><th className="px-4 py-2.5">Runtime (h)</th>{isManager && <th className="px-4 py-2.5"></th>}</tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {(data?.data || []).map((h) => (
                  <tr key={h.id} className="hover:bg-slate-50/60">
                    <td className="px-4 py-2.5">{fmtDate(h.usage_date)}</td>
                    <td className="px-4 py-2.5">{h.material || '—'}</td>
                    <td className="px-4 py-2.5 font-medium text-slate-800">{num(h.volume_cc)}</td>
                    <td className="px-4 py-2.5">{num(h.hours)}</td>
                    {isManager && <td className="px-4 py-2.5"><div className="flex gap-2"><button className="text-slate-300 hover:text-brand-600" title="Edit" onClick={() => openEdit(h)}><Pencil className="h-4 w-4" /></button><button className="text-slate-300 hover:text-red-500" title="Delete" onClick={() => setDelLog(h)}><Trash2 className="h-4 w-4" /></button></div></td>}
                  </tr>
                ))}
              </tbody>
            </table>
            {data?.pagination && <Pagination pagination={data.pagination} onPage={setPage} />}
          </div>
        )}
      </div>

      {/* Edit log modal */}
      <Modal open={!!editLog} onClose={() => setEditLog(null)} title="Edit usage log"
        footer={<><button className="btn-secondary" onClick={() => setEditLog(null)} disabled={busy}>Cancel</button><button className="btn-primary" onClick={saveEdit} disabled={busy}>{busy ? 'Saving…' : 'Save'}</button></>}>
        <div className="space-y-3">
          <Field label="Date" required><Input type="date" value={editForm.usage_date || ''} onChange={(e) => setEditForm((f) => ({ ...f, usage_date: e.target.value }))} /></Field>
          <Field label="Material" required><Input value={editForm.material || ''} onChange={(e) => setEditForm((f) => ({ ...f, material: e.target.value }))} /></Field>
          <Field label="Volume (cc)" required><Input type="number" min="0" step="0.1" value={editForm.volume_cc || ''} onChange={(e) => setEditForm((f) => ({ ...f, volume_cc: e.target.value }))} /></Field>
          <Field label="Runtime (Hours)" required><Input type="number" min="0" step="0.1" value={editForm.hours || ''} onChange={(e) => setEditForm((f) => ({ ...f, hours: e.target.value }))} /></Field>
        </div>
      </Modal>

      <ConfirmDialog open={!!delLog} onClose={() => setDelLog(null)} onConfirm={confirmDel} title="Delete usage log?" message="This permanently removes this usage entry." />
    </section>
  );
}
