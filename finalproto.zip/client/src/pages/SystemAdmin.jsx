import { useState, useEffect, useCallback, useRef } from 'react';
import { Database, HardDrive, Cpu, Activity, Server, Shield, Save, Download, RotateCcw, Trash2, Clock, Users } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useToast } from '../context/ToastContext';
import SystemUpdates from './SystemUpdates';
import { PageHeader, LoadingState, ErrorState, EmptyState, Modal, Field, Input } from '../components/ui';

const fmtBytes = (n) => {
  if (n == null) return '—';
  if (n < 1024) return `${n} B`;
  const u = ['KB', 'MB', 'GB', 'TB']; let v = n / 1024, i = 0;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(1)} ${u[i]}`;
};
const fmtDateTime = (s) => (s ? new Date(s).toLocaleString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—');

const DOT = { healthy: 'bg-emerald-500', warning: 'bg-amber-500', critical: 'bg-red-500' };
const RING = { healthy: 'text-emerald-600', warning: 'text-amber-600', critical: 'text-red-600' };

function HealthCard({ icon: Icon, label, value, status = 'healthy', sub }) {
  return (
    <div className="card px-4 py-3">
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-2 text-xs font-medium text-slate-500"><Icon className="h-4 w-4 text-slate-400" /> {label}</span>
        <span className={`h-2.5 w-2.5 rounded-full ${DOT[status] || DOT.healthy}`} title={status} />
      </div>
      <p className={`mt-1.5 text-lg font-semibold ${RING[status] || 'text-slate-900'}`}>{value}</p>
      {sub && <p className="text-[11px] text-slate-400">{sub}</p>}
    </div>
  );
}

export default function SystemAdmin() {
  const toast = useToast();
  const [health, setHealth] = useState(null);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const [tab, setTab] = useState('health');
  const [restoreTarget, setRestoreTarget] = useState(null);
  const [confirmText, setConfirmText] = useState('');
  const [deleteTarget, setDeleteTarget] = useState(null);
  const pollRef = useRef(null);

  const loadHealth = useCallback(async () => { try { setHealth(await Api.systemHealth()); } catch { /* keep last */ } }, []);
  const loadBackups = useCallback(async () => {
    try { setData(await Api.listBackups()); setError(null); }
    catch (e) { setError(e.message); } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadHealth(); loadBackups(); }, [loadHealth, loadBackups]);
  useEffect(() => {
    pollRef.current = setInterval(loadHealth, 15000);
    return () => clearInterval(pollRef.current);
  }, [loadHealth]);

  const backupNow = async () => {
    setBusy(true);
    try { await Api.createBackup(); toast.success('Backup created'); loadBackups(); loadHealth(); }
    catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };
  const doRestore = async () => {
    if (confirmText !== 'RESTORE') return;
    setBusy(true);
    try {
      await Api.restoreBackup(restoreTarget.name);
      toast.success('Database restored. Reloading…');
      setRestoreTarget(null); setConfirmText('');
      setTimeout(() => window.location.reload(), 1500);
    } catch (e) { toast.error(e.message); setBusy(false); }
  };
  const doDelete = async () => {
    setBusy(true);
    try { await Api.deleteBackup(deleteTarget.name); toast.success('Backup deleted'); setDeleteTarget(null); loadBackups(); loadHealth(); }
    catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };
  const download = async (name) => {
    try {
      const res = await Api.downloadBackup(name);
      const url = URL.createObjectURL(res.data);
      const a = document.createElement('a'); a.href = url; a.download = name;
      document.body.appendChild(a); a.click(); document.body.removeChild(a); URL.revokeObjectURL(url);
    } catch (e) { toast.error(e.message); }
  };

  const stats = data?.stats;
  const backups = data?.backups || [];

  return (
    <section>
      <PageHeader title="System Administration" subtitle="Health, database backups and software updates for WOLF3D ERP." />

      <div className="mb-5 inline-flex rounded-lg border border-slate-200 bg-white p-0.5 text-sm">
        <button className={`rounded-md px-3 py-1.5 font-medium transition ${tab === 'health' ? 'bg-brand-600 text-white' : 'text-slate-600 hover:bg-slate-50'}`} onClick={() => setTab('health')}>Health &amp; Backups</button>
        <button className={`rounded-md px-3 py-1.5 font-medium transition ${tab === 'updates' ? 'bg-brand-600 text-white' : 'text-slate-600 hover:bg-slate-50'}`} onClick={() => setTab('updates')}>Software Updates</button>
      </div>

      {tab === 'updates' ? <SystemUpdates /> : <>
      {/* ---- System Health ---- */}
      <h3 className="mb-2 text-sm font-semibold text-slate-700">System health</h3>
      {!health ? <div className="mb-6"><LoadingState label="Reading system health…" /></div> : (
        <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          <HealthCard icon={Database} label="Database" value={health.database.label} status={health.database.status} sub={`Size ${fmtBytes(health.database.size)}`} />
          <HealthCard icon={Activity} label="Socket.IO" value={health.socket.label} status={health.socket.status} />
          <HealthCard icon={Server} label="Server" value="Running" status={health.server.status} sub={`Uptime ${Math.floor(health.server.uptime_seconds / 3600)}h ${Math.floor((health.server.uptime_seconds % 3600) / 60)}m`} />
          <HealthCard icon={Users} label="Connected users" value={health.connected_users} status="healthy" />
          <HealthCard icon={Cpu} label="Memory" value={`${health.memory.used_pct}%`} status={health.memory.status} sub={`${fmtBytes(health.memory.used)} / ${fmtBytes(health.memory.total)}`} />
          <HealthCard icon={HardDrive} label="Disk" value={health.disk.used_pct != null ? `${health.disk.used_pct}%` : health.disk.label} status={health.disk.status} sub={health.disk.free != null ? `${fmtBytes(health.disk.free)} free` : undefined} />
          <HealthCard icon={Save} label="Last backup" value={health.backup.last_backup ? fmtDateTime(health.backup.last_backup.created_at) : 'None yet'} status={health.backup.status} sub={`${health.backup.count} stored`} />
          <HealthCard icon={Shield} label="Version" value={`v${health.version}`} status="healthy" />
        </div>
      )}

      {/* ---- Database backups ---- */}
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-sm font-semibold text-slate-700">Database backups</h3>
        <button className="btn-primary" onClick={backupNow} disabled={busy}><Save className="h-4 w-4" /> {busy ? 'Working…' : 'Backup now'}</button>
      </div>

      {stats && (
        <div className="mb-3 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div className="card px-4 py-3"><p className="text-xs text-slate-400">Last successful</p><p className="text-sm font-semibold text-slate-800">{stats.last_backup ? fmtDateTime(stats.last_backup.created_at) : '—'}</p></div>
          <div className="card px-4 py-3"><p className="text-xs text-slate-400">Total size</p><p className="text-sm font-semibold text-slate-800">{fmtBytes(stats.total_size)}</p></div>
          <div className="card px-4 py-3"><p className="text-xs text-slate-400">Stored backups</p><p className="text-sm font-semibold text-slate-800">{stats.count} <span className="text-xs font-normal text-slate-400">/ {stats.max_backups} kept</span></p></div>
          <div className="card px-4 py-3"><p className="flex items-center gap-1 text-xs text-slate-400"><Clock className="h-3 w-3" /> Next scheduled</p><p className="text-sm font-semibold text-slate-800">{fmtDateTime(stats.next_scheduled)}</p></div>
        </div>
      )}

      {loading ? <LoadingState /> : error ? <ErrorState message={error} onRetry={loadBackups} /> : backups.length === 0 ? (
        <div className="card"><EmptyState title="No backups yet" message="Create one now, or wait for the nightly automatic backup at 2:00 AM." /></div>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-100 bg-slate-50/60 text-left text-xs uppercase text-slate-500">
              <tr><th className="px-4 py-2.5">Backup file</th><th className="px-4 py-2.5">Created</th><th className="px-4 py-2.5">Size</th><th className="px-4 py-2.5 text-right">Actions</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {backups.map((b) => (
                <tr key={b.name} className="hover:bg-slate-50/50">
                  <td className="px-4 py-2.5 font-mono text-xs text-slate-700">{b.name}</td>
                  <td className="px-4 py-2.5 text-slate-500">{fmtDateTime(b.created_at)}</td>
                  <td className="px-4 py-2.5 text-slate-500">{fmtBytes(b.size)}</td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center justify-end gap-1">
                      <button className="rounded p-1.5 text-slate-500 hover:bg-slate-100 hover:text-brand-600" title="Download" onClick={() => download(b.name)}><Download className="h-4 w-4" /></button>
                      <button className="rounded p-1.5 text-slate-500 hover:bg-amber-50 hover:text-amber-600" title="Restore" onClick={() => { setRestoreTarget(b); setConfirmText(''); }}><RotateCcw className="h-4 w-4" /></button>
                      <button className="rounded p-1.5 text-slate-500 hover:bg-red-50 hover:text-red-600" title="Delete" onClick={() => setDeleteTarget(b)}><Trash2 className="h-4 w-4" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Restore confirmation (must type RESTORE) */}
      <Modal open={!!restoreTarget} onClose={() => { setRestoreTarget(null); setConfirmText(''); }} title="Restore database"
        footer={<><button className="btn-secondary" onClick={() => { setRestoreTarget(null); setConfirmText(''); }} disabled={busy}>Cancel</button>
          <button className="btn-danger" onClick={doRestore} disabled={busy || confirmText !== 'RESTORE'}>{busy ? 'Restoring…' : 'Restore database'}</button></>}>
        <div className="space-y-3">
          <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">
            This will <strong>replace the entire live database</strong> with the contents of this backup. Current data not in the backup will be permanently lost. This cannot be undone.
          </div>
          <p className="text-xs text-slate-500 font-mono break-all">{restoreTarget?.name}</p>
          <Field label="Type RESTORE to confirm">
            <Input value={confirmText} onChange={(e) => setConfirmText(e.target.value)} placeholder="RESTORE" autoFocus />
          </Field>
        </div>
      </Modal>

      {/* Delete confirmation */}
      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Delete backup"
        footer={<><button className="btn-secondary" onClick={() => setDeleteTarget(null)} disabled={busy}>Cancel</button>
          <button className="btn-danger" onClick={doDelete} disabled={busy}>{busy ? 'Deleting…' : 'Delete'}</button></>}>
        <p className="text-sm text-slate-600">Permanently delete <span className="font-mono text-xs">{deleteTarget?.name}</span>? This cannot be undone.</p>
      </Modal>
      </>}
    </section>
  );
}
