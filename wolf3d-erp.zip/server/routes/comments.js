const express = require('express');
const { pool } = require('../db/pool');
const { authGuard } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler } = require('../middleware/errorHandler');
const { emitEvent } = require('../socket/socket');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { project_id, task_id, notice_id } = req.query;
  const conditions = [];
  const values = [];
  let i = 1;
  if (project_id) { conditions.push(`c.project_id = $${i}`); values.push(project_id); i++; }
  if (task_id) { conditions.push(`c.task_id = $${i}`); values.push(task_id); i++; }
  if (notice_id) { conditions.push(`c.notice_id = $${i}`); values.push(notice_id); i++; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const { rows } = await pool.query(
    `SELECT c.*, u.name AS user_name FROM comments c
     LEFT JOIN users u ON u.id = c.user_id ${where} ORDER BY c.created_at ASC`,
    values
  );
  res.json({ data: rows });
}));

router.post('/', validate({ body: schemas.createComment }), asyncHandler(async (req, res) => {
  const { project_id, task_id, notice_id, content } = req.body;
  const { rows } = await pool.query(
    `INSERT INTO comments (user_id, project_id, task_id, notice_id, content)
     VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [req.user.id, project_id || null, task_id || null, notice_id || null, content]
  );
  const comment = { ...rows[0], user_name: req.user.name };
  emitEvent('comment_added', comment);
  res.status(201).json(comment);
}));

module.exports = router;
