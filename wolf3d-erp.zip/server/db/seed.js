const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const { pool } = require('./pool');
const config = require('../config/env');

const DEFAULT_DEPARTMENTS = [
  'Design',
  'Reverse Engineering',
  'Quality',
  'Dispatch',
  'Management',
  'General'
];

async function seedDepartments() {
  for (const name of DEFAULT_DEPARTMENTS) {
    await pool.query(
      'INSERT INTO departments (name) VALUES ($1) ON CONFLICT (name) DO NOTHING',
      [name]
    );
  }
}

async function seedAdmin() {
  const { rowCount } = await pool.query(
    "SELECT id FROM users WHERE role = 'manager' LIMIT 1"
  );
  if (rowCount > 0) return;

  let password = config.ADMIN_PASSWORD;
  let generated = false;
  if (!password) {
    // Strong random temporary password, printed once. Forces change on first login.
    password = crypto.randomBytes(12).toString('base64').replace(/[^a-zA-Z0-9]/g, '').slice(0, 16) + 'A1!';
    generated = true;
  }

  const passwordHash = await bcrypt.hash(password, config.BCRYPT_ROUNDS);
  await pool.query(
    `INSERT INTO users (name, username, password_hash, role, status, must_change_password)
     VALUES ($1, $2, $3, 'manager', 'active', $4)`,
    [config.ADMIN_NAME, config.ADMIN_USERNAME, passwordHash, generated]
  );

  console.log('====================================================');
  console.log(' WOLF3D ERP — bootstrap administrator account created');
  console.log(`   username: ${config.ADMIN_USERNAME}`);
  if (generated) {
    console.log(`   password: ${password}`);
    console.log('   (randomly generated — change it on first login)');
  } else {
    console.log('   password: (from ADMIN_PASSWORD env var)');
  }
  console.log('====================================================');
}

async function seed() {
  await seedDepartments();
  await seedAdmin();
}

module.exports = { seed };
