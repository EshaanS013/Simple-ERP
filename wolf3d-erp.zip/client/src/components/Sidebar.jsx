import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard, FolderKanban, ClipboardList, CheckSquare, Building2,
  ShieldCheck, Truck, Megaphone, Network, BarChart3, Users, Activity
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/projects', label: 'Projects', icon: FolderKanban },
  { to: '/work-orders', label: 'Work Orders', icon: ClipboardList },
  { to: '/tasks', label: 'Tasks', icon: CheckSquare },
  { to: '/quality', label: 'Quality Control', icon: ShieldCheck },
  { to: '/dispatch', label: 'Dispatch', icon: Truck },
  { to: '/clients', label: 'Clients', icon: Building2 },
  { to: '/notices', label: 'Notices', icon: Megaphone },
  { to: '/departments', label: 'Departments', icon: Network },
  { to: '/activity', label: 'Activity', icon: Activity },
  { to: '/reports', label: 'Reports', icon: BarChart3 },
  { to: '/users', label: 'Team', icon: Users, managerOnly: true }
];

export default function Sidebar({ onNavigate }) {
  const { isManager } = useAuth();
  const items = NAV.filter((n) => !n.managerOnly || isManager);
  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-slate-200 bg-white">
      <div className="flex items-center gap-2.5 px-5 py-4">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 text-sm font-bold text-white">W</div>
        <div className="leading-tight">
          <p className="text-sm font-semibold text-slate-900">WOLF3D</p>
          <p className="text-[11px] text-slate-400">ERP Platform</p>
        </div>
      </div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 py-2">
        {items.map(({ to, label, icon: Icon, end }) => (
          <NavLink key={to} to={to} end={end} onClick={onNavigate}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition ${
                isActive ? 'bg-brand-50 text-brand-700' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}>
            <Icon className="h-[18px] w-[18px]" />
            {label}
          </NavLink>
        ))}
      </nav>
      <div className="border-t border-slate-100 px-5 py-3 text-[11px] text-slate-400">
        WOLF3D Technologies · v1.0
      </div>
    </aside>
  );
}
