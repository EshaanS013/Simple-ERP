const { z } = require('zod');

const id = z.coerce.number().int().positive();
const idParam = z.object({ id });

// ---- Password policy ----
const password = z
  .string()
  .min(8, 'must be at least 8 characters')
  .max(128, 'is too long')
  .refine((v) => /[A-Za-z]/.test(v) && /[0-9]/.test(v), {
    message: 'must include at least one letter and one number'
  });

const optionalDate = z
  .string()
  .trim()
  .regex(/^\d{4}-\d{2}-\d{2}$/, 'must be a valid date (YYYY-MM-DD)')
  .nullish()
  .or(z.literal('').transform(() => null));

const nonEmpty = (label) => z.string().trim().min(1, `${label} is required`);

const listQuery = z.object({
  page: z.coerce.number().int().positive().optional(),
  pageSize: z.coerce.number().int().positive().max(200).optional(),
  search: z.string().trim().optional(),
  status: z.string().trim().optional(),
  sort: z.string().trim().optional(),
  assigned_to: z.coerce.number().int().positive().optional(),
  project_id: z.coerce.number().int().positive().optional()
});

const projectStatus = z.enum(['pending', 'in_progress', 'completed', 'delivered', 'cancelled']);
const taskStatus = z.enum(['awaiting', 'in_progress', 'partially_complete', 'completed', 'blocked', 'cancelled']);
const taskPriority = z.enum(['low', 'medium', 'high', 'critical']);
const qualityStatus = z.enum(['pending', 'in_review', 'approved', 'rejected', 'completed']);
const dispatchStatus = z.enum(['awaiting', 'ready', 'dispatched', 'delivered', 'returned']);
const role = z.enum(['manager', 'employee']);

const schemas = {
  idParam,

  login: z.object({
    username: nonEmpty('Username'),
    password: z.string().min(1, 'Password is required')
  }),

  changePassword: z.object({
    currentPassword: z.string().min(1, 'Current password is required'),
    newPassword: password
  }),

  createUser: z.object({
    name: nonEmpty('Name'),
    username: nonEmpty('Username').regex(/^[a-zA-Z0-9._-]+$/, 'Username may only contain letters, numbers, . _ -'),
    password,
    role,
    department_id: id.nullish()
  }),

  updateUser: z.object({
    name: nonEmpty('Name'),
    role,
    status: z.enum(['active', 'inactive']),
    department_id: id.nullish()
  }),

  resetPassword: z.object({ password }),

  createClient: z.object({
    name: nonEmpty('Client name'),
    contact_person: z.string().trim().optional().nullable(),
    email: z.string().trim().email('must be a valid email').optional().nullable().or(z.literal('').transform(() => null)),
    phone: z.string().trim().max(40).optional().nullable(),
    address: z.string().trim().optional().nullable()
  }),

  createDepartment: z.object({
    name: nonEmpty('Department name').max(60, 'Department name is too long')
  }),

  createWorkOrder: z.object({
    work_order_number: nonEmpty('Work order number'),
    client_id: id.nullish(),
    service_type: nonEmpty('Service type'),
    part_name: z.string().trim().optional().nullable(),
    quantity: z.coerce.number().int().min(0).default(1),
    description: z.string().trim().optional().nullable(),
    status: projectStatus.default('pending'),
    assigned_to: id.nullish(),
    submission_date: optionalDate
  }),

  updateWorkOrder: z.object({
    client_id: id.nullish(),
    service_type: nonEmpty('Service type'),
    part_name: z.string().trim().optional().nullable(),
    quantity: z.coerce.number().int().min(0).default(1),
    description: z.string().trim().optional().nullable(),
    status: projectStatus,
    assigned_to: id.nullish(),
    submission_date: optionalDate
  }),

  createProject: z.object({
    project_number: nonEmpty('Project number'),
    project_name: nonEmpty('Project name'),
    client_id: id.nullish(),
    part_name: z.string().trim().optional().nullable(),
    service_type: z.string().trim().optional().nullable(),
    assigned_to: z.array(id).default([]),
    progress_percent: z.coerce.number().int().min(0).max(100).default(0),
    start_date: optionalDate,
    deadline: optionalDate,
    status: projectStatus.default('pending'),
    remarks: z.string().trim().optional().nullable(),
    work_order_id: id.nullish()
  }),

  updateProject: z.object({
    project_name: nonEmpty('Project name'),
    client_id: id.nullish(),
    part_name: z.string().trim().optional().nullable(),
    service_type: z.string().trim().optional().nullable(),
    assigned_to: z.array(id).default([]),
    progress_percent: z.coerce.number().int().min(0).max(100).default(0),
    start_date: optionalDate,
    deadline: optionalDate,
    status: projectStatus,
    remarks: z.string().trim().optional().nullable(),
    work_order_id: id.nullish()
  }),

  createTask: z.object({
    task_name: nonEmpty('Task name'),
    project_id: id.nullish(),
    assigned_to: id.nullish(),
    deadline: optionalDate,
    priority: taskPriority.default('medium'),
    status: taskStatus.default('awaiting'),
    comments: z.string().trim().optional().nullable()
  }),

  updateTask: z.object({
    task_name: nonEmpty('Task name'),
    project_id: id.nullish(),
    assigned_to: id.nullish(),
    deadline: optionalDate,
    priority: taskPriority,
    status: taskStatus,
    comments: z.string().trim().optional().nullable()
  }),

  createNotice: z.object({
    title: nonEmpty('Title'),
    content: nonEmpty('Content'),
    urgent: z.coerce.boolean().default(false),
    pinned: z.coerce.boolean().default(false)
  }),

  createUpdate: z.object({
    department: nonEmpty('Department'),
    message: nonEmpty('Message')
  }),

  createQuality: z.object({
    project_id: id.nullish(),
    part_name: z.string().trim().optional().nullable(),
    xyz_dimension: z.string().trim().optional().nullable(),
    critical_dimensions: z.string().trim().optional().nullable(),
    inspection_notes: z.string().trim().optional().nullable(),
    report_number: z.string().trim().optional().nullable(),
    quality_status: qualityStatus.default('pending'),
    inspector: id.nullish(),
    date: optionalDate
  }),

  updateQuality: z.object({
    project_id: id.nullish(),
    part_name: z.string().trim().optional().nullable(),
    xyz_dimension: z.string().trim().optional().nullable(),
    critical_dimensions: z.string().trim().optional().nullable(),
    inspection_notes: z.string().trim().optional().nullable(),
    report_number: z.string().trim().optional().nullable(),
    quality_status: qualityStatus,
    inspector: id.nullish(),
    date: optionalDate
  }),

  createDispatch: z.object({
    project_id: id.nullish(),
    client_id: id.nullish(),
    submission_date: optionalDate,
    dispatch_date: optionalDate,
    tracking_number: z.string().trim().optional().nullable(),
    courier: z.string().trim().optional().nullable(),
    status: dispatchStatus.default('awaiting'),
    remarks: z.string().trim().optional().nullable()
  }),

  updateDispatch: z.object({
    project_id: id.nullish(),
    client_id: id.nullish(),
    submission_date: optionalDate,
    dispatch_date: optionalDate,
    tracking_number: z.string().trim().optional().nullable(),
    courier: z.string().trim().optional().nullable(),
    status: dispatchStatus,
    remarks: z.string().trim().optional().nullable()
  }),

  createComment: z.object({
    project_id: id.nullish(),
    task_id: id.nullish(),
    notice_id: id.nullish(),
    content: nonEmpty('Comment')
  }),

  upsertSetting: z.object({
    key: nonEmpty('Key'),
    value: z.string().nullable().optional()
  }),

  listQuery
};

module.exports = schemas;
