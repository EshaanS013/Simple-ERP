import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Network, MessageSquare, Users, ChevronRight, Plus, Pencil, Trash2 } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PageHeader, LoadingState, ErrorState, EmptyState, Modal, ConfirmDialog, Field, Input } from '../components/ui';

export default function Departments() {
  const navigate = useNavigate();
  const { isManager } = useAuth();
  const toast = useToast();
  const [departments, setDepartments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [editing, setEditing] = useState(null); // null=closed, {}=create, {id,name}=rename
  const [deleting, setDeleting] = useState(null);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try {
      const res = await Api.departments();
      setDepartments(res.data || []);
    } catch (e) { setError(e.message); } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const refresh = () => load();
    const events = ['department_created', 'department_updated', 'department_deleted', 'update_created'];
    events.forEach((e) => socket.on(e, refresh));
    return () => events.forEach((e) => socket.off(e, refresh));
  }, [load]);

  const openCreate = () => { setName(''); setEditing({}); };
  const openRename = (e, d) => { e.stopPropagation(); setName(d.name); setEditing(d); };
  const openDelete = (e, d) => { e.stopPropagation(); setDeleting(d); };

  const save = async () => {
    const trimmed = name.trim();
    if (!trimmed) { toast.error('Department name is required'); return; }
    setBusy(true);
    try {
      if (editing.id) {
        await Api.update('departments', editing.id, { name: trimmed });
        toast.success('Department renamed');
      } else {
        await Api.create('departments', { name: trimmed });
        toast.success('Department created');
      }
      setEditing(null);
      load();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const confirmDelete = async () => {
    setBusy(true);
    try {
      await Api.remove('departments', deleting.id);
      toast.success('Department deleted');
      setDeleting(null);
      load();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  return (
    <section>
      <PageHeader title="Departments" subtitle="Team channels and the latest updates from each department.">
        {isManager && <button className="btn-primary" onClick={openCreate}><Plus className="h-4 w-4" /> Add Department</button>}
      </PageHeader>

      {loading ? <LoadingState /> : error ? <ErrorState message={error} onRetry={load} /> : departments.length === 0 ? (
        <div className="card"><EmptyState title="No departments" message={isManager ? 'Add your first department to get started.' : 'No departments have been set up yet.'}
          action={isManager ? <button className="btn-primary" onClick={openCreate}><Plus className="h-4 w-4" /> Add Department</button> : null} /></div>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {departments.map((d) => (
            <div key={d.id} onClick={() => navigate(`/departments/${encodeURIComponent(d.name)}`)}
              className="card group flex cursor-pointer items-center gap-4 p-4 text-left transition hover:border-brand-200 hover:shadow-pop">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-brand-50 text-brand-600"><Network className="h-5 w-5" /></div>
              <div className="min-w-0 flex-1">
                <p className="truncate font-semibold text-slate-900">{d.name}</p>
                <p className="flex items-center gap-3 text-xs text-slate-500">
                  <span className="flex items-center gap-1"><MessageSquare className="h-3.5 w-3.5" /> {d.updates_count || 0}</span>
                  <span className="flex items-center gap-1"><Users className="h-3.5 w-3.5" /> {d.member_count || 0}</span>
                </p>
              </div>
              {isManager ? (
                <div className="flex items-center gap-1 opacity-0 transition group-hover:opacity-100">
                  <button title="Rename" onClick={(e) => openRename(e, d)} className="btn-ghost btn-sm"><Pencil className="h-4 w-4" /></button>
                  <button title="Delete" onClick={(e) => openDelete(e, d)} className="btn-ghost btn-sm text-red-500 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                </div>
              ) : (
                <ChevronRight className="h-4 w-4 text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-brand-500" />
              )}
            </div>
          ))}
        </div>
      )}

      {/* Create / rename */}
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Rename Department' : 'Add Department'} size="sm"
        footer={<>
          <button className="btn-secondary" onClick={() => setEditing(null)} disabled={busy}>Cancel</button>
          <button className="btn-primary" onClick={save} disabled={busy}>{busy ? 'Saving…' : editing?.id ? 'Save changes' : 'Create'}</button>
        </>}>
        <Field label="Department name" required>
          <Input value={name} autoFocus onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && save()} placeholder="e.g. Engineering" />
        </Field>
      </Modal>

      <ConfirmDialog open={!!deleting} busy={busy} onClose={() => setDeleting(null)} onConfirm={confirmDelete}
        title="Delete department?"
        message={deleting ? `“${deleting.name}” will be removed. Its ${deleting.updates_count || 0} update(s) will be deleted and ${deleting.member_count || 0} member(s) will be unassigned (their accounts are not affected).` : ''} />
    </section>
  );
}
