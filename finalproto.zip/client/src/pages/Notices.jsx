import { useState, useEffect, useCallback } from 'react';
import { Plus, Pin, Trash2, Megaphone } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PageHeader, LoadingState, ErrorState, EmptyState, Modal, ConfirmDialog, Field, Input, Textarea } from '../components/ui';

const timeAgo = (d) => {
  const sec = Math.floor((Date.now() - new Date(d)) / 1000);
  if (sec < 60) return 'just now';
  if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  if (sec < 86400) return `${Math.floor(sec / 3600)}h ago`;
  return new Date(d).toLocaleDateString();
};

export default function Notices() {
  const { isManager } = useAuth();
  const toast = useToast();
  const [notices, setNotices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [creating, setCreating] = useState(false);
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ title: '', content: '', urgent: false, pinned: false });

  const load = useCallback(async () => {
    setError(null);
    try {
      const res = await Api.notices();
      setNotices(res.data || []);
    } catch (e) { setError(e.message); } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const refresh = () => load();
    socket.on('notice_created', refresh);
    socket.on('notice_deleted', refresh);
    return () => { socket.off('notice_created', refresh); socket.off('notice_deleted', refresh); };
  }, [load]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async () => {
    if (!form.title.trim() || !form.content.trim()) { toast.error('Title and content are required'); return; }
    setBusy(true);
    try {
      await Api.createNotice({ title: form.title.trim(), content: form.content.trim(), urgent: form.urgent, pinned: form.pinned });
      toast.success('Notice posted');
      setCreating(false);
      setForm({ title: '', content: '', urgent: false, pinned: false });
      load();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const confirmDelete = async () => {
    setBusy(true);
    try {
      await Api.deleteNotice(deleting.id);
      toast.success('Notice deleted');
      setDeleting(null);
      load();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  return (
    <section>
      <PageHeader title="Notices" subtitle="Company-wide announcements and alerts.">
        {isManager && <button className="btn-primary" onClick={() => setCreating(true)}><Plus className="h-4 w-4" /> Post Notice</button>}
      </PageHeader>

      {loading ? <LoadingState /> : error ? <ErrorState message={error} onRetry={load} /> : notices.length === 0 ? (
        <div className="card"><EmptyState title="No notices yet" message={isManager ? 'Post your first announcement.' : 'Check back later for updates.'} icon={Megaphone} /></div>
      ) : (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {notices.map((n) => (
            <div key={n.id} className={`card p-4 ${n.urgent ? 'border-red-200' : ''}`}>
              <div className="mb-1.5 flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  {n.pinned && <Pin className="h-4 w-4 text-amber-500" />}
                  <h3 className="font-semibold text-slate-900">{n.title}</h3>
                </div>
                <div className="flex items-center gap-1">
                  {n.urgent && <span className="badge bg-red-50 text-red-700">Urgent</span>}
                  {isManager && (
                    <button onClick={() => setDeleting(n)} className="btn-ghost btn-sm text-red-500 hover:bg-red-50"><Trash2 className="h-4 w-4" /></button>
                  )}
                </div>
              </div>
              <p className="whitespace-pre-wrap text-sm text-slate-600">{n.content}</p>
              <p className="mt-3 text-xs text-slate-400">{n.author_name ? `${n.author_name} · ` : ''}{timeAgo(n.created_at)}</p>
            </div>
          ))}
        </div>
      )}

      <Modal open={creating} onClose={() => setCreating(false)} title="Post a Notice" size="md"
        footer={<>
          <button className="btn-secondary" onClick={() => setCreating(false)} disabled={busy}>Cancel</button>
          <button className="btn-primary" onClick={submit} disabled={busy}>{busy ? 'Posting…' : 'Post Notice'}</button>
        </>}>
        <div className="space-y-4">
          <Field label="Title" required><Input value={form.title} onChange={(e) => set('title', e.target.value)} placeholder="Notice title" /></Field>
          <Field label="Content" required><Textarea rows={5} value={form.content} onChange={(e) => set('content', e.target.value)} placeholder="What do you want to announce?" /></Field>
          <div className="flex items-center gap-6">
            <label className="flex items-center gap-2 text-sm text-slate-700"><input type="checkbox" className="h-4 w-4 rounded border-slate-300 text-brand-600" checked={form.urgent} onChange={(e) => set('urgent', e.target.checked)} /> Mark as urgent</label>
            <label className="flex items-center gap-2 text-sm text-slate-700"><input type="checkbox" className="h-4 w-4 rounded border-slate-300 text-brand-600" checked={form.pinned} onChange={(e) => set('pinned', e.target.checked)} /> Pin to top</label>
          </div>
        </div>
      </Modal>

      <ConfirmDialog open={!!deleting} busy={busy} onClose={() => setDeleting(null)} onConfirm={confirmDelete}
        title="Delete notice?" message={deleting ? `“${deleting.title}” will be removed for everyone.` : ''} />
    </section>
  );
}
