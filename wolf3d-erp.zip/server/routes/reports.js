const express = require('express');
const { pool } = require('../db/pool');
const { authGuard } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();
router.use(authGuard);

async function buildSummary() {
  const [projects, tasks, quality, dispatch, workOrders, totals] = await Promise.all([
    pool.query('SELECT status, COUNT(*)::int count FROM projects GROUP BY status'),
    pool.query('SELECT status, COUNT(*)::int count FROM tasks GROUP BY status'),
    pool.query('SELECT quality_status AS status, COUNT(*)::int count FROM quality_records GROUP BY quality_status'),
    pool.query('SELECT status, COUNT(*)::int count FROM dispatch_records GROUP BY status'),
    pool.query('SELECT status, COUNT(*)::int count FROM work_orders GROUP BY status'),
    pool.query(`SELECT
       (SELECT COUNT(*)::int FROM projects) AS total_projects,
       (SELECT COUNT(*)::int FROM projects WHERE status IN ('completed','delivered')) AS completed_projects,
       (SELECT COUNT(*)::int FROM work_orders) AS total_work_orders,
       (SELECT COUNT(*)::int FROM work_orders WHERE status = 'pending') AS pending_work_orders,
       (SELECT COUNT(*)::int FROM tasks) AS total_tasks,
       (SELECT COUNT(*)::int FROM tasks WHERE status = 'in_progress') AS in_progress_tasks,
       (SELECT COUNT(*)::int FROM tasks WHERE status = 'completed') AS completed_tasks,
       (SELECT COUNT(*)::int FROM clients) AS total_clients`)
  ]);
  return {
    totals: totals.rows[0],
    projects: projects.rows,
    tasks: tasks.rows,
    quality: quality.rows,
    dispatch: dispatch.rows,
    workOrders: workOrders.rows
  };
}

router.get('/', asyncHandler(async (req, res) => res.json(await buildSummary())));
router.get('/summary', asyncHandler(async (req, res) => res.json(await buildSummary())));

module.exports = router;
