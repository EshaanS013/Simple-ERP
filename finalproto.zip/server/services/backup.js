// Automated PostgreSQL backup/restore service.
// - pg_dump (compressed) to BACKUPS_DIR, runs WITHOUT stopping the ERP.
// - keeps the latest MAX_BACKUPS, prunes older ones.
// - restore replaces the current database from a chosen backup.
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { spawn } = require('child_process');
const config = require('../config/env');
const logger = require('../utils/logger');

const BACKUPS_DIR = process.env.BACKUPS_DIR || path.join(__dirname, '..', 'backups');
const MAX_BACKUPS = Number(process.env.MAX_BACKUPS || 30);
// Allow pointing at a specific libpq bin dir (sandbox); empty = use PATH (Docker).
const PG_BIN = process.env.PG_BIN_DIR ? (d) => path.join(process.env.PG_BIN_DIR, d) : (d) => d;
const PREFIX = 'wolf3d_backup_';

try { fs.mkdirSync(BACKUPS_DIR, { recursive: true }); } catch { /* exists */ }

function stamp(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}_${p(d.getMonth() + 1)}_${p(d.getDate())}_${p(d.getHours())}_${p(d.getMinutes())}`;
}
const isBackup = (f) => f.startsWith(PREFIX) && f.endsWith('.sql.gz');

function listBackups() {
  let files = [];
  try { files = fs.readdirSync(BACKUPS_DIR).filter(isBackup); } catch { return []; }
  return files.map((name) => {
    const st = fs.statSync(path.join(BACKUPS_DIR, name));
    return { name, size: st.size, created_at: st.mtime.toISOString() };
  }).sort((a, b) => b.name.localeCompare(a.name));
}

function pruneBackups() {
  const all = listBackups();
  const remove = all.slice(MAX_BACKUPS);
  for (const b of remove) {
    try { fs.unlinkSync(path.join(BACKUPS_DIR, b.name)); } catch { /* ignore */ }
  }
  return remove.length;
}

// Verify a backup file is a valid gzip that decompresses to a real SQL dump.
function verifyBackupFile(file) {
  return new Promise((resolve, reject) => {
    let head = '';
    let done = false;
    const gunzip = zlib.createGunzip();
    const rs = fs.createReadStream(file);
    const finish = () => {
      if (done) return; done = true;
      if (/PostgreSQL database dump|SET statement_timeout|CREATE TABLE|DROP TABLE|^--/m.test(head)) resolve(true);
      else reject(new Error('decompressed content is not a PostgreSQL dump'));
    };
    gunzip.on('data', (chunk) => { head += chunk.toString('utf8'); if (head.length > 2000) { rs.destroy(); gunzip.destroy(); finish(); } });
    gunzip.on('end', finish);
    gunzip.on('error', (e) => { if (!done) { done = true; reject(new Error(`gzip is corrupt: ${e.message}`)); } });
    rs.on('error', (e) => { if (!done) { done = true; reject(e); } });
    rs.pipe(gunzip);
  });
}

// Startup self-check: is pg_dump usable? Logged so failures are diagnosable.
function checkTools() {
  return new Promise((resolve) => {
    const v = spawn(PG_BIN('pg_dump'), ['--version'], { env: process.env });
    let out = '';
    v.stdout.on('data', (d) => { out += d.toString(); });
    v.on('error', () => { logger.error('backup_tools', 'pg_dump not found — backups will fail until postgresql-client is installed'); resolve({ ok: false }); });
    v.on('close', (code) => { code === 0 ? (logger.info('backup_tools', `pg_dump available: ${out.trim()}`), resolve({ ok: true, version: out.trim() })) : resolve({ ok: false }); });
  });
}

// Run pg_dump, stream through gzip into a temp file, then atomically rename.
function createBackup() {
  return new Promise((resolve, reject) => {
    const name = `${PREFIX}${stamp()}.sql.gz`;
    const finalPath = path.join(BACKUPS_DIR, name);
    const tmpPath = `${finalPath}.part`;
    const out = fs.createWriteStream(tmpPath);
    const gzip = zlib.createGzip();
    const dump = spawn(PG_BIN('pg_dump'), ['--clean', '--if-exists', '--no-owner', '--no-privileges', config.DATABASE_URL], { env: process.env });
    let errBuf = '';
    dump.stderr.on('data', (d) => { errBuf += d.toString(); });
    dump.on('error', (e) => { cleanup(); reject(new Error(`pg_dump failed to start: ${e.message}`)); });
    dump.stdout.pipe(gzip).pipe(out);
    const cleanup = () => { try { fs.unlinkSync(tmpPath); } catch { /* ignore */ } };
    out.on('error', (e) => { cleanup(); reject(e); });
    dump.on('close', (code) => {
      if (code !== 0) {
        cleanup();
        const hint = /not found|ENOENT/i.test(errBuf) ? ' (pg_dump not found — ensure postgresql-client is installed in the image)' : '';
        const msg = `pg_dump exited ${code}${hint}: ${errBuf.slice(0, 300)}`;
        logger.backup('failed', msg);
        return reject(new Error(msg));
      }
      out.on('finish', () => {
        (async () => {
          try {
            fs.renameSync(tmpPath, finalPath);
            // VERIFY: file exists, size > 0, and the gzip decompresses to a real SQL dump.
            const size = fs.statSync(finalPath).size;
            if (size === 0) throw new Error('backup file is empty');
            await verifyBackupFile(finalPath);
            pruneBackups();
            logger.backup('success', `Created ${name}`, { size });
            resolve({ name, size, created_at: new Date().toISOString(), verified: true });
          } catch (e) {
            try { fs.unlinkSync(finalPath); } catch { /* ignore */ }
            cleanup();
            logger.backup('failed', `verification failed: ${e.message}`);
            reject(new Error(`Backup verification failed: ${e.message}`));
          }
        })();
      });
    });
  });
}

// Restore the database from a backup (gunzip -> psql). Replaces current data.
async function restoreBackup(name) {
  if (!isBackup(name)) throw new Error('Invalid backup name');
  const file = path.join(BACKUPS_DIR, path.basename(name));
  if (!fs.existsSync(file)) throw new Error('Backup not found');
  // Validate the archive BEFORE we touch the live database.
  await verifyBackupFile(file);
  await new Promise((resolve, reject) => {
    const psql = spawn(PG_BIN('psql'), ['-v', 'ON_ERROR_STOP=1', '--single-transaction', config.DATABASE_URL], { env: process.env });
    let errBuf = '';
    psql.stderr.on('data', (d) => { errBuf += d.toString(); });
    psql.on('error', (e) => reject(new Error(`psql failed to start: ${e.message}`)));
    fs.createReadStream(file).pipe(zlib.createGunzip()).pipe(psql.stdin);
    psql.on('close', (code) => {
      if (code !== 0) { const msg = `restore failed (psql ${code}): ${errBuf.slice(0, 300)}`; logger.restore('failed', msg, { name }); return reject(new Error(msg)); }
      resolve();
    });
  });
  // Post-restore health: confirm the database is reachable and core tables exist.
  try {
    const { pool } = require('../db/pool');
    const r = await pool.query("SELECT (SELECT count(*) FROM users) AS users, to_regclass('public.production_records') IS NOT NULL AS has_prod");
    if (!r.rows[0].has_prod) throw new Error('core tables missing after restore');
    logger.restore('success', `Restored ${name}`, { name, users: r.rows[0].users });
    return { name, users: Number(r.rows[0].users) };
  } catch (e) {
    logger.restore('failed', `post-restore health check failed: ${e.message}`, { name });
    throw new Error(`Restore applied but health check failed: ${e.message}`);
  }
}

function deleteBackup(name) {
  if (!isBackup(name)) throw new Error('Invalid backup name');
  fs.unlinkSync(path.join(BACKUPS_DIR, path.basename(name)));
}

function backupPath(name) {
  if (!isBackup(name)) throw new Error('Invalid backup name');
  const file = path.join(BACKUPS_DIR, path.basename(name));
  if (!fs.existsSync(file)) throw new Error('Backup not found');
  return file;
}

// 2:00 AM local time, recomputed after each run (no external cron needed).
let timer = null;
function msUntilNext2am() {
  const now = new Date();
  const next = new Date(now);
  next.setHours(2, 0, 0, 0);
  if (next <= now) next.setDate(next.getDate() + 1);
  return next - now;
}
function scheduleNightly() {
  if (timer) clearTimeout(timer);
  const delay = msUntilNext2am();
  timer = setTimeout(async function run() {
    try { await createBackup(); } catch (e) { logger.backup('failed', e.message); }
    timer = setTimeout(run, 24 * 60 * 60 * 1000); // then every 24h
  }, delay);
  if (timer.unref) timer.unref();
  return new Date(Date.now() + delay).toISOString();
}
function nextScheduled() {
  return new Date(Date.now() + msUntilNext2am()).toISOString();
}

function getStats() {
  const all = listBackups();
  const totalSize = all.reduce((s, b) => s + b.size, 0);
  return {
    count: all.length,
    total_size: totalSize,
    last_backup: all[0] || null,
    next_scheduled: nextScheduled(),
    max_backups: MAX_BACKUPS
  };
}

module.exports = {
  BACKUPS_DIR, MAX_BACKUPS,
  createBackup, listBackups, restoreBackup, deleteBackup, backupPath,
  pruneBackups, scheduleNightly, nextScheduled, getStats, checkTools, verifyBackupFile
};
