const { io } = require('socket.io-client');

const B = 'http://127.0.0.1:4000';
let pass = 0, fail = 0;
const log = [];
const check = (n, c) => { if (c) { pass++; log.push('  PASS: ' + n); } else { fail++; log.push('  FAIL: ' + n); } };

async function login() {
  const r = await fetch(B + '/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'Wolf3dAdmin#2026' })
  });
  return (await r.json()).token;
}

(async () => {
  const token = await login();

  // 1. Unauthenticated socket must be rejected.
  await new Promise((resolve) => {
    const s = io(B, { transports: ['websocket'], auth: {} });
    const timer = setTimeout(() => { check('socket without token rejected', false); s.close(); resolve(); }, 4000);
    s.on('connect', () => { clearTimeout(timer); check('socket without token rejected', false); s.close(); resolve(); });
    s.on('connect_error', () => { clearTimeout(timer); check('socket without token rejected', true); s.close(); resolve(); });
  });

  // 2. Authenticated socket connects and receives presence + broadcast event.
  await new Promise((resolve) => {
    const s = io(B, { transports: ['websocket'], auth: { token } });
    let gotPresence = false, gotEvent = false;
    const done = () => { if (gotPresence && gotEvent) { s.close(); resolve(); } };
    const timer = setTimeout(() => {
      check('authed socket connects', s.connected);
      check('received presence event', gotPresence);
      check('received broadcast (notice_created)', gotEvent);
      s.close(); resolve();
    }, 6000);

    s.on('connect', () => {
      // Trigger a broadcast by creating a notice over REST.
      fetch(B + '/api/notices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
        body: JSON.stringify({ title: 'RT Test', content: 'realtime check' })
      });
    });
    s.on('presence', (p) => { gotPresence = typeof p.onlineUsers === 'number'; });
    s.on('notice_created', (n) => {
      gotEvent = n && n.title === 'RT Test';
      if (gotPresence && gotEvent) {
        clearTimeout(timer);
        check('authed socket connects', true);
        check('received presence event', true);
        check('received broadcast (notice_created)', true);
        s.close(); resolve();
      }
    });
  });

  console.log(log.join('\n'));
  console.log(`\nSOCKET RESULT: ${pass} passed, ${fail} failed`);
  process.exit(fail > 0 ? 1 : 0);
})().catch((e) => { console.error('SOCKET TEST CRASH', e); process.exit(2); });
