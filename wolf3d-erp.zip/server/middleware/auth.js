const jwt = require('jsonwebtoken');
const { pool } = require('../db/pool');
const config = require('../config/env');
const { unauthorized, forbidden, asyncHandler } = require('./errorHandler');

function getToken(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return null;
  const [type, token] = authHeader.split(' ');
  if (type !== 'Bearer' || !token) return null;
  return token;
}

// Verify a JWT and resolve the current user record. Shared by HTTP + sockets.
async function resolveUserFromToken(token) {
  const payload = jwt.verify(token, config.JWT_SECRET);
  const result = await pool.query(
    `SELECT u.id, u.name, u.username, u.role, u.department_id, u.status,
            u.must_change_password, d.name AS department
     FROM users u LEFT JOIN departments d ON d.id = u.department_id
     WHERE u.id = $1`,
    [payload.userId]
  );
  if (result.rowCount === 0) return null;
  const user = result.rows[0];
  if (user.status !== 'active') return null;
  return user;
}

const authGuard = asyncHandler(async (req, res, next) => {
  const token = getToken(req);
  if (!token) throw unauthorized();
  let user;
  try {
    user = await resolveUserFromToken(token);
  } catch (err) {
    throw unauthorized('Invalid or expired session');
  }
  if (!user) throw unauthorized('Invalid or expired session');
  req.user = user;
  next();
});

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return next(forbidden('Manager access required'));
    }
    next();
  };
}

const managerOnly = requireRole('manager');

module.exports = { authGuard, managerOnly, requireRole, resolveUserFromToken };
