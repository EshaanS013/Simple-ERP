import { useState, useEffect, useCallback } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Factory, FolderKanban, PenTool, Cpu,
  Wallet, Megaphone, Network, Users, Activity, MessageSquare
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { socket } from '../services/socket';
import Api from '../services/api';

const NAV = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/production', label: 'Production', icon: Factory },
  { to: '/design', label: 'Design Updates', icon: PenTool, designOrManager: true },
  { to: '/messages', label: 'Messages', icon: MessageSquare, badge: 'unread' },
  { to: '/machines', label: 'Machine Utilization', icon: Cpu },
  { to: '/accounts', label: 'Accounts', icon: Wallet, accountsOnly: true },
  { to: '/departments', label: 'Departments', icon: Network },
  { to: '/notices', label: 'Notices', icon: Megaphone, badge: 'notice' },
  { to: '/activity', label: 'Activity', icon: Activity, managerOnly: true },
  { to: '/users', label: 'Team', icon: Users, managerOnly: true }
];

export default function Sidebar({ onNavigate }) {
  const { isManager, user, canAccessAccounts } = useAuth();
  const toast = useToast();
  const location = useLocation();
  const [unread, setUnread] = useState(0);
  const [noticeUnseen, setNoticeUnseen] = useState(0);
  const isDesign = (user?.departments || []).some((d) => String(d.name).toLowerCase() === 'design');

  const refreshUnread = useCallback(() => {
    Api.unreadCount().then((r) => setUnread(r.count || 0)).catch(() => {});
  }, []);

  const lastSeenNotice = () => Number(localStorage.getItem('wolf3d_lastSeenNotice') || 0);
  const refreshNotices = useCallback(() => {
    Api.notices().then((r) => {
      const list = r.data || r || [];
      const since = lastSeenNotice();
      setNoticeUnseen(list.filter((n) => new Date(n.created_at).getTime() > since).length);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    refreshUnread(); refreshNotices();
    const onDm = () => refreshUnread();
    const onNotice = (n) => {
      setNoticeUnseen((c) => c + 1);
      toast.info ? toast.info(`📢 New notice: ${n?.title || 'Posted'}`) : toast.success(`📢 New notice: ${n?.title || 'Posted'}`);
    };
    socket.on('dm', onDm); socket.on('dm_read', onDm); socket.on('notice_created', onNotice);
    return () => { socket.off('dm', onDm); socket.off('dm_read', onDm); socket.off('notice_created', onNotice); };
  }, [refreshUnread, refreshNotices, toast]);

  // Mark notices seen when viewing the Notices page.
  useEffect(() => {
    if (location.pathname === '/notices') {
      localStorage.setItem('wolf3d_lastSeenNotice', String(Date.now()));
      setNoticeUnseen(0);
    }
  }, [location.pathname]);

  const items = NAV.filter((n) => {
    if (n.managerOnly) return isManager;
    if (n.designOrManager) return isManager || isDesign;
    if (n.accountsOnly) return canAccessAccounts;
    return true;
  });

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-slate-200 bg-white">
      <div className="flex items-center gap-2.5 px-5 py-4">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand-600 text-sm font-bold text-white">W</div>
        <div className="leading-tight">
          <p className="text-sm font-semibold text-slate-900">WOLF3D</p>
          <p className="text-[11px] text-slate-400">ERP Platform</p>
        </div>
      </div>
      <nav className="flex-1 space-y-0.5 overflow-y-auto px-3 py-2">
        {items.map(({ to, label, icon: Icon, end, badge }) => (
          <NavLink key={to} to={to} end={end} onClick={onNavigate}
            className={({ isActive }) =>
              `flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition ${
                isActive ? 'bg-brand-50 text-brand-700' : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              }`}>
            <Icon className="h-[18px] w-[18px]" />
            <span className="flex-1">{label}</span>
            {badge === 'unread' && unread > 0 && (
              <span className="inline-flex h-5 min-w-[20px] items-center justify-center rounded-full bg-brand-600 px-1.5 text-[11px] font-semibold text-white">{unread}</span>
            )}
            {badge === 'notice' && noticeUnseen > 0 && (
              <span className="inline-flex h-5 min-w-[20px] items-center justify-center rounded-full bg-amber-500 px-1.5 text-[11px] font-semibold text-white">{noticeUnseen}</span>
            )}
          </NavLink>
        ))}
      </nav>
      <div className="border-t border-slate-100 px-5 py-3 text-[11px] text-slate-400">
        WOLF3D Technologies · v2.0
      </div>
    </aside>
  );
}
