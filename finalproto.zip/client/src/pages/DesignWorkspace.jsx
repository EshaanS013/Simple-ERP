import { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Users, MessageSquare, Clock, Trash2, PenTool } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PageHeader, LoadingState, ErrorState, ConfirmDialog, Field, Input, Textarea, Select } from '../components/ui';
import { DESIGN_STATUS, fmtDate } from '../lib/options';

const statusMeta = {
  not_started: { label: 'Not started', tint: 'bg-slate-100 text-slate-600' },
  in_progress: { label: 'In progress', tint: 'bg-blue-50 text-blue-700' },
  on_hold: { label: 'On hold', tint: 'bg-amber-50 text-amber-700' },
  completed: { label: 'Completed', tint: 'bg-emerald-50 text-emerald-700' }
};

export default function DesignWorkspace() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isManager } = useAuth();
  const toast = useToast();
  const [data, setData] = useState(null);
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [upd, setUpd] = useState({ entry_date: new Date().toISOString().slice(0, 10), progress_percent: '', work_done: '', comment: '', status: 'in_progress' });
  const [savingUpd, setSavingUpd] = useState(false);
  const [draft, setDraft] = useState('');
  const [replyTo, setReplyTo] = useState(null);
  const [replyText, setReplyText] = useState('');
  const [confirmDel, setConfirmDel] = useState(false);

  const load = useCallback(async () => {
    setError(null);
    try { const [b, c] = await Promise.all([Api.designAssignment(id), Api.designComments(id)]); setData(b); setComments(c.data || []); }
    catch (e) { setError(e.message); } finally { setLoading(false); }
  }, [id]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const onUpd = (p) => { if (!p || p.id === Number(id)) load(); };
    const onCom = (p) => { if (p?.assignment_id === Number(id)) Api.designComments(id).then((c) => setComments(c.data || [])).catch(() => {}); };
    const onMention = (m) => { if (m?.assignment_id !== Number(id)) toast.info(`💬 ${m.by} mentioned you in a design assignment`); };
    socket.on('design_updated', onUpd); socket.on('design_comment', onCom); socket.on('design_mention', onMention);
    return () => { socket.off('design_updated', onUpd); socket.off('design_comment', onCom); socket.off('design_mention', onMention); };
  }, [id, load, toast]);

  const submitUpdate = async () => {
    if (upd.progress_percent === '' || upd.progress_percent === null) { toast.error('Enter a progress %'); return; }
    setSavingUpd(true);
    try {
      await Api.addDesignUpdate(id, { entry_date: upd.entry_date, progress_percent: Number(upd.progress_percent), work_done: upd.work_done, comment: upd.comment, status: upd.status });
      setUpd((u) => ({ ...u, progress_percent: '', work_done: '', comment: '' }));
      toast.success('Update logged'); load();
    } catch (e) { toast.error(e.message); } finally { setSavingUpd(false); }
  };
  const sendComment = async () => {
    const b = draft.trim(); if (!b) return; setDraft('');
    try { await Api.postDesignComment(id, b); const c = await Api.designComments(id); setComments(c.data || []); } catch (e) { toast.error(e.message); }
  };
  const sendReply = async (parentId) => {
    const b = replyText.trim(); if (!b) return;
    try { await Api.postDesignComment(id, b, parentId); setReplyText(''); setReplyTo(null); const c = await Api.designComments(id); setComments(c.data || []); } catch (e) { toast.error(e.message); }
  };

  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} onRetry={load} />;
  const a = data.assignment;
  const sm = statusMeta[a.status] || statusMeta.not_started;

  return (
    <section>
      <button className="mb-3 inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-800" onClick={() => navigate('/design')}>
        <ArrowLeft className="h-4 w-4" /> Back to design updates
      </button>
      <PageHeader title={a.part_name} subtitle={`${a.work_order_number ? a.work_order_number + ' · ' : ''}${a.client_name || 'No client'}`}>
        <span className={`rounded-full px-3 py-1 text-sm font-medium ${sm.tint}`}>{sm.label}</span>
        {isManager && <button className="btn-secondary" onClick={() => setConfirmDel(true)}><Trash2 className="h-4 w-4" /></button>}
      </PageHeader>

      <div className="card mb-4 p-4">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-slate-700">Design progress</span>
          <span className="text-lg font-semibold text-brand-700">{a.progress_percent}%</span>
        </div>
        <div className="mt-2 h-3 w-full overflow-hidden rounded-full bg-slate-100">
          <div className="h-full rounded-full bg-gradient-to-r from-brand-400 to-brand-600" style={{ width: `${a.progress_percent}%` }} />
        </div>
        <p className="mt-1.5 text-xs text-slate-400">Updates automatically from the latest daily progress entry.</p>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <div className="card p-4">
            <h3 className="mb-3 text-sm font-semibold text-slate-900">Work order</h3>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm sm:grid-cols-3">
              {[['Client', a.client_name], ['Technology', a.technology], ['Part', a.part_name], ['Quantity', a.quantity], ['Work order', a.work_order_number], ['Start', a.start_date ? fmtDate(a.start_date) : null], ['Deadline', a.deadline ? fmtDate(a.deadline) : null]].map(([k, v]) => (
                <div key={k}><dt className="text-xs text-slate-400">{k}</dt><dd className="text-slate-800">{v || '—'}</dd></div>
              ))}
            </dl>
          </div>

          {/* Add daily update */}
          <div className="card p-4">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-900"><PenTool className="h-4 w-4" /> Log today's progress</h3>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Field label="Date"><Input type="date" value={upd.entry_date} onChange={(e) => setUpd((u) => ({ ...u, entry_date: e.target.value }))} /></Field>
              <Field label="Progress %"><Input type="number" min="0" max="100" value={upd.progress_percent} onChange={(e) => setUpd((u) => ({ ...u, progress_percent: e.target.value }))} /></Field>
            </div>
            <div className="mt-3"><Field label="Today's work"><Input value={upd.work_done} placeholder="e.g. Reverse engineering started" onChange={(e) => setUpd((u) => ({ ...u, work_done: e.target.value }))} /></Field></div>
            <div className="mt-3"><Field label="Comments"><Textarea rows={2} value={upd.comment} onChange={(e) => setUpd((u) => ({ ...u, comment: e.target.value }))} /></Field></div>
            <div className="mt-3 flex items-end gap-3">
              <div className="flex-1"><Field label="Status"><Select value={upd.status} onChange={(e) => setUpd((u) => ({ ...u, status: e.target.value }))}>{DESIGN_STATUS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}</Select></Field></div>
              <button className="btn-primary" onClick={submitUpdate} disabled={savingUpd}>{savingUpd ? 'Saving…' : 'Add update'}</button>
            </div>
          </div>

          {/* Daily updates history (accumulating) = activity timeline */}
          <div className="card p-4">
            <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-900"><Clock className="h-4 w-4" /> Daily updates &amp; timeline</h3>
            <ol className="relative space-y-3 border-l border-slate-200 pl-4">
              {(data.updates || []).length === 0 ? <li className="text-sm text-slate-400">No updates logged yet.</li> :
                data.updates.map((u) => (
                  <li key={u.id} className="relative">
                    <span className="absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full bg-brand-400 ring-2 ring-white" />
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-medium text-slate-800">{u.progress_percent}%</span>
                      {u.target_status && <span className={`rounded-full px-2 py-0.5 text-[10px] font-medium ${u.target_status === 'completed' ? 'bg-emerald-100 text-emerald-700' : u.target_status === 'partially_complete' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-600'}`}>{u.target_status.replace('_', ' ')}</span>}
                      {u.delivery_status === 'delivered' && <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-medium text-emerald-700">delivered</span>}
                    </div>
                    {u.target && <p className="text-xs text-slate-500"><span className="text-slate-400">Target:</span> {u.target}</p>}
                    {u.work_done && <p className="text-sm text-slate-700">{u.work_done}</p>}
                    {u.comment && <p className="text-xs text-slate-500">“{u.comment}”</p>}
                    <p className="text-xs text-slate-400">{u.designer_name || 'Designer'} · {u.entry_date ? fmtDate(u.entry_date) : new Date(u.created_at).toLocaleDateString()}</p>
                  </li>
                ))}
            </ol>
          </div>
        </div>

        <div className="space-y-4">
          <div className="card p-4">
            <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-900"><Users className="h-4 w-4" /> Assigned designers</h3>
            <ul className="space-y-1">
              {(data.designers || []).length === 0 ? <li className="text-xs text-slate-400">No designers assigned.</li> :
                data.designers.map((m) => <li key={m.id} className="flex items-center gap-2 text-sm text-slate-700"><span className="flex h-6 w-6 items-center justify-center rounded-full bg-brand-100 text-[10px] font-semibold text-brand-700">{m.name.split(' ').map((x) => x[0]).slice(0, 2).join('')}</span>{m.name}</li>)}
            </ul>
          </div>

          <div className="card flex max-h-[28rem] flex-col p-4">
            <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-900"><MessageSquare className="h-4 w-4" /> Discussion</h3>
            <div className="flex-1 space-y-3 overflow-y-auto">
              {comments.length === 0 ? <p className="py-4 text-center text-xs text-slate-400">No comments yet. Use @name to mention.</p> :
                comments.map((c) => (
                  <div key={c.id} className="rounded-lg bg-slate-50/70 px-3 py-2">
                    <p className="text-sm text-slate-800">{c.body}</p>
                    <p className="text-[11px] text-slate-400">{c.author_name} · {new Date(c.created_at).toLocaleString()}</p>
                    {c.replies?.length > 0 && (
                      <div className="mt-1.5 space-y-1 border-l-2 border-slate-200 pl-2.5">
                        {c.replies.map((r) => (<div key={r.id}><p className="text-sm text-slate-700">{r.body}</p><p className="text-[11px] text-slate-400">{r.author_name} · {new Date(r.created_at).toLocaleString()}</p></div>))}
                      </div>
                    )}
                    {replyTo === c.id ? (
                      <div className="mt-1.5 flex gap-1.5">
                        <input className="input h-8 flex-1 text-sm" autoFocus placeholder="Reply…" value={replyText} onChange={(e) => setReplyText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') sendReply(c.id); if (e.key === 'Escape') setReplyTo(null); }} />
                        <button className="btn-primary btn-sm" onClick={() => sendReply(c.id)}>Reply</button>
                      </div>
                    ) : <button className="mt-1 text-xs font-medium text-brand-600 hover:underline" onClick={() => { setReplyTo(c.id); setReplyText(''); }}>Reply{c.replies?.length ? ` (${c.replies.length})` : ''}</button>}
                  </div>
                ))}
            </div>
            <div className="mt-2 flex gap-2">
              <input className="input flex-1 text-sm" placeholder="Write a comment… @name to mention" value={draft} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') sendComment(); }} />
              <button className="btn-primary btn-sm" onClick={sendComment} disabled={!draft.trim()}>Send</button>
            </div>
          </div>
        </div>
      </div>

      <ConfirmDialog open={confirmDel} onClose={() => setConfirmDel(false)} onConfirm={async () => { try { await Api.deleteDesignAssignment(id); toast.success('Assignment deleted'); navigate('/design'); } catch (e) { toast.error(e.message); } }}
        title="Delete assignment?" message="This removes the assignment and all its daily updates and comments." />
    </section>
  );
}
