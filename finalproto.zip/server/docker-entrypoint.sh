#!/bin/sh
# Activates a staged update (if any) before starting the backend.
#
# The System Update module stages validated releases into the releases volume
# and records a pointer at $RELEASES_DIR/current.json. On container start we
# apply the staged BACKEND over the app directory so that a simple
# `docker compose restart server` activates the new backend version. Database
# migrations were already applied (with rollback) at install time.
#
# Frontend assets are staged at $RELEASES_DIR/<version>/frontend; activate them
# by pointing the web (nginx) service at the releases volume or running
# `docker compose up -d --build`. See the setup guide for details.
set -e

RELEASES_DIR="${RELEASES_DIR:-/app/releases}"
APP_DIR="$(pwd)"
POINTER="$RELEASES_DIR/current.json"

if [ -f "$POINTER" ]; then
  VERSION="$(node -e "try{process.stdout.write(require('$POINTER').version||'')}catch(e){}" 2>/dev/null || true)"
  RUNNING="$(node -e "try{process.stdout.write(require('$APP_DIR/package.json').version||'')}catch(e){}" 2>/dev/null || true)"
  STAGED_BACKEND="$RELEASES_DIR/$VERSION/backend"
  if [ -n "$VERSION" ] && [ "$VERSION" != "$RUNNING" ] && [ -d "$STAGED_BACKEND" ]; then
    echo "[entrypoint] Activating staged backend v$VERSION (was v$RUNNING)…"
    # Preserve node_modules; copy everything else from the staged backend.
    cp -a "$STAGED_BACKEND"/. "$APP_DIR"/ 2>/dev/null || true
    # Install any new production dependencies the release introduced.
    if [ -f "$APP_DIR/package.json" ]; then (cd "$APP_DIR" && npm install --omit=dev --no-audit --no-fund >/dev/null 2>&1 || true); fi
    echo "[entrypoint] Activation complete — now running v$VERSION"
  fi
fi

exec "$@"
