const express = require('express');
const { pool } = require('../db/pool');
const { authGuard, managerOnly, requireDepartment } = require('../middleware/auth');
const { attachScope } = require('../utils/scope');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound } = require('../middleware/errorHandler');
const { recordActivity } = require('../utils/activity');
const { emitEvent } = require('../socket/socket');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard, attachScope, requireDepartment('Accounts'));

const COLUMNS = ['invoice_date', 'client_name', 'contact_number', 'invoice_number', 'amount', 'gst_status', 'payment_terms', 'payment_status', 'action', 'comments'];

const SORTABLE = new Set(['invoice_date', 'client_name', 'invoice_number', 'amount', 'payment_status', 'payment_terms', 'gst_status', 'created_at']);

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query, 50);
  const { search, status, sort, dir } = req.query;
  const where = []; const params = []; let i = 1;
  if (status) { where.push(`payment_status = $${i++}`); params.push(status); }
  if (search) { where.push(`(client_name ILIKE $${i} OR invoice_number ILIKE $${i})`); params.push(`%${search}%`); i++; }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const orderCol = SORTABLE.has(sort) ? sort : 'invoice_date';
  const orderDir = String(dir).toLowerCase() === 'asc' ? 'ASC' : 'DESC';
  const total = await pool.query(`SELECT COUNT(*)::int c FROM payments ${whereSql}`, params);
  const rows = await pool.query(`SELECT * FROM payments ${whereSql} ORDER BY ${orderCol} ${orderDir} NULLS LAST, id DESC LIMIT $${i++} OFFSET $${i++}`, [...params, pageSize, offset]);
  res.json(paginatedResponse(rows.rows, total.rows[0].c, page, pageSize));
}));

router.post('/', validate({ body: schemas.createPayment }), asyncHandler(async (req, res) => {
  const b = req.body;
  const vals = COLUMNS.map((c) => b[c] ?? null);
  const ph = COLUMNS.map((_, idx) => `$${idx + 1}`).join(',');
  const { rows } = await pool.query(`INSERT INTO payments (${COLUMNS.join(',')}, created_by) VALUES (${ph}, $${COLUMNS.length + 1}) RETURNING *`, [...vals, req.user.id]);
  emitEvent('payment_created', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'added an invoice', module: 'Payments', details: `${rows[0].client_name} ${rows[0].invoice_number || ''}`.trim(), entityType: 'payment', entityId: rows[0].id });
  res.status(201).json(rows[0]);
}));

router.put('/:id', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const updates = []; const params = []; let i = 1;
  for (const c of COLUMNS) if (c in req.body) { updates.push(`${c} = $${i++}`); params.push(req.body[c] === '' ? null : req.body[c]); }
  if (updates.length === 0) { const cur = await pool.query('SELECT * FROM payments WHERE id=$1', [req.params.id]); if (!cur.rowCount) throw notFound('Invoice not found'); return res.json(cur.rows[0]); }
  params.push(req.params.id);
  const { rows, rowCount } = await pool.query(`UPDATE payments SET ${updates.join(', ')} WHERE id = $${i} RETURNING *`, params);
  if (rowCount === 0) throw notFound('Invoice not found');
  emitEvent('payment_updated', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'updated an invoice', module: 'Payments', details: `${rows[0].client_name} ${rows[0].invoice_number || ''}`.trim(), entityType: 'payment', entityId: rows[0].id });
  res.json(rows[0]);
}));

router.delete('/:id', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rowCount } = await pool.query('DELETE FROM payments WHERE id = $1', [req.params.id]);
  if (rowCount === 0) throw notFound('Invoice not found');
  emitEvent('payment_deleted', { id: Number(req.params.id) });
  res.json({ success: true });
}));

// Accounts analytics (managers/admins only): revenue, receivables, growth, top clients.
router.get('/analytics', managerOnly, asyncHandler(async (req, res) => {
  const monthly = await pool.query(`
    SELECT to_char(date_trunc('month', invoice_date), 'YYYY-MM') AS month,
           COALESCE(SUM(amount),0)::float AS invoiced,
           COALESCE(SUM(amount) FILTER (WHERE payment_status='received'),0)::float AS received
      FROM payments WHERE invoice_date >= (CURRENT_DATE - INTERVAL '11 months')
     GROUP BY 1 ORDER BY 1`);
  const yearly = await pool.query(`
    SELECT to_char(date_trunc('year', invoice_date), 'YYYY') AS year,
           COALESCE(SUM(amount),0)::float AS invoiced
      FROM payments GROUP BY 1 ORDER BY 1`);
  const totals = await pool.query(`
    SELECT
      COALESCE(SUM(amount),0)::float AS total_invoiced,
      COALESCE(SUM(amount) FILTER (WHERE payment_status='received'),0)::float AS received,
      COALESCE(SUM(amount) FILTER (WHERE payment_status IN ('pending','overdue','partial')),0)::float AS outstanding,
      COALESCE(AVG(amount),0)::float AS avg_invoice,
      COUNT(*)::int AS invoices
      FROM payments`);
  const topClients = await pool.query(`
    SELECT client_name,
           COALESCE(SUM(amount),0)::float AS revenue,
           COUNT(*)::int AS invoices
      FROM payments GROUP BY client_name ORDER BY revenue DESC LIMIT 8`);
  const t = totals.rows[0];
  const collectionRate = t.total_invoiced > 0 ? Math.round((t.received / t.total_invoiced) * 1000) / 10 : 0;
  // Month-over-month growth from the monthly series (invoiced).
  const m = monthly.rows;
  let mom = null;
  if (m.length >= 2) {
    const cur = m[m.length - 1].invoiced, prev = m[m.length - 2].invoiced;
    mom = prev > 0 ? Math.round(((cur - prev) / prev) * 1000) / 10 : null;
  }
  res.json({
    monthly: m, yearly: yearly.rows, topClients: topClients.rows,
    summary: { ...t, collection_rate: collectionRate, mom_growth: mom, pending: t.outstanding }
  });
}));

module.exports = router;
