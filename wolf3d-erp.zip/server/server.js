const path = require('path');
const fs = require('fs');
const http = require('http');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');

const config = require('./config/env');
const { runMigrations } = require('./db/migrate');
const { seed } = require('./db/seed');
const { healthcheck } = require('./db/pool');
const { initSocket } = require('./socket/socket');
const { apiLimiter } = require('./middleware/rateLimit');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');

const app = express();
app.set('trust proxy', 1);

// Allow the SPA bundle (served from same origin) to load; relax CSP for assets.
app.use(helmet({ contentSecurityPolicy: false, crossOriginResourcePolicy: false }));

const corsOptions = {
  origin: config.ALLOWED_ORIGINS,
  credentials: true
};
app.use(cors(corsOptions));
app.use(express.json({ limit: '1mb' }));
app.use(morgan(config.isProd ? 'combined' : 'dev'));

// Health/readiness endpoints (used by Docker healthchecks).
app.get('/api/health', async (req, res) => {
  try {
    await healthcheck();
    res.json({ status: 'ok', uptime: process.uptime() });
  } catch (err) {
    res.status(503).json({ status: 'degraded', error: 'database unavailable' });
  }
});

app.use('/api', apiLimiter);

app.use('/api/auth', require('./routes/auth'));
app.use('/api/users', require('./routes/users'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/work-orders', require('./routes/workOrders'));
app.use('/api/projects', require('./routes/projects'));
app.use('/api/tasks', require('./routes/tasks'));
app.use('/api/notices', require('./routes/notices'));
app.use('/api/quality', require('./routes/quality'));
app.use('/api/dispatch', require('./routes/dispatch'));
app.use('/api/comments', require('./routes/comments'));
app.use('/api/activities', require('./routes/activities'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/departments', require('./routes/departments'));
app.use('/api/clients', require('./routes/clients'));
app.use('/api/search', require('./routes/search'));
app.use('/api/updates', require('./routes/updates'));

// Unmatched API routes return JSON 404 (never the SPA HTML).
app.use(notFoundHandler);

// Serve the built SPA when present (single-container production deployment).
const clientDist = path.resolve(__dirname, '..', 'client', 'dist');
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get('*', (req, res) => res.sendFile(path.join(clientDist, 'index.html')));
}

app.use(errorHandler);

const server = http.createServer(app);

async function start() {
  await runMigrations();
  await seed();
  initSocket(server);
  server.listen(config.PORT, '0.0.0.0', () => {
    console.log(`WOLF3D ERP server running on http://0.0.0.0:${config.PORT} (${config.NODE_ENV})`);
  });
}

start().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

// Graceful shutdown
['SIGINT', 'SIGTERM'].forEach((sig) => {
  process.on(sig, () => {
    console.log(`\n${sig} received, shutting down...`);
    server.close(() => process.exit(0));
  });
});

module.exports = app;
