import { useState, useEffect, useCallback } from 'react';
import { X, History as HistoryIcon, ArrowRight } from 'lucide-react';
import Api from '../services/api';
import { useToast } from '../context/ToastContext';
import { Spinner } from './ui';

const LABELS = {
  work_order_number: 'Work Order', order_date: 'Date', client_name: 'Client', part_name: 'Part Name',
  technology: 'Technology', quantity: 'Qty', finish: 'Finish', paint: 'Paint', printing: 'Printing',
  clean_and_cure: 'Clean & Cure', sanding_and_polishing: 'Sanding & Polish', paint_status: 'Paint Status',
  xyz_dimension: 'XYZ Dimension', critical_dimension: 'Critical Dimension', surface_finish: 'Surface Finish',
  report_generated: 'Report Generated', rework_verdict: 'Rework Verdict', dispatch_status: 'Dispatch Status', dispatch_date: 'Dispatch Date'
};

// Read-only audit trail for a production record (managers/admins).
export default function HistoryDrawer({ record, onClose }) {
  const toast = useToast();
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const open = !!record;

  const load = useCallback(async () => {
    if (!record) return;
    setLoading(true);
    try { setRows((await Api.productionHistory(record.id)).data || []); }
    catch (e) { toast.error(e.message); } finally { setLoading(false); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [record?.id]);

  useEffect(() => { load(); }, [load]);

  const fmt = (d) => new Date(d).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  const val = (v) => (v === null || v === undefined || v === '' ? <span className="text-slate-300">empty</span> : v);

  return (
    <>
      <div className={`fixed inset-0 z-40 bg-slate-900/30 transition-opacity ${open ? 'opacity-100' : 'pointer-events-none opacity-0'}`} onClick={onClose} />
      <aside className={`fixed right-0 top-0 z-50 flex h-full w-full max-w-lg flex-col border-l border-slate-200 bg-white shadow-xl transition-transform duration-200 ${open ? 'translate-x-0' : 'translate-x-full'}`}>
        <header className="flex items-start justify-between gap-3 border-b border-slate-200 px-5 py-4">
          <div className="min-w-0">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-900"><HistoryIcon className="h-4 w-4 text-brand-600" /> Change History</h2>
            {record && <p className="mt-0.5 truncate text-xs text-slate-500">{`${record.work_order_number || ''} ${record.part_name || ''}`.trim()}</p>}
          </div>
          <button className="btn-ghost btn-sm" onClick={onClose}><X className="h-5 w-5" /></button>
        </header>
        <div className="flex-1 overflow-y-auto px-5 py-4">
          {loading ? <div className="flex justify-center py-10"><Spinner /></div>
            : rows.length === 0 ? <p className="py-10 text-center text-sm text-slate-400">No changes recorded yet.</p>
            : (
              <ul className="space-y-2">
                {rows.map((r, idx) => (
                  <li key={idx} className="rounded-lg border border-slate-100 bg-slate-50/60 px-3 py-2 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-slate-700">{LABELS[r.field] || r.field}</span>
                      <span className="text-[11px] text-slate-400">{fmt(r.changed_at)}</span>
                    </div>
                    <div className="mt-1 flex items-center gap-2 text-slate-600">
                      {val(r.old_value)} <ArrowRight className="h-3.5 w-3.5 text-slate-400" /> <span className="font-medium text-slate-900">{val(r.new_value)}</span>
                    </div>
                    <p className="mt-1 text-[11px] text-slate-400">by {r.changed_by_name || 'Unknown'}</p>
                  </li>
                ))}
              </ul>
            )}
        </div>
      </aside>
    </>
  );
}
