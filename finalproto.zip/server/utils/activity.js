const { pool } = require('../db/pool');
const { emitEvent } = require('../socket/socket');

// Records a business activity and broadcasts it as a single, consistently shaped
// `activity_created` event (the only source of activity-feed events).
// department_id lets the feed be scoped per workspace for employees.
async function recordActivity({ userId, userName, action, module, details, entityType, entityId, departmentId }) {
  const { rows } = await pool.query(
    `INSERT INTO activities (user_id, user_name, action, module, details, entity_type, entity_id, department_id)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
     RETURNING id, user_id, user_name, action, module, details, entity_type, entity_id, department_id, created_at`,
    [userId || null, userName || null, action, module, details || null, entityType || null, entityId || null, departmentId || null]
  );
  const activity = rows[0];
  try { emitEvent('activity_created', activity); } catch (err) { /* socket not ready during boot */ }
  return activity;
}

module.exports = { recordActivity };
