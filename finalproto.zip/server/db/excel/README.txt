DROP YOUR EXCEL FILES HERE
==========================

Put your three spreadsheets in this folder:
  • BDE-production.xlsx        (the production tracker)
  • acounts.xlsx              (payments / invoices)
  • machine_utilisation.xlsx  (machine usage)

The file names don't have to match exactly — the importer recognises each
sheet by its column headers, and ignores case, spaces and punctuation.

Then, from the "server" folder, run:

  npm run import              (adds the rows to the database)
  npm run import -- --reset   (clears old production/payment/usage rows first)

Notes
-----
• Production stage (Work Order / Production / Quality / Dispatch / Completed)
  is set automatically from which columns are filled in each row.
• Machine usage sheet should be a simple list with these columns:
      Machine | Date | Material | Volume | Weight
  (Volume in cc for resin printers, Weight in grams for FDM printers.)
  Any machine name not already set up is created automatically.
• Amounts like "1,85,000" and "₹92,000" are read correctly.
