import { useState, useEffect, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Search, FolderPlus, ExternalLink, Trash2, Download, Pencil } from 'lucide-react';
import Api from '../services/api';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { PageHeader, LoadingState, ErrorState, EmptyState, Modal, Field, Input, Select, Textarea } from '../components/ui';
import { fmtDate } from '../lib/options';
import { downloadCsv } from '../lib/csv';

const TARGET_STATUS = [
  { value: 'awaiting', label: 'Awaiting', tint: 'bg-slate-100 text-slate-600' },
  { value: 'partially_complete', label: 'Partially complete', tint: 'bg-amber-100 text-amber-800' },
  { value: 'completed', label: 'Completed', tint: 'bg-emerald-100 text-emerald-700' }
];
const DELIVERY_STATUS = [
  { value: 'awaiting', label: 'Awaiting', tint: 'bg-slate-100 text-slate-600' },
  { value: 'delivered', label: 'Delivered', tint: 'bg-emerald-100 text-emerald-700' }
];
const tintOf = (arr, v) => (arr.find((x) => x.value === v) || arr[0]).tint;

function StatCard({ label, value, accent = 'slate' }) {
  const c = { slate: 'text-slate-900', brand: 'text-brand-700', emerald: 'text-emerald-600', amber: 'text-amber-600', rose: 'text-rose-600' }[accent];
  return <div className="card px-4 py-3"><p className="text-xs text-slate-400">{label}</p><p className={`text-xl font-semibold ${c}`}>{value}</p></div>;
}

// Inline status dropdown rendered as a coloured pill.
function StatusSelect({ value, options, disabled, onChange }) {
  if (disabled) { const o = options.find((x) => x.value === value) || options[0]; return <span className={`inline-block rounded-full px-2.5 py-1 text-xs font-medium ${o.tint}`}>{o.label}</span>; }
  return (
    <select value={value} onChange={(e) => onChange(e.target.value)} className={`cursor-pointer rounded-full border-0 px-2.5 py-1 text-xs font-medium focus:ring-2 focus:ring-brand-300 ${tintOf(options, value)}`}>
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}

export default function DesignUpdates() {
  const { user, isManager } = useAuth();
  const navigate = useNavigate();
  const toast = useToast();
  const [rows, setRows] = useState([]);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [designers, setDesigners] = useState([]);
  const [projects, setProjects] = useState([]);

  // filters
  const [search, setSearch] = useState('');
  const [fDate, setFDate] = useState('');
  const [fDesigner, setFDesigner] = useState(isManager ? '' : 'me');
  const [fProject, setFProject] = useState('');
  const [fTarget, setFTarget] = useState('');
  const [fDelivery, setFDelivery] = useState('');

  // modals
  const [assigning, setAssigning] = useState(false);
  const [assignForm, setAssignForm] = useState({});
  const [newProject, setNewProject] = useState(false);
  const [projForm, setProjForm] = useState({ designer_ids: [] });
  const [busy, setBusy] = useState(false);

  // Manage Projects view
  const [view, setView] = useState('planner'); // 'planner' | 'projects'
  const [projSearch, setProjSearch] = useState('');
  const [projStatusFilter, setProjStatusFilter] = useState('');
  const [editProject, setEditProject] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [deleteProject, setDeleteProject] = useState(null);

  const loadRefs = useCallback(async () => {
    try { const [u, p] = await Promise.all([Api.designDesigners(), Api.designAssignments()]); setDesigners((u.data || u || [])); setProjects(p.data || []); } catch { /* ignore */ }
  }, []);
  const load = useCallback(async () => {
    setError(null);
    const params = {};
    if (fDate) params.date = fDate;
    if (fDesigner && fDesigner !== 'me') params.designer_id = fDesigner;
    if (fDesigner === 'me') params.designer_id = user?.id;
    if (fProject) params.assignment_id = fProject;
    if (fTarget) params.target_status = fTarget;
    if (fDelivery) params.delivery_status = fDelivery;
    if (search.trim()) params.search = search.trim();
    try { const [r, s] = await Promise.all([Api.designPlanner(params), Api.designStats().catch(() => null)]); setRows(r.data || []); setStats(s); }
    catch (e) { setError(e.message); } finally { setLoading(false); }
  }, [fDate, fDesigner, fProject, fTarget, fDelivery, search, user]);

  useEffect(() => { loadRefs(); }, [loadRefs]);
  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const r = () => { load(); loadRefs(); };
    ['planner_changed', 'design_updated', 'design_created', 'design_deleted'].forEach((e) => socket.on(e, r));
    return () => ['planner_changed', 'design_updated', 'design_created', 'design_deleted'].forEach((e) => socket.off(e, r));
  }, [load]);

  const canEditRow = (row) => isManager || row.designer_id === user?.id;
  const patchRow = async (row, patch) => {
    setRows((rs) => rs.map((x) => (x.id === row.id ? { ...x, ...patch } : x))); // optimistic
    try { await Api.updatePlannerRow(row.id, patch); Api.designStats().then(setStats).catch(() => {}); }
    catch (e) { toast.error(e.message); load(); }
  };

  const openAssign = () => { setAssignForm({ entry_date: new Date().toISOString().slice(0, 10), target_status: 'awaiting', delivery_status: 'awaiting' }); setAssigning(true); };
  const submitAssign = async () => {
    if (!assignForm.designer_id) { toast.error('Select a designer'); return; }
    if (!assignForm.assignment_id) { toast.error('Select a project'); return; }
    setBusy(true);
    try { await Api.assignPlannerRow({ entry_date: assignForm.entry_date, designer_id: Number(assignForm.designer_id), assignment_id: Number(assignForm.assignment_id), target: assignForm.target, target_status: assignForm.target_status, delivery_status: assignForm.delivery_status }); toast.success('Work assigned'); setAssigning(false); load(); }
    catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const submitProject = async () => {
    if (!projForm.part_name?.trim()) { toast.error('Part name is required'); return; }
    setBusy(true);
    try { const a = await Api.createDesignAssignment({ ...projForm, quantity: projForm.quantity || null }); toast.success('Project created'); setNewProject(false); setProjForm({ designer_ids: [] }); loadRefs(); setAssignForm((f) => ({ ...f, assignment_id: a.id })); }
    catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };
  const removeRow = async (row) => { try { await Api.deletePlannerRow(row.id); load(); } catch (e) { toast.error(e.message); } };

  // ---- Manage Projects handlers ----
  const openEditProject = (p) => { setEditForm({ part_name: p.part_name || '', work_order_number: p.work_order_number || '', client_name: p.client_name || '', technology: p.technology || '', quantity: p.quantity || '', deadline: p.deadline ? String(p.deadline).slice(0, 10) : '', status: p.status || '' }); setEditProject(p); };
  const submitEditProject = async () => {
    if (!editForm.part_name?.trim()) { toast.error('Part name is required'); return; }
    setBusy(true);
    try { await Api.updateDesignAssignment(editProject.id, { ...editForm, quantity: editForm.quantity || null }); toast.success('Project updated'); setEditProject(null); loadRefs(); }
    catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };
  const confirmDeleteProject = async () => {
    setBusy(true);
    try { await Api.deleteDesignAssignment(deleteProject.id); toast.success('Project deleted'); setDeleteProject(null); loadRefs(); load(); }
    catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };
  const visibleProjects = useMemo(() => {
    const q = projSearch.trim().toLowerCase();
    return (projects || []).filter((p) => {
      if (projStatusFilter && (p.status || 'in_progress') !== projStatusFilter) return false;
      if (!q) return true;
      return [p.part_name, p.work_order_number, p.client_name, p.technology, ...(p.designers || [])].some((v) => String(v || '').toLowerCase().includes(q));
    });
  }, [projects, projSearch, projStatusFilter]);

  const labelOf = (arr, v) => (arr.find((x) => x.value === v) || {}).label || v || '';
  const exportCsv = () => {
    if (!rows.length) { toast.error('Nothing to export'); return; }
    const headers = ['Date', 'Designer', 'Assigned Project', 'Work Order', 'Today\'s Target', 'Target Status', 'Delivery Status', 'Comments'];
    const data = rows.map((r) => [
      String(r.entry_date).slice(0, 10), r.designer_name || '', r.part_name || '', r.work_order_number || '',
      r.target || '', labelOf(TARGET_STATUS, r.target_status), labelOf(DELIVERY_STATUS, r.delivery_status), r.comment || ''
    ]);
    downloadCsv(`design-daily-updates-${new Date().toISOString().slice(0, 10)}`, headers, data);
  };

  const grouped = useMemo(() => {
    const m = new Map();
    for (const r of rows) { const k = String(r.entry_date).slice(0, 10); if (!m.has(k)) m.set(k, []); m.get(k).push(r); }
    return [...m.entries()];
  }, [rows]);

  return (
    <section>
      <PageHeader title="Design Daily Updates" subtitle="Daily planner — managers assign work, designers update progress every day.">
        <div className="flex gap-2">
          <button className="btn-secondary" onClick={exportCsv}><Download className="h-4 w-4" /> Export CSV</button>
          {isManager && <>
            <button className="btn-secondary" onClick={() => { setProjForm({ designer_ids: [] }); setNewProject(true); }}><FolderPlus className="h-4 w-4" /> New project</button>
            <button className="btn-primary" onClick={openAssign}><Plus className="h-4 w-4" /> Assign work</button>
          </>}
        </div>
      </PageHeader>

      {/* View toggle */}
      <div className="mb-4 inline-flex rounded-lg border border-slate-200 bg-white p-0.5 text-sm">
        <button className={`rounded-md px-3 py-1.5 font-medium transition ${view === 'planner' ? 'bg-brand-600 text-white' : 'text-slate-600 hover:bg-slate-50'}`} onClick={() => setView('planner')}>Daily Planner</button>
        <button className={`rounded-md px-3 py-1.5 font-medium transition ${view === 'projects' ? 'bg-brand-600 text-white' : 'text-slate-600 hover:bg-slate-50'}`} onClick={() => setView('projects')}>Manage Projects</button>
      </div>

      {view === 'planner' && <>
      {/* Dashboard */}
      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <StatCard label="Today's assignments" value={stats?.total ?? 0} accent="brand" />
        <StatCard label="Completed today" value={stats?.completed ?? 0} accent="emerald" />
        <StatCard label="Pending" value={stats?.pending ?? 0} accent="slate" />
        <StatCard label="Partially complete" value={stats?.partial ?? 0} accent="amber" />
        <StatCard label="Delayed" value={stats?.delayed ?? 0} accent="rose" />
        <StatCard label="Average progress" value={`${stats?.avg_progress ?? 0}%`} accent="brand" />
      </div>

      {/* Filters */}
      <div className="mb-3 flex flex-wrap gap-2">
        <div className="relative min-w-[200px] flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input className="input pl-9" placeholder="Search designer, project, target, comment…" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <Input type="date" value={fDate} onChange={(e) => setFDate(e.target.value)} className="w-40" />
        <Select value={fDesigner} onChange={(e) => setFDesigner(e.target.value)} className="w-40">
          {!isManager && <option value="me">My work</option>}
          <option value="">All designers</option>
          {designers.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
        </Select>
        <Select value={fProject} onChange={(e) => setFProject(e.target.value)} className="w-44">
          <option value="">All projects</option>
          {projects.map((p) => <option key={p.id} value={p.id}>{p.part_name}</option>)}
        </Select>
        <Select value={fTarget} onChange={(e) => setFTarget(e.target.value)} className="w-40">
          <option value="">Any target status</option>
          {TARGET_STATUS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </Select>
        <Select value={fDelivery} onChange={(e) => setFDelivery(e.target.value)} className="w-40">
          <option value="">Any delivery</option>
          {DELIVERY_STATUS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </Select>
      </div>

      {/* Planner table */}
      {loading ? <LoadingState /> : error ? <ErrorState message={error} onRetry={load} /> : rows.length === 0 ? (
        <div className="card"><EmptyState title="No assignments" message={isManager ? 'Assign work to a designer to start the daily planner.' : 'You have no assigned work for these filters.'} /></div>
      ) : (
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-slate-100 bg-slate-50/60 text-left text-xs uppercase text-slate-500">
              <tr>
                <th className="px-3 py-2.5">Date</th><th className="px-3 py-2.5">Designer</th><th className="px-3 py-2.5">Assigned project</th>
                <th className="px-3 py-2.5">Today's target</th><th className="px-3 py-2.5">Target status</th><th className="px-3 py-2.5">Delivery</th>
                <th className="px-3 py-2.5">Comments</th>{isManager && <th></th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {grouped.map(([date, drows]) => drows.map((row, idx) => (
                <tr key={row.id} className="align-top hover:bg-slate-50/50">
                  <td className="px-3 py-2.5 text-slate-500">{idx === 0 ? fmtDate(date) : ''}</td>
                  <td className="px-3 py-2.5 font-medium text-slate-800">{row.designer_name}</td>
                  <td className="px-3 py-2.5">
                    <button className="inline-flex items-center gap-1 font-medium text-brand-600 hover:underline" onClick={() => navigate(`/design/${row.assignment_id}`)}>
                      {row.part_name}<ExternalLink className="h-3 w-3" />
                    </button>
                    {row.work_order_number && <p className="text-[11px] text-slate-400">{row.work_order_number}{row.client_name ? ` · ${row.client_name}` : ''}</p>}
                  </td>
                  <td className="px-3 py-2.5 text-slate-700">
                    {isManager
                      ? <input className="w-full rounded border border-transparent bg-transparent px-1 py-0.5 hover:border-slate-200 focus:border-brand-300 focus:bg-white focus:outline-none" defaultValue={row.target || ''} placeholder="—" onBlur={(e) => { if ((e.target.value || '') !== (row.target || '')) patchRow(row, { target: e.target.value }); }} />
                      : <span>{row.target || '—'}</span>}
                  </td>
                  <td className="px-3 py-2.5"><StatusSelect value={row.target_status} options={TARGET_STATUS} disabled={!canEditRow(row)} onChange={(v) => patchRow(row, { target_status: v })} /></td>
                  <td className="px-3 py-2.5"><StatusSelect value={row.delivery_status} options={DELIVERY_STATUS} disabled={!canEditRow(row)} onChange={(v) => patchRow(row, { delivery_status: v })} /></td>
                  <td className="px-3 py-2.5 min-w-[180px]">
                    {canEditRow(row)
                      ? <input className="w-full rounded border border-transparent bg-transparent px-1 py-0.5 hover:border-slate-200 focus:border-brand-300 focus:bg-white focus:outline-none" defaultValue={row.comment || ''} placeholder="Add comment…" onBlur={(e) => { if ((e.target.value || '') !== (row.comment || '')) patchRow(row, { comment: e.target.value }); }} />
                      : <span className="text-slate-600">{row.comment || '—'}</span>}
                  </td>
                  {isManager && <td className="px-2 py-2.5"><button className="text-slate-300 hover:text-red-500" title="Remove row" onClick={() => removeRow(row)}><Trash2 className="h-4 w-4" /></button></td>}
                </tr>
              )))}
            </tbody>
          </table>
        </div>
      )}
      </>}

      {/* ---- Manage Projects view ---- */}
      {view === 'projects' && <>
        <div className="mb-3 flex flex-wrap gap-2">
          <div className="relative min-w-[220px] flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input className="input pl-9" placeholder="Search projects by part, work order, client, designer…" value={projSearch} onChange={(e) => setProjSearch(e.target.value)} />
          </div>
          <Select value={projStatusFilter} onChange={(e) => setProjStatusFilter(e.target.value)} className="w-44">
            <option value="">Any status</option>
            <option value="in_progress">In progress</option>
            <option value="completed">Completed</option>
            <option value="on_hold">On hold</option>
          </Select>
        </div>

        {loading ? <LoadingState /> : visibleProjects.length === 0 ? (
          <div className="card"><EmptyState title="No projects" message={isManager ? 'Create a project to get started.' : 'You have no projects assigned to you yet.'} /></div>
        ) : (
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2 xl:grid-cols-3">
            {visibleProjects.map((p) => {
              const designers = Array.isArray(p.designers) ? p.designers : [];
              const pct = p.progress_percent ?? 0;
              const overdue = p.deadline && new Date(p.deadline) < new Date() && (p.status !== 'completed');
              return (
                <div key={p.id} className="card flex flex-col p-4 transition hover:shadow-md">
                  <div className="flex items-start justify-between gap-2">
                    <button className="text-left" onClick={() => navigate(`/design/${p.id}`)}>
                      <h4 className="font-semibold text-slate-800 hover:text-brand-600">{p.part_name}</h4>
                      <p className="text-[11px] text-slate-400">{[p.work_order_number, p.client_name].filter(Boolean).join(' · ') || 'No work order'}</p>
                    </button>
                    {isManager && (
                      <div className="flex shrink-0 gap-1">
                        <button className="rounded p-1 text-slate-400 hover:bg-slate-100 hover:text-brand-600" title="Edit" onClick={() => openEditProject(p)}><Pencil className="h-3.5 w-3.5" /></button>
                        <button className="rounded p-1 text-slate-400 hover:bg-red-50 hover:text-red-500" title="Delete" onClick={() => setDeleteProject(p)}><Trash2 className="h-3.5 w-3.5" /></button>
                      </div>
                    )}
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1.5 text-[11px]">
                    {p.technology && <span className="rounded bg-slate-100 px-1.5 py-0.5 text-slate-600">{p.technology}</span>}
                    {p.quantity != null && <span className="rounded bg-slate-100 px-1.5 py-0.5 text-slate-600">Qty {p.quantity}</span>}
                    {p.deadline && <span className={`rounded px-1.5 py-0.5 ${overdue ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-600'}`}>Due {fmtDate(p.deadline)}</span>}
                    <span className={`rounded px-1.5 py-0.5 ${p.status === 'completed' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-800'}`}>{(p.status || 'in_progress').replace('_', ' ')}</span>
                  </div>
                  <div className="mt-3">
                    <div className="mb-1 flex justify-between text-[11px] text-slate-400"><span>Progress</span><span className="font-medium text-slate-600">{pct}%</span></div>
                    <div className="h-1.5 w-full rounded-full bg-slate-100"><div className="h-1.5 rounded-full bg-brand-500" style={{ width: `${pct}%` }} /></div>
                  </div>
                  <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="truncate">{designers.length ? `Designers: ${designers.join(', ')}` : 'No designers assigned'}</span>
                  </div>
                  <div className="mt-1 flex items-center justify-between text-[11px] text-slate-400">
                    <span>{p.update_count || 0} update{(p.update_count || 0) === 1 ? '' : 's'}</span>
                    <button className="font-medium text-brand-600 hover:underline" onClick={() => navigate(`/design/${p.id}`)}>Open workspace →</button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </>}

      {/* Edit project modal */}
      <Modal open={!!editProject} onClose={() => setEditProject(null)} title="Edit project" size="lg"
        footer={<><button className="btn-secondary" onClick={() => setEditProject(null)} disabled={busy}>Cancel</button><button className="btn-primary" onClick={submitEditProject} disabled={busy}>{busy ? 'Saving…' : 'Save changes'}</button></>}>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Part name" required><Input value={editForm.part_name || ''} onChange={(e) => setEditForm((f) => ({ ...f, part_name: e.target.value }))} /></Field>
          <Field label="Work order #"><Input value={editForm.work_order_number || ''} onChange={(e) => setEditForm((f) => ({ ...f, work_order_number: e.target.value }))} /></Field>
          <Field label="Client"><Input value={editForm.client_name || ''} onChange={(e) => setEditForm((f) => ({ ...f, client_name: e.target.value }))} /></Field>
          <Field label="Technology"><Input value={editForm.technology || ''} onChange={(e) => setEditForm((f) => ({ ...f, technology: e.target.value }))} /></Field>
          <Field label="Quantity"><Input type="number" value={editForm.quantity || ''} onChange={(e) => setEditForm((f) => ({ ...f, quantity: e.target.value }))} /></Field>
          <Field label="Deadline"><Input type="date" value={editForm.deadline || ''} onChange={(e) => setEditForm((f) => ({ ...f, deadline: e.target.value }))} /></Field>
          <Field label="Status"><Select value={editForm.status || ''} onChange={(e) => setEditForm((f) => ({ ...f, status: e.target.value }))}><option value="">—</option><option value="in_progress">In progress</option><option value="completed">Completed</option><option value="on_hold">On hold</option></Select></Field>
        </div>
      </Modal>

      {/* Delete project confirmation */}
      <Modal open={!!deleteProject} onClose={() => setDeleteProject(null)} title="Delete project"
        footer={<><button className="btn-secondary" onClick={() => setDeleteProject(null)} disabled={busy}>Cancel</button><button className="btn-danger" onClick={confirmDeleteProject} disabled={busy}>{busy ? 'Deleting…' : 'Delete project'}</button></>}>
        <p className="text-sm text-slate-600">Delete <span className="font-medium">{deleteProject?.part_name}</span> and all of its daily updates and history? This cannot be undone.</p>
      </Modal>
      <Modal open={assigning} onClose={() => setAssigning(false)} title="Assign work"
        footer={<><button className="btn-secondary" onClick={() => setAssigning(false)} disabled={busy}>Cancel</button><button className="btn-primary" onClick={submitAssign} disabled={busy}>{busy ? 'Assigning…' : 'Assign'}</button></>}>
        <div className="space-y-3">
          <Field label="Date" required><Input type="date" value={assignForm.entry_date || ''} onChange={(e) => setAssignForm((f) => ({ ...f, entry_date: e.target.value }))} /></Field>
          <Field label="Designer" required><Select value={assignForm.designer_id || ''} onChange={(e) => setAssignForm((f) => ({ ...f, designer_id: e.target.value }))}><option value="">Select designer…</option>{designers.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</Select></Field>
          <Field label="Project" required>
            <div className="flex gap-2">
              <Select value={assignForm.assignment_id || ''} onChange={(e) => setAssignForm((f) => ({ ...f, assignment_id: e.target.value }))} className="flex-1"><option value="">Select project…</option>{projects.map((p) => <option key={p.id} value={p.id}>{p.part_name}{p.work_order_number ? ` (${p.work_order_number})` : ''}</option>)}</Select>
              <button type="button" className="btn-secondary btn-sm" onClick={() => { setProjForm({ designer_ids: [] }); setNewProject(true); }}><FolderPlus className="h-4 w-4" /></button>
            </div>
          </Field>
          <Field label="Today's target"><Input value={assignForm.target || ''} placeholder="e.g. Finalize battery casing" onChange={(e) => setAssignForm((f) => ({ ...f, target: e.target.value }))} /></Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Initial status"><Select value={assignForm.target_status || 'awaiting'} onChange={(e) => setAssignForm((f) => ({ ...f, target_status: e.target.value }))}>{TARGET_STATUS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}</Select></Field>
            <Field label="Delivery status"><Select value={assignForm.delivery_status || 'awaiting'} onChange={(e) => setAssignForm((f) => ({ ...f, delivery_status: e.target.value }))}>{DELIVERY_STATUS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}</Select></Field>
          </div>
        </div>
      </Modal>

      {/* New project modal */}
      <Modal open={newProject} onClose={() => setNewProject(false)} title="New project (work order)" size="lg"
        footer={<><button className="btn-secondary" onClick={() => setNewProject(false)} disabled={busy}>Cancel</button><button className="btn-primary" onClick={submitProject} disabled={busy}>{busy ? 'Creating…' : 'Create project'}</button></>}>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <Field label="Part name" required><Input value={projForm.part_name || ''} onChange={(e) => setProjForm((f) => ({ ...f, part_name: e.target.value }))} /></Field>
          <Field label="Work order #"><Input value={projForm.work_order_number || ''} onChange={(e) => setProjForm((f) => ({ ...f, work_order_number: e.target.value }))} /></Field>
          <Field label="Client"><Input value={projForm.client_name || ''} onChange={(e) => setProjForm((f) => ({ ...f, client_name: e.target.value }))} /></Field>
          <Field label="Technology"><Input value={projForm.technology || ''} placeholder="SLA / DLP / FDM" onChange={(e) => setProjForm((f) => ({ ...f, technology: e.target.value }))} /></Field>
          <Field label="Quantity"><Input type="number" value={projForm.quantity || ''} onChange={(e) => setProjForm((f) => ({ ...f, quantity: e.target.value }))} /></Field>
          <Field label="Deadline"><Input type="date" value={projForm.deadline || ''} onChange={(e) => setProjForm((f) => ({ ...f, deadline: e.target.value }))} /></Field>
        </div>
      </Modal>
    </section>
  );
}
