// Parse pagination params with sane bounds.
function getPagination(query, defaultPageSize = 25, maxPageSize = 200) {
  let page = parseInt(query.page, 10);
  let pageSize = parseInt(query.pageSize, 10);
  if (!Number.isFinite(page) || page < 1) page = 1;
  if (!Number.isFinite(pageSize) || pageSize < 1) pageSize = defaultPageSize;
  if (pageSize > maxPageSize) pageSize = maxPageSize;
  const offset = (page - 1) * pageSize;
  return { page, pageSize, offset };
}

function paginatedResponse(rows, total, page, pageSize) {
  return {
    data: rows,
    pagination: {
      page,
      pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / pageSize))
    }
  };
}

module.exports = { getPagination, paginatedResponse };
