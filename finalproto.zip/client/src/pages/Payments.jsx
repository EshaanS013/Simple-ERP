import { useState, useEffect, useCallback } from 'react';
import { TrendingUp, TrendingDown, Wallet } from 'lucide-react';
import { PageHeader } from '../components/ui';
import InlineTable from '../components/InlineTable';
import { StatTile, GroupedBars, HBarList } from '../components/Charts';
import { socket } from '../services/socket';
import { useAuth } from '../context/AuthContext';
import Api from '../services/api';
import { PAYMENT_STATUS, fmtMoney } from '../lib/options';

const TERMS = ['8 days', '15 days', '30 days', '45 days', 'Advance', 'On delivery'];
const GST = ['DONE', 'Pending', 'N/A'];
const ACTIONS = ['Call', 'Email', 'Follow up', 'Escalate', 'Closed'];
const monthLabel = (ym) => { const [y, m] = ym.split('-'); return new Date(y, m - 1).toLocaleString('en-US', { month: 'short' }); };

const columns = [
  { key: 'invoice_date', label: 'Date', type: 'date', width: '130px' },
  { key: 'client_name', label: 'Client', width: '160px' },
  { key: 'contact_number', label: 'Contact', width: '130px' },
  { key: 'invoice_number', label: 'Invoice No.', width: '130px' },
  { key: 'amount', label: 'Amount', type: 'number', width: '110px', format: (v) => fmtMoney(v) },
  { key: 'gst_status', label: 'GST', suggestions: GST, width: '90px' },
  { key: 'payment_terms', label: 'Terms', suggestions: TERMS, width: '110px' },
  { key: 'payment_status', label: 'Status', type: 'select', options: PAYMENT_STATUS, width: '120px' },
  { key: 'action', label: 'Action', suggestions: ACTIONS, width: '110px' },
  { key: 'comments', label: 'Comments', width: '180px' }
];

function Analytics() {
  const [a, setA] = useState(null);
  const load = useCallback(() => { Api.accountsAnalytics().then(setA).catch(() => {}); }, []);
  useEffect(() => { load(); }, [load]);
  useEffect(() => {
    const r = () => load();
    ['payment_created', 'payment_updated', 'payment_deleted'].forEach((e) => socket.on(e, r));
    return () => ['payment_created', 'payment_updated', 'payment_deleted'].forEach((e) => socket.off(e, r));
  }, [load]);

  if (!a || !a.summary || a.summary.invoices === 0) return null;
  const s = a.summary;
  const monthly = (a.monthly || []).map((d) => ({ label: monthLabel(d.month), a: d.invoiced, b: d.received }));
  const mom = s.mom_growth;

  return (
    <div className="mb-6 space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatTile label="Total invoiced" value={fmtMoney(s.total_invoiced)} sub={`${s.invoices} invoices`} />
        <StatTile label="Received" value={fmtMoney(s.received)} accent="emerald" sub={`Collection ${s.collection_rate}%`} />
        <StatTile label="Outstanding" value={fmtMoney(s.outstanding)} accent="amber" />
        <StatTile label="Avg invoice" value={fmtMoney(Math.round(s.avg_invoice))}
          sub={mom == null ? null : <span className={mom >= 0 ? 'text-emerald-600' : 'text-red-600'}>{mom >= 0 ? '▲' : '▼'} {Math.abs(mom)}% MoM</span>} />
      </div>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <div className="card p-4">
          <h3 className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-700"><Wallet className="h-4 w-4 text-brand-600" /> Monthly revenue</h3>
          <GroupedBars data={monthly} aLabel="Invoiced" bLabel="Received" valueFmt={(v) => fmtMoney(v)} />
        </div>
        <div className="card p-4">
          <h3 className="mb-3 text-sm font-semibold text-slate-700">Top clients by revenue</h3>
          <HBarList items={(a.topClients || []).map((c) => ({ label: c.client_name, value: c.revenue, sub: `${c.invoices} inv` }))} valueFmt={(v) => fmtMoney(v)} />
        </div>
      </div>
    </div>
  );
}

export default function Payments() {
  const { isManager } = useAuth();
  return (
    <section>
      <PageHeader title="Accounts" subtitle="Invoice and payment follow-up. Click any cell to edit." />
      {isManager && <Analytics />}
      <InlineTable
        resource="payments"
        columns={columns}
        events={['payment_created', 'payment_updated', 'payment_deleted']}
        filters={{ key: 'status', label: 'statuses', options: PAYMENT_STATUS }}
        searchPlaceholder="Search client or invoice number…"
        requiredKey="client_name"
        newRowDefaults={{ payment_status: 'pending' }}
      />
    </section>
  );
}
