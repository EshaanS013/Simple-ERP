import { useEffect } from 'react';
import { Activity as ActivityIcon } from 'lucide-react';
import { useList } from '../hooks/useList';
import { socket } from '../services/socket';
import { PageHeader, SearchBar, Pagination, LoadingState, ErrorState, EmptyState } from '../components/ui';

const timeAgo = (d) => {
  const sec = Math.floor((Date.now() - new Date(d)) / 1000);
  if (sec < 60) return 'just now';
  if (sec < 3600) return `${Math.floor(sec / 60)}m ago`;
  if (sec < 86400) return `${Math.floor(sec / 3600)}h ago`;
  return new Date(d).toLocaleString();
};

export default function Activity() {
  const list = useList('activities', { pageSize: 30 });

  // Refresh first page when a new activity arrives.
  useEffect(() => {
    const onActivity = () => { if (list.page === 1) list.refetch(); };
    socket.on('activity_created', onActivity);
    return () => socket.off('activity_created', onActivity);
  }, [list.page, list.refetch]);

  return (
    <section>
      <PageHeader title="Activity" subtitle="A complete audit trail of actions across the system." />
      <div className="card overflow-hidden">
        <div className="border-b border-slate-100 p-3">
          <SearchBar value={list.search} onChange={list.onSearch} placeholder="Search activity…" />
        </div>
        {list.loading ? <LoadingState /> : list.error ? <ErrorState message={list.error} onRetry={list.refetch} /> : list.data.length === 0 ? (
          <EmptyState title="No activity" message={list.search ? 'No matches for your search.' : 'Activity will appear here as people work.'} />
        ) : (
          <>
            <ul className="divide-y divide-slate-50">
              {list.data.map((a) => (
                <li key={a.id} className="flex items-start gap-3 px-5 py-3">
                  <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-brand-50 text-brand-600"><ActivityIcon className="h-3.5 w-3.5" /></div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm text-slate-700">
                      <span className="font-medium text-slate-900">{a.user_name || 'Someone'}</span> {a.action}
                      {a.details ? <span className="text-slate-500"> — {a.details}</span> : null}
                    </p>
                    <p className="text-xs text-slate-400">{a.module}{a.entity_type ? ` · ${a.entity_type}` : ''} · {timeAgo(a.created_at)}</p>
                  </div>
                </li>
              ))}
            </ul>
            <Pagination pagination={list.pagination} onPage={list.setPage} />
          </>
        )}
      </div>
    </section>
  );
}
