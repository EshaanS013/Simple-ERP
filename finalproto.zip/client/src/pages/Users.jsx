import { useState, useEffect } from 'react';
import { Plus, Pencil, KeyRound, Trash2, Lock } from 'lucide-react';
import { useList } from '../hooks/useList';
import { useLookups } from '../hooks/useLookups';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { socket } from '../services/socket';
import Api from '../services/api';
import {
  PageHeader, SearchBar, Select, Pagination, Modal, ConfirmDialog,
  LoadingState, EmptyState, ErrorState, StatusBadge, Field, Input
} from '../components/ui';
import { ROLE } from '../lib/options';

const ROLE_LABEL = { admin: 'Admin', manager: 'Manager', employee: 'Employee' };
const roleBadge = (role) => (
  <span className={`badge ${role === 'admin' ? 'bg-amber-50 text-amber-700' : role === 'manager' ? 'bg-brand-50 text-brand-700' : 'bg-slate-100 text-slate-600'}`}>
    {ROLE_LABEL[role] || role}
  </span>
);

// Live presence indicator. Disabled accounts read "Disabled"; otherwise Online/Offline.
const presence = (u, onlineIds) => {
  if (u.status === 'inactive') return <span className="inline-flex items-center gap-1.5 text-sm text-slate-400"><span className="h-2 w-2 rounded-full bg-slate-300" /> Disabled</span>;
  const on = onlineIds.has(u.id) || u.online;
  return on
    ? <span className="inline-flex items-center gap-1.5 text-sm font-medium text-emerald-600"><span className="h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_0_3px_rgba(16,185,129,0.15)]" /> Online</span>
    : <span className="inline-flex items-center gap-1.5 text-sm text-slate-400"><span className="h-2 w-2 rounded-full bg-slate-300" /> Offline</span>;
};

export default function Users() {
  const { user, isAdmin } = useAuth();
  const toast = useToast();
  const list = useList('users', { pageSize: 25, refreshEvents: ['user_created', 'user_updated', 'user_deleted'] });
  const lookups = useLookups(['departments']);
  const [onlineIds, setOnlineIds] = useState(() => new Set());

  useEffect(() => {
    const onPresence = (p) => setOnlineIds(new Set(p.onlineUserIds || []));
    socket.on('presence', onPresence);
    return () => socket.off('presence', onPresence);
  }, []);

  const [editing, setEditing] = useState(null);
  const [resetting, setResetting] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({});
  const [resetPw, setResetPw] = useState('');

  const openCreate = () => { setForm({ name: '', password: '', role: 'employee', department_ids: [] }); setEditing({}); };
  const openEdit = (u) => { setForm({ name: u.name, role: u.role, status: u.status, department_ids: (u.departments || []).map((d) => d.id) }); setEditing(u); };
  const toggleDept = (id) => setForm((f) => { const ids = f.department_ids || []; return { ...f, department_ids: ids.includes(id) ? ids.filter((x) => x !== id) : [...ids, id] }; });
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = async () => {
    setBusy(true);
    try {
      const department_ids = form.department_ids || [];
      if (editing.id) {
        await Api.update('users', editing.id, { name: form.name.trim(), role: form.role, status: form.status, department_ids });
        toast.success('User updated');
      } else {
        if (!form.name.trim() || !form.password) { toast.error('Full name and password are required'); setBusy(false); return; }
        await Api.create('users', { name: form.name.trim(), password: form.password, role: form.role, department_ids });
        toast.success('User created');
      }
      setEditing(null);
      list.refetch();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const doReset = async () => {
    if (resetPw.length < 8 || !/[A-Za-z]/.test(resetPw) || !/[0-9]/.test(resetPw)) {
      toast.error('Password must be 8+ chars with a letter and a number'); return;
    }
    setBusy(true);
    try {
      await Api.raw.post(`/api/users/${resetting.id}/reset-password`, { newPassword: resetPw });
      toast.success(`Password reset for ${resetting.name}`);
      setResetting(null); setResetPw('');
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  const doDelete = async () => {
    setBusy(true);
    try {
      await Api.remove('users', deleting.id);
      toast.success('User removed');
      setDeleting(null);
      list.refetch();
    } catch (e) { toast.error(e.message); } finally { setBusy(false); }
  };

  return (
    <section>
      <PageHeader title="Team" subtitle={isAdmin ? 'Manage user accounts, roles and access.' : 'View team members and their roles.'}>
        {isAdmin && <button className="btn-primary" onClick={openCreate}><Plus className="h-4 w-4" /> New User</button>}
      </PageHeader>

      {!isAdmin && (
        <div className="mb-3 flex items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-500">
          <Lock className="h-4 w-4" /> Read-only — only an admin can create or change user accounts.
        </div>
      )}

      <div className="card overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-slate-100 p-3 sm:flex-row sm:items-center">
          <div className="flex-1"><SearchBar value={list.search} onChange={list.onSearch} placeholder="Search team members…" /></div>
          <Select value={list.filters.role || ''} onChange={(e) => list.updateFilter('role', e.target.value)} className="sm:w-44">
            <option value="">All roles</option>
            {ROLE.map((r) => <option key={r.value} value={r.value}>{ROLE_LABEL[r.value]}</option>)}
          </Select>
        </div>

        {list.loading ? <LoadingState /> : list.error ? <ErrorState message={list.error} onRetry={list.refetch} /> : list.data.length === 0 ? (
          <EmptyState title="No users found" message={list.search ? 'Try a different search.' : 'Create your first team member.'} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-slate-100 bg-slate-50/60">
                <tr>
                  <th className="th">Name</th><th className="th">Role</th>
                  <th className="th">Workspaces</th><th className="th">Presence</th>
                  {isAdmin && <th className="th text-right">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {list.data.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/60">
                    <td className="td font-medium text-slate-900">{u.name}{u.id === user.id && <span className="ml-2 text-xs text-slate-400">(you)</span>}</td>
                    <td className="td">{roleBadge(u.role)}</td>
                    <td className="td text-slate-500">{(u.departments && u.departments.length) ? u.departments.map((d) => d.name).join(', ') : '—'}</td>
                    <td className="td">{presence(u, onlineIds)}</td>
                    {isAdmin && (
                      <td className="td">
                        <div className="flex items-center justify-end gap-1">
                          <button className="btn-ghost btn-sm" title="Edit" onClick={() => openEdit(u)}><Pencil className="h-4 w-4" /></button>
                          <button className="btn-ghost btn-sm" title="Reset password" onClick={() => { setResetPw(''); setResetting(u); }}><KeyRound className="h-4 w-4" /></button>
                          {u.id !== user.id && (
                            <button className="btn-ghost btn-sm text-red-500 hover:bg-red-50" title="Remove" onClick={() => setDeleting(u)}><Trash2 className="h-4 w-4" /></button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
            <Pagination pagination={list.pagination} onPage={list.setPage} />
          </div>
        )}
      </div>

      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.id ? 'Edit User' : 'New User'} size="md"
        footer={<>
          <button className="btn-secondary" onClick={() => setEditing(null)} disabled={busy}>Cancel</button>
          <button className="btn-primary" onClick={save} disabled={busy}>{busy ? 'Saving…' : editing?.id ? 'Save changes' : 'Create user'}</button>
        </>}>
        {editing && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Full Name" required hint="This is also the login name."><Input value={form.name || ''} onChange={(e) => set('name', e.target.value)} placeholder="e.g. Ramesh Kumar" /></Field>
            {!editing.id && <Field label="Temporary Password" required><Input type="text" value={form.password || ''} onChange={(e) => set('password', e.target.value)} placeholder="Min 8 chars, letter + number" /></Field>}
            <Field label="Role"><Select value={form.role || 'employee'} onChange={(e) => set('role', e.target.value)}>{ROLE.map((r) => <option key={r.value} value={r.value}>{ROLE_LABEL[r.value]}</option>)}</Select></Field>
            <div className="sm:col-span-2">
              <label className="mb-1 block text-sm font-medium text-slate-700">Workspaces</label>
              <div className="flex flex-wrap gap-2">
                {lookups.departments.length === 0 && <span className="text-sm text-slate-400">No workspaces yet.</span>}
                {lookups.departments.map((d) => {
                  const on = (form.department_ids || []).includes(d.id);
                  return (
                    <button type="button" key={d.id} onClick={() => toggleDept(d.id)}
                      className={`rounded-full border px-3 py-1 text-sm transition ${on ? 'border-brand-300 bg-brand-50 text-brand-700' : 'border-slate-200 text-slate-600 hover:bg-slate-50'}`}>
                      {d.name}
                    </button>
                  );
                })}
              </div>
              <p className="mt-1 text-xs text-slate-400">Employees only see the workspaces you assign here.</p>
            </div>
            {editing.id && <Field label="Status"><Select value={form.status || 'active'} onChange={(e) => set('status', e.target.value)}><option value="active">Active</option><option value="inactive">Inactive</option></Select></Field>}
          </div>
        )}
      </Modal>

      <Modal open={!!resetting} onClose={() => setResetting(null)} title={`Reset password — ${resetting?.name || ''}`} size="sm"
        footer={<>
          <button className="btn-secondary" onClick={() => setResetting(null)} disabled={busy}>Cancel</button>
          <button className="btn-primary" onClick={doReset} disabled={busy}>{busy ? 'Resetting…' : 'Reset password'}</button>
        </>}>
        <Field label="New temporary password" required>
          <Input type="text" value={resetPw} onChange={(e) => setResetPw(e.target.value)} placeholder="Min 8 chars, letter + number" />
        </Field>
        <p className="mt-2 text-xs text-slate-500">The user will be required to change this password at next sign-in.</p>
      </Modal>

      <ConfirmDialog open={!!deleting} busy={busy} onClose={() => setDeleting(null)} onConfirm={doDelete}
        title="Remove user?" confirmLabel="Remove"
        message={deleting ? `${deleting.name} will lose access to the system.` : ''} />
    </section>
  );
}
