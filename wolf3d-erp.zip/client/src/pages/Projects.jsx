import CrudPage from '../components/CrudPage';
import { StatusBadge } from '../components/ui';
import { PROJECT_STATUS, fmtDate } from '../lib/options';

export default function Projects() {
  return (
    <CrudPage
      resource="projects"
      title="Projects"
      subtitle="Track engineering projects from kickoff to delivery."
      createLabel="New Project"
      refreshEvents={['project_created', 'project_updated', 'project_deleted']}
      lookupsNeeded={['clients', 'users', 'projects']}
      statusOptions={PROJECT_STATUS}
      getRowTitle={(r) => r.project_name}
      defaults={{ status: 'pending', progress_percent: 0, assigned_to: [] }}
      columns={[
        { key: 'project_number', header: 'Project #', render: (r) => <span className="font-medium text-slate-900">{r.project_number}</span> },
        { key: 'project_name', header: 'Name', render: (r) => <span className="text-slate-700">{r.project_name}</span> },
        { key: 'client_name', header: 'Client', render: (r) => r.client_name || '—' },
        { key: 'status', header: 'Status', render: (r) => <StatusBadge value={r.status} /> },
        { key: 'progress', header: 'Progress', render: (r) => (
          <div className="flex items-center gap-2">
            <div className="h-1.5 w-20 overflow-hidden rounded-full bg-slate-100">
              <div className="h-full rounded-full bg-brand-500" style={{ width: `${r.progress_percent || 0}%` }} />
            </div>
            <span className="text-xs text-slate-500">{r.progress_percent || 0}%</span>
          </div>
        ) },
        { key: 'open_tasks', header: 'Open Tasks', render: (r) => r.open_tasks ?? 0 },
        { key: 'deadline', header: 'Deadline', render: (r) => fmtDate(r.deadline) }
      ]}
      buildForm={(r) => ({
        id: r.id, project_number: r.project_number, project_name: r.project_name, client_id: r.client_id,
        part_name: r.part_name, service_type: r.service_type, assigned_to: r.assigned_to || [],
        progress_percent: r.progress_percent, start_date: r.start_date, deadline: r.deadline,
        status: r.status, remarks: r.remarks, work_order_id: r.work_order_id
      })}
      fields={(lk) => [
        { name: 'project_number', label: 'Project Number', type: 'text', required: true, placeholder: 'PRJ-001' },
        { name: 'project_name', label: 'Project Name', type: 'text', required: true },
        { name: 'client_id', label: 'Client', type: 'select', numeric: true, options: lk.clients.map((c) => ({ value: c.id, label: c.name })) },
        { name: 'service_type', label: 'Service Type', type: 'text', placeholder: '3D Scanning, Reverse Eng…' },
        { name: 'part_name', label: 'Part Name', type: 'text' },
        { name: 'status', label: 'Status', type: 'select', required: true, options: PROJECT_STATUS },
        { name: 'progress_percent', label: 'Progress (%)', type: 'number', min: 0, max: 100 },
        { name: 'start_date', label: 'Start Date', type: 'date' },
        { name: 'deadline', label: 'Deadline', type: 'date' },
        { name: 'assigned_to', label: 'Assigned Team', type: 'multiselect', options: lk.users.map((u) => ({ value: u.id, label: u.name })) },
        { name: 'remarks', label: 'Remarks', type: 'textarea', full: true }
      ]}
    />
  );
}
