// Production field ownership by department (spec: Sales / Production / Quality).
const SALES = ['work_order_number', 'order_date', 'client_name', 'part_name', 'technology', 'quantity', 'finish', 'paint'];
const PRODUCTION = ['printing', 'clean_and_cure', 'sanding_and_polishing', 'paint_status'];
const QUALITY = ['xyz_dimension', 'critical_dimension', 'surface_finish', 'report_generated', 'rework_verdict', 'dispatch_status', 'dispatch_date'];
// Accounts/Dispatch billing fields (editable by Accounts, managers, admins).
const ACCOUNTS = ['delivery_challan', 'invoice_no'];
// part_image is view-only here (set via the dedicated upload endpoint, not the cell editor).
const ALL = [...SALES, 'part_image', ...PRODUCTION, ...QUALITY, ...ACCOUNTS];
// Always-visible row identifiers (so non-Sales staff can recognise the row).
const SALES_IDENTITY = ['work_order_number', 'part_name'];
// Departments that participate in the production sheet at all.
const WORKFLOW_DEPTS = ['sales', 'production', 'quality', 'dispatch'];

function deptNames(req) {
  return (req.user.departments || []).map((d) => String(d.name).toLowerCase());
}

function groups(req) {
  if (req.isManager) return { all: true };
  const n = deptNames(req);
  return { all: false, sales: n.includes('sales'), production: n.includes('production'), quality: n.includes('quality'), accounts: n.includes('accounts') };
}

// Fields this user may EDIT.
function editableFields(req) {
  const g = groups(req);
  if (g.all) return new Set(ALL);
  const s = new Set();
  if (g.sales) SALES.forEach((f) => s.add(f));
  if (g.production) PRODUCTION.forEach((f) => s.add(f));
  if (g.quality) QUALITY.forEach((f) => s.add(f));
  if (g.accounts) ACCOUNTS.forEach((f) => s.add(f));
  return s;
}

// Fields this user may SEE. Per the shared-workflow spec, EVERY employee can
// view the complete production workflow (Sales, Production, Quality, Dispatch).
// Editing stays department-specific via editableFields().
function visibleFields() {
  return new Set(ALL);
}

// Everyone can view the production sheet; editing is gated per field.
function canSeeProduction() {
  return true;
}

// Only Sales (work-order entry) and managers/admin may create new rows.
function canCreate(req) {
  if (req.isManager) return true;
  return deptNames(req).includes('sales');
}

// SQL expression that derives the pipeline position from filled fields
// (replaces the old stored "stage" — automatic, never manually edited).
const DERIVED_STAGE = `
  CASE
    WHEN lower(coalesce(dispatch_status,'')) ~ '(dispatch|deliver|complete|done|sent)' THEN 'completed'
    WHEN coalesce(dispatch_status,'') <> '' THEN 'dispatch'
    WHEN coalesce(xyz_dimension,'')||coalesce(critical_dimension,'')||coalesce(surface_finish,'')||coalesce(report_generated,'')||coalesce(rework_verdict,'') <> '' THEN 'quality'
    WHEN coalesce(printing,'')||coalesce(clean_and_cure,'')||coalesce(sanding_and_polishing,'')||coalesce(paint_status,'') <> '' THEN 'production'
    ELSE 'work_order'
  END`;

module.exports = { SALES, PRODUCTION, QUALITY, ACCOUNTS, ALL, SALES_IDENTITY, editableFields, visibleFields, canSeeProduction, canCreate, DERIVED_STAGE };
