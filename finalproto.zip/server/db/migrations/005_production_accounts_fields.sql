-- 005_production_accounts_fields.sql
-- Dispatch/Accounts fields from the company sheet: delivery challan + invoice no.
-- Editable by Accounts dept, managers and admins; visible to everyone.
ALTER TABLE production_records ADD COLUMN IF NOT EXISTS delivery_challan TEXT;
ALTER TABLE production_records ADD COLUMN IF NOT EXISTS invoice_no TEXT;
