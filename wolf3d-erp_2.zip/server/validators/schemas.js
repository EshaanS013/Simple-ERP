const { z } = require('zod');

const id = z.coerce.number().int().positive();
const idParam = z.object({ id });
const optStr = z.string().trim().max(2000).optional().nullable();
const shortStr = z.string().trim().max(120).optional().nullable();
const nonEmpty = (label) => z.string().trim().min(1, `${label} is required`);
const optDate = z.string().trim().optional().nullable().or(z.literal('').transform(() => null));
const optNum = z.coerce.number().optional().nullable();

const password = z.string().min(8, 'Password must be at least 8 characters')
  .regex(/[A-Za-z]/, 'Password must include a letter')
  .regex(/[0-9]/, 'Password must include a number');

const listQuery = z.object({
  page: z.coerce.number().int().positive().optional(),
  pageSize: z.coerce.number().int().positive().max(200).optional(),
  search: z.string().trim().optional(),
  status: z.string().trim().optional(),
  stage: z.string().trim().optional(),
  department_id: z.coerce.number().int().positive().optional(),
  machine_id: z.coerce.number().int().positive().optional(),
  project_id: z.coerce.number().int().positive().optional(),
  task_id: z.coerce.number().int().positive().optional(),
  production_id: z.coerce.number().int().positive().optional(),
  sort: z.string().trim().optional(),
  dir: z.enum(['asc', 'desc']).optional()
});

const projectStatus = z.enum(['work_order', 'in_production', 'in_quality', 'ready_for_dispatch', 'completed', 'on_hold', 'cancelled']);
const taskStatus = z.enum(['awaiting', 'in_progress', 'partially_complete', 'completed', 'blocked', 'cancelled']);
const taskPriority = z.enum(['low', 'medium', 'high', 'critical']);
const productionStage = z.enum(['work_order', 'production', 'quality', 'dispatch', 'completed']);
const paymentStatus = z.enum(['pending', 'received', 'overdue', 'partial']);

const schemas = {
  idParam,
  listQuery,

  login: z.object({
    name: nonEmpty('Full name'),
    password: z.string().min(1, 'Password is required')
  }),
  changePassword: z.object({
    currentPassword: z.string().min(1, 'Current password is required'),
    newPassword: password
  }),

  createUser: z.object({
    name: nonEmpty('Full name').max(80),
    password,
    role: z.enum(['admin', 'manager', 'employee']).default('employee'),
    department_ids: z.array(id).optional()
  }),
  updateUser: z.object({
    name: nonEmpty('Full name').max(80),
    role: z.enum(['admin', 'manager', 'employee']),
    status: z.enum(['active', 'inactive']),
    department_ids: z.array(id).optional()
  }),
  resetPassword: z.object({ newPassword: password }),

  createDepartment: z.object({
    name: nonEmpty('Department name').max(60),
    description: optStr
  }),
  createDesignUpdate: z.object({
    entry_date: optStr,
    project_name: z.string().trim().max(160).optional().nullable().or(z.literal('').transform(() => null)),
    designer_id: id.optional().nullable(),
    designer_name: z.string().trim().max(80).optional().nullable().or(z.literal('').transform(() => null)),
    work_done: optStr,
    comment: optStr,
    progress_percent: z.coerce.number().int().min(0).max(100).optional().nullable(),
    status: z.enum(['not_started', 'in_progress', 'completed']).optional().nullable()
  }),
  setMembers: z.object({ user_ids: z.array(id) }),
  createDesignAssignment: z.object({
    work_order_number: shortStr,
    client_name: shortStr,
    part_name: nonEmpty('Part name'),
    technology: shortStr,
    quantity: z.coerce.number().int().min(0).optional().nullable(),
    start_date: optDate,
    deadline: optDate,
    status: z.enum(['not_started', 'in_progress', 'completed', 'on_hold']).optional(),
    designer_ids: z.array(id).optional()
  }),
  designDailyUpdate: z.object({
    entry_date: optStr,
    progress_percent: z.coerce.number().int().min(0).max(100),
    work_done: optStr,
    comment: optStr,
    status: z.enum(['not_started', 'in_progress', 'completed', 'on_hold']).optional()
  }),
  designComment: z.object({
    body: nonEmpty('Comment').max(4000),
    parent_id: id.optional().nullable()
  }),
  assignPlannerRow: z.object({
    entry_date: nonEmpty('Date'),
    designer_id: id,
    assignment_id: id,
    target: optStr,
    target_status: z.enum(['awaiting', 'partially_complete', 'completed']).optional(),
    delivery_status: z.enum(['awaiting', 'delivered']).optional()
  }),
  updatePlannerRow: z.object({
    target: optStr,
    work_done: optStr,
    comment: optStr,
    progress_percent: z.coerce.number().int().min(0).max(100).optional(),
    target_status: z.enum(['awaiting', 'partially_complete', 'completed']).optional(),
    delivery_status: z.enum(['awaiting', 'delivered']).optional()
  }),
  sendMessage: z.object({
    recipient_id: id,
    body: nonEmpty('Message').max(4000)
  }),

  createProject: z.object({
    department_id: id.optional().nullable(),
    department_ids: z.array(id).optional(),
    member_ids: z.array(id).optional(),
    project_number: shortStr,
    work_order_number: shortStr,
    project_name: nonEmpty('Project name'),
    client_name: shortStr,
    technology: shortStr,
    part_name: shortStr,
    quantity: z.coerce.number().int().min(0).optional().nullable(),
    status: projectStatus.default('in_production'),
    progress_percent: z.coerce.number().int().min(0).max(100).default(0),
    start_date: optDate,
    deadline: optDate,
    remarks: optStr
  }),
  updateProjectStage: z.object({
    stage: z.enum(['design', 'production', 'quality', 'dispatch']),
    percent: z.coerce.number().int().min(0).max(100),
    note: optStr
  }),
  projectComment: z.object({
    body: nonEmpty('Comment').max(4000),
    parent_id: id.optional().nullable()
  }),
  assignProject: z.object({
    department_ids: z.array(id).optional(),
    member_ids: z.array(id).optional()
  }),

  createTask: z.object({
    department_id: id.optional().nullable(),
    project_id: id.optional().nullable(),
    task_name: nonEmpty('Task name'),
    assigned_to: id.optional().nullable(),
    priority: taskPriority.default('medium'),
    status: taskStatus.default('awaiting'),
    deadline: optDate,
    description: optStr
  }),

  createProduction: z.object({
    department_id: id.optional().nullable(),
    work_order_number: shortStr,
    order_date: optDate,
    client_name: shortStr,
    part_name: nonEmpty('Part name'),
    technology: shortStr,
    quantity: z.coerce.number().int().min(0).optional().nullable(),
    finish: shortStr,
    paint: shortStr,
    printing: shortStr,
    clean_and_cure: shortStr,
    sanding_and_polishing: shortStr,
    paint_status: shortStr,
    xyz_dimension: shortStr,
    critical_dimension: shortStr,
    surface_finish: shortStr,
    report_generated: shortStr,
    rework_verdict: shortStr,
    dispatch_status: shortStr,
    dispatch_date: optDate
  }),

  createMachine: z.object({
    name: nonEmpty('Machine name').max(80),
    technology: nonEmpty('Technology').max(40)
  }),
  createMachineUsage: z.object({
    machine_id: id,
    usage_date: nonEmpty('Date'),
    material: nonEmpty('Material').max(120),
    volume_cc: z.coerce.number().positive('Volume must be greater than 0'),
    hours: z.coerce.number().positive('Runtime must be greater than 0')
  }),
  updateMachineUsage: z.object({
    usage_date: nonEmpty('Date'),
    material: nonEmpty('Material').max(120),
    volume_cc: z.coerce.number().positive('Volume must be greater than 0'),
    hours: z.coerce.number().positive('Runtime must be greater than 0')
  }),

  createPayment: z.object({
    invoice_date: optDate,
    client_name: nonEmpty('Client name'),
    contact_number: shortStr,
    invoice_number: shortStr,
    amount: optNum,
    gst_status: shortStr,
    payment_terms: shortStr,
    payment_status: paymentStatus.default('pending'),
    action: shortStr,
    comments: optStr
  }),

  createNotice: z.object({
    title: nonEmpty('Title'),
    content: nonEmpty('Content'),
    urgent: z.coerce.boolean().optional(),
    pinned: z.coerce.boolean().optional()
  }),

  createUpdate: z.object({
    department_id: id,
    message: nonEmpty('Message')
  }),

  createComment: z.object({
    body: nonEmpty('Comment'),
    project_id: id.optional().nullable(),
    task_id: id.optional().nullable(),
    production_id: id.optional().nullable(),
    department_id: id.optional().nullable()
  }),

  upsertSetting: z.object({ key: nonEmpty('Key'), value: z.string().optional().nullable() })
};

module.exports = schemas;
