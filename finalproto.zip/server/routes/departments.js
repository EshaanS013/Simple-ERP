const express = require('express');
const { pool, withTransaction } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { attachScope, canUseDepartment, departmentFilter } = require('../utils/scope');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound, forbidden } = require('../middleware/errorHandler');
const { recordActivity } = require('../utils/activity');
const { emitEvent } = require('../socket/socket');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard, attachScope);

// List workspaces (employees see only theirs; managers see all) with counts.
router.get('/', asyncHandler(async (req, res) => {
  const scope = departmentFilter(req, 'd.id', 1);
  const whereSql = scope.clause ? `WHERE ${scope.clause}` : '';
  const { rows } = await pool.query(`
    SELECT d.id, d.name, d.description,
      (SELECT COUNT(*)::int FROM user_departments ud WHERE ud.department_id = d.id) AS member_count,
      (SELECT COUNT(*)::int FROM projects p WHERE p.department_id = d.id) AS project_count,
      (SELECT COUNT(*)::int FROM production_records pr WHERE pr.department_id = d.id) AS production_count,
      (SELECT COUNT(*)::int FROM updates u WHERE u.department_id = d.id) AS updates_count
    FROM departments d ${whereSql} ORDER BY d.name`, scope.params);
  res.json({ data: rows });
}));

// Workspace bundle: dashboard stats, members, recent feed.
router.get('/:id', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const dId = Number(req.params.id);
  if (!canUseDepartment(req, dId)) throw forbidden('You are not a member of this workspace');
  const dept = await pool.query('SELECT * FROM departments WHERE id = $1', [dId]);
  if (dept.rowCount === 0) throw notFound('Department not found');

  const { DERIVED_STAGE } = require('../utils/production');
  const PIPE = DERIVED_STAGE.replace(/\n/g, ' ');
  const [stats, members, feed] = await Promise.all([
    pool.query(`SELECT
        (SELECT COUNT(*)::int FROM projects WHERE department_id=$1) AS projects,
        (SELECT COUNT(*)::int FROM projects WHERE department_id=$1 AND status='completed') AS projects_completed,
        (SELECT COUNT(*)::int FROM production_records WHERE department_id=$1) AS production,
        COUNT(*) FILTER (WHERE pipe='production')::int AS in_production,
        COUNT(*) FILTER (WHERE pipe='quality')::int AS in_quality,
        COUNT(*) FILTER (WHERE pipe='dispatch')::int AS ready_dispatch,
        COUNT(*) FILTER (WHERE pipe='completed')::int AS completed
      FROM (SELECT (${PIPE}) AS pipe FROM production_records WHERE department_id=$1) q`, [dId]),
    pool.query(`SELECT u.id, u.name, u.username, u.role FROM user_departments ud JOIN users u ON u.id=ud.user_id WHERE ud.department_id=$1 AND u.status='active' ORDER BY u.name`, [dId]),
    pool.query(`SELECT up.id, up.message, up.created_at, us.name AS author_name FROM updates up LEFT JOIN users us ON us.id=up.author_id WHERE up.department_id=$1 AND up.parent_id IS NULL ORDER BY up.created_at DESC LIMIT 15`, [dId])
  ]);
  res.json({ department: dept.rows[0], stats: stats.rows[0], members: members.rows, feed: feed.rows });
}));

// Department feed: top-level posts, each with its replies nested.
router.get('/:id/updates', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  if (!canUseDepartment(req, Number(req.params.id))) throw forbidden('Not a member');
  const { rows } = await pool.query(
    `SELECT up.id, up.parent_id, up.message, up.created_at, us.name AS author_name
       FROM updates up LEFT JOIN users us ON us.id = up.author_id
       WHERE up.department_id = $1 ORDER BY up.created_at ASC LIMIT 500`, [req.params.id]);
  const byId = new Map();
  const top = [];
  rows.forEach((r) => { r.replies = []; byId.set(r.id, r); });
  rows.forEach((r) => { if (r.parent_id && byId.has(r.parent_id)) byId.get(r.parent_id).replies.push(r); else if (!r.parent_id) top.push(r); });
  top.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  res.json({ data: top });
}));

router.post('/:id/updates', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const dId = Number(req.params.id);
  if (!canUseDepartment(req, dId)) throw forbidden('You can only post in your own workspaces');
  const message = (req.body.message || '').trim();
  if (!message) throw notFound('Message is required');
  let parentId = null;
  if (req.body.parent_id) {
    const par = await pool.query('SELECT id FROM updates WHERE id=$1 AND department_id=$2 AND parent_id IS NULL', [req.body.parent_id, dId]);
    if (par.rowCount === 0) throw notFound('Parent post not found');
    parentId = Number(req.body.parent_id);
  }
  const { rows } = await pool.query(
    `INSERT INTO updates (department_id, parent_id, message, author_id) VALUES ($1,$2,$3,$4)
     RETURNING id, department_id, parent_id, message, created_at`, [dId, parentId, message, req.user.id]);
  const payload = { ...rows[0], author_name: req.user.name, replies: [] };
  emitEvent('update_created', payload);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: parentId ? 'replied in the feed' : 'posted an update', module: 'Departments', details: message.slice(0, 80), entityType: 'update', entityId: rows[0].id, departmentId: dId });
  res.status(201).json(payload);
}));

// ----- Management (manager only) -----
router.post('/', managerOnly, validate({ body: schemas.createDepartment }), asyncHandler(async (req, res) => {
  const { rows } = await pool.query('INSERT INTO departments (name, description) VALUES ($1,$2) RETURNING *', [req.body.name, req.body.description || null]);
  emitEvent('department_created', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'created a workspace', module: 'Departments', details: rows[0].name, entityType: 'department', entityId: rows[0].id, departmentId: rows[0].id });
  res.status(201).json(rows[0]);
}));

router.put('/:id', managerOnly, validate({ params: schemas.idParam, body: schemas.createDepartment }), asyncHandler(async (req, res) => {
  const { rows, rowCount } = await pool.query('UPDATE departments SET name=$1, description=$2 WHERE id=$3 RETURNING *', [req.body.name, req.body.description || null, req.params.id]);
  if (rowCount === 0) throw notFound('Department not found');
  emitEvent('department_updated', rows[0]);
  res.json(rows[0]);
}));

router.delete('/:id', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rowCount } = await pool.query('DELETE FROM departments WHERE id = $1', [req.params.id]);
  if (rowCount === 0) throw notFound('Department not found');
  emitEvent('department_deleted', { id: Number(req.params.id) });
  res.json({ success: true });
}));

// Membership (manager only).
router.get('/:id/members', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rows } = await pool.query('SELECT user_id FROM user_departments WHERE department_id = $1', [req.params.id]);
  res.json({ data: rows.map((r) => r.user_id) });
}));

router.put('/:id/members', managerOnly, validate({ params: schemas.idParam, body: schemas.setMembers }), asyncHandler(async (req, res) => {
  const dId = Number(req.params.id);
  await withTransaction(async (client) => {
    await client.query('DELETE FROM user_departments WHERE department_id = $1', [dId]);
    for (const uid of req.body.user_ids) {
      await client.query('INSERT INTO user_departments (user_id, department_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [uid, dId]);
    }
  });
  emitEvent('department_updated', { id: dId });
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'updated workspace members', module: 'Departments', entityType: 'department', entityId: dId, departmentId: dId });
  res.json({ success: true });
}));

module.exports = router;
