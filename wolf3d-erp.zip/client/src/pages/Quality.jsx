import CrudPage from '../components/CrudPage';
import { StatusBadge } from '../components/ui';
import { QUALITY_STATUS, fmtDate } from '../lib/options';

export default function Quality() {
  return (
    <CrudPage
      resource="quality"
      title="Quality Control"
      subtitle="Inspection reports and quality sign-off records."
      createLabel="New QC Report"
      refreshEvents={['quality_created', 'quality_updated', 'quality_deleted']}
      lookupsNeeded={['projects', 'users']}
      statusOptions={QUALITY_STATUS}
      getRowTitle={(r) => r.report_number}
      defaults={{ quality_status: 'pending' }}
      columns={[
        { key: 'report_number', header: 'Report #', render: (r) => <span className="font-medium text-slate-900">{r.report_number}</span> },
        { key: 'part_name', header: 'Part', render: (r) => r.part_name || '—' },
        { key: 'project_name', header: 'Project', render: (r) => r.project_name || '—' },
        { key: 'inspector_name', header: 'Inspector', render: (r) => r.inspector_name || '—' },
        { key: 'quality_status', header: 'Status', render: (r) => <StatusBadge value={r.quality_status} /> },
        { key: 'inspection_date', header: 'Inspected', render: (r) => fmtDate(r.inspection_date) }
      ]}
      buildForm={(r) => ({
        id: r.id, report_number: r.report_number, part_name: r.part_name, project_id: r.project_id,
        inspector_id: r.inspector_id, quality_status: r.quality_status, inspection_date: r.inspection_date,
        dimensions: r.dimensions, notes: r.notes
      })}
      fields={(lk) => [
        { name: 'report_number', label: 'Report Number', type: 'text', required: true, placeholder: 'QC-001' },
        { name: 'part_name', label: 'Part Name', type: 'text', required: true },
        { name: 'project_id', label: 'Project', type: 'select', numeric: true, options: lk.projects.map((p) => ({ value: p.id, label: p.project_name })) },
        { name: 'inspector_id', label: 'Inspector', type: 'select', numeric: true, options: lk.users.map((u) => ({ value: u.id, label: u.name })) },
        { name: 'quality_status', label: 'Status', type: 'select', required: true, options: QUALITY_STATUS },
        { name: 'inspection_date', label: 'Inspection Date', type: 'date' },
        { name: 'dimensions', label: 'Dimensions / Measurements', type: 'textarea', full: true },
        { name: 'notes', label: 'Notes', type: 'textarea', full: true }
      ]}
    />
  );
}
