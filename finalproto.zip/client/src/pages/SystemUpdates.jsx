import { useState, useEffect, useCallback, useRef } from 'react';
import { UploadCloud, CheckCircle2, XCircle, Loader2, Package, Clock, GitBranch, Tag, RefreshCw, AlertTriangle } from 'lucide-react';
import Api from '../services/api';
import { LoadingState, EmptyState } from '../components/ui';
import { useToast } from '../context/ToastContext';

const STAGE_ORDER = [
  ['validating', 'Validating update'],
  ['backup', 'Creating backup'],
  ['installing', 'Installing'],
  ['migrating', 'Migrating database'],
  ['health', 'Running health checks'],
  ['completed', 'Completed']
];

function InfoCard({ icon: Icon, label, value, sub, tone = 'text-slate-800' }) {
  return (
    <div className="card p-4">
      <div className="flex items-center gap-2 text-xs font-medium text-slate-500"><Icon className="h-4 w-4" />{label}</div>
      <div className={`mt-1 text-lg font-semibold ${tone}`}>{value}</div>
      {sub && <div className="text-[11px] text-slate-400">{sub}</div>}
    </div>
  );
}

const fmtDate = (s) => s ? new Date(s).toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
const fmtDur = (ms) => ms == null ? '—' : ms < 1000 ? `${ms} ms` : `${(ms / 1000).toFixed(1)} s`;
const RESULT = {
  success: 'bg-emerald-100 text-emerald-700', in_progress: 'bg-sky-100 text-sky-700',
  failed: 'bg-red-100 text-red-700', rolled_back: 'bg-amber-100 text-amber-800'
};

export default function SystemUpdates() {
  const toast = useToast();
  const [info, setInfo] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [file, setFile] = useState(null);
  const [validation, setValidation] = useState(null); // {valid, manifest, error}
  const [installing, setInstalling] = useState(false);
  const [activeStage, setActiveStage] = useState(null);
  const [result, setResult] = useState(null); // {success, ...} | {error}
  const fileRef = useRef();
  const stageTimer = useRef();

  const load = useCallback(async () => {
    try { const [i, h] = await Promise.all([Api.updatesInfo(), Api.updatesHistory()]); setInfo(i); setHistory(h.data || []); }
    catch (e) { toast.error(e.message); } finally { setLoading(false); }
  }, [toast]);
  useEffect(() => { load(); }, [load]);

  const pickFile = async (f) => {
    setFile(f); setValidation(null); setResult(null);
    if (!f) return;
    try { const v = await Api.validateUpdate(f); setValidation(v); if (!v.valid) toast.error(v.error || 'Invalid package'); }
    catch (e) { setValidation({ valid: false, error: e.message }); }
  };

  // Walk the progress labels while the (atomic) server request runs.
  const animateStages = () => {
    let idx = 0;
    setActiveStage(STAGE_ORDER[0][0]);
    stageTimer.current = setInterval(() => {
      idx = Math.min(idx + 1, STAGE_ORDER.length - 2); // hold before "completed" until server returns
      setActiveStage(STAGE_ORDER[idx][0]);
    }, 1100);
  };
  const stopStages = () => { clearInterval(stageTimer.current); };

  const install = async () => {
    if (!file || !validation?.valid) return;
    setInstalling(true); setResult(null); animateStages();
    try {
      const res = await Api.installUpdate(file);
      stopStages();
      if (res.success) { setActiveStage('completed'); setResult(res); toast.success(`Update v${res.version} installed`); }
      else { setActiveStage(null); setResult({ error: res.error || 'Update failed' }); toast.error(res.error || 'Update failed'); }
      load();
    } catch (e) { stopStages(); setActiveStage(null); setResult({ error: e.message }); toast.error(e.message); }
    finally { setInstalling(false); }
  };

  const reset = () => { setFile(null); setValidation(null); setResult(null); setActiveStage(null); if (fileRef.current) fileRef.current.value = ''; };

  if (loading) return <LoadingState label="Loading update status…" />;

  return (
    <div>
      {/* Version info */}
      <div className="mb-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        <InfoCard icon={Tag} label="Current version" value={`v${info?.current_version || '—'}`} tone="text-brand-600" />
        <InfoCard icon={GitBranch} label="Build" value={info?.build || '—'} />
        <InfoCard icon={Clock} label="Release date" value={info?.release_date || '—'} />
        <InfoCard icon={Package} label="Last installed" value={info?.last_installed ? `v${info.last_installed.version}` : 'None'} sub={info?.last_installed ? fmtDate(info.last_installed.created_at) : 'No updates yet'} />
        <InfoCard icon={RefreshCw} label="System status"
          value={info?.status === 'healthy' ? 'Up to date' : info?.status === 'restart_pending' ? 'Restart pending' : 'Degraded'}
          tone={info?.status === 'degraded' ? 'text-red-600' : info?.status === 'restart_pending' ? 'text-amber-600' : 'text-emerald-600'} />
      </div>

      {info?.restart_pending && (
        <div className="mb-6 flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
          <div>Version <b>v{info.staged?.version}</b> is staged and will activate after the next service restart (<code className="rounded bg-amber-100 px-1">docker compose restart</code>). Company data is preserved.</div>
        </div>
      )}

      {/* Upload + install */}
      <h3 className="mb-2 text-sm font-semibold text-slate-700">Install an update</h3>
      <div className="card mb-6 p-5">
        {!installing && !result && (
          <>
            <div onClick={() => fileRef.current?.click()} onDragOver={(e) => e.preventDefault()} onDrop={(e) => { e.preventDefault(); pickFile(e.dataTransfer.files?.[0]); }}
              className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed border-slate-200 px-4 py-8 text-center hover:border-brand-300 hover:bg-brand-50/40">
              <UploadCloud className="mb-2 h-8 w-8 text-slate-400" />
              <p className="text-sm font-medium text-slate-700">{file ? file.name : 'Drop a wolf3d_update_vX.Y.Z.zip here, or click to browse'}</p>
              <p className="mt-1 text-[11px] text-slate-400">Compiled release package (.zip) with manifest and checksums</p>
              <input ref={fileRef} type="file" accept=".zip" className="hidden" onChange={(e) => pickFile(e.target.files?.[0])} />
            </div>

            {validation && (
              <div className={`mt-3 rounded-lg border p-3 text-sm ${validation.valid ? 'border-emerald-200 bg-emerald-50' : 'border-red-200 bg-red-50'}`}>
                {validation.valid ? (
                  <div className="flex items-start gap-2 text-emerald-800">
                    <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" />
                    <div>
                      <p className="font-medium">Package verified: v{validation.manifest.version} (build {validation.manifest.build})</p>
                      <p className="text-[11px] text-emerald-700">Requires ≥ v{validation.manifest.min_compatible} · checksums valid · ready to install</p>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-start gap-2 text-red-800"><XCircle className="mt-0.5 h-4 w-4 shrink-0" /><div><p className="font-medium">Invalid package</p><p className="text-[11px]">{validation.error}</p></div></div>
                )}
              </div>
            )}

            <div className="mt-4 flex justify-end gap-2">
              {file && <button className="btn-secondary" onClick={reset}>Clear</button>}
              <button className="btn-primary" disabled={!validation?.valid} onClick={install}>Install update</button>
            </div>
          </>
        )}

        {/* Progress */}
        {(installing || result) && (
          <div>
            <div className="space-y-2">
              {STAGE_ORDER.map(([key, label]) => {
                const order = STAGE_ORDER.findIndex(([k]) => k === activeStage);
                const meIdx = STAGE_ORDER.findIndex(([k]) => k === key);
                const state = result?.error ? (meIdx < order ? 'done' : meIdx === order ? 'fail' : 'todo')
                  : result?.success ? 'done' : meIdx < order ? 'done' : meIdx === order ? 'active' : 'todo';
                return (
                  <div key={key} className="flex items-center gap-2 text-sm">
                    {state === 'done' && <CheckCircle2 className="h-4 w-4 text-emerald-500" />}
                    {state === 'active' && <Loader2 className="h-4 w-4 animate-spin text-brand-500" />}
                    {state === 'fail' && <XCircle className="h-4 w-4 text-red-500" />}
                    {state === 'todo' && <span className="h-4 w-4 rounded-full border border-slate-200" />}
                    <span className={state === 'todo' ? 'text-slate-400' : state === 'fail' ? 'text-red-600' : 'text-slate-700'}>{label}</span>
                  </div>
                );
              })}
            </div>
            {result?.success && (
              <div className="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 p-3 text-sm text-emerald-800">
                <p className="font-medium">Update v{result.version} installed successfully in {fmtDur(result.duration_ms)}.</p>
                <p className="text-[11px]">A pre-update backup was created ({result.backup}). Restart services to activate the new version.</p>
                <button className="btn-secondary mt-3" onClick={reset}>Done</button>
              </div>
            )}
            {result?.error && (
              <div className="mt-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-800">
                <p className="font-medium">Update failed — rolled back automatically.</p>
                <p className="text-[11px]">{result.error}</p>
                <button className="btn-secondary mt-3" onClick={reset}>Try again</button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* History */}
      <h3 className="mb-2 text-sm font-semibold text-slate-700">Update history</h3>
      <div className="card p-0">
        {history.length === 0 ? <EmptyState title="No updates yet" message="Installed updates will appear here." /> : (
          <table className="w-full text-sm">
            <thead><tr className="border-b border-slate-200 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
              <th className="px-4 py-3">Version</th><th className="px-4 py-3">Installed by</th><th className="px-4 py-3">Time</th><th className="px-4 py-3">Result</th><th className="px-4 py-3">Duration</th>
            </tr></thead>
            <tbody>
              {history.map((h) => (
                <tr key={h.id} className="border-b border-slate-100 last:border-0">
                  <td className="px-4 py-2.5 font-medium text-slate-700">v{h.version}{h.from_version && <span className="text-[11px] text-slate-400"> ← v{h.from_version}</span>}</td>
                  <td className="px-4 py-2.5 text-slate-600">{h.installed_by || '—'}</td>
                  <td className="px-4 py-2.5 text-slate-600">{fmtDate(h.created_at)}</td>
                  <td className="px-4 py-2.5"><span className={`rounded px-2 py-0.5 text-[11px] font-medium ${RESULT[h.result] || 'bg-slate-100 text-slate-600'}`}>{h.result.replace('_', ' ')}</span></td>
                  <td className="px-4 py-2.5 text-slate-600">{fmtDur(h.duration_ms)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
