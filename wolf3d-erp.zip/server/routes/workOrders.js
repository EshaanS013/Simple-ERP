const express = require('express');
const { pool } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound } = require('../middleware/errorHandler');
const { emitEvent } = require('../socket/socket');
const { recordActivity } = require('../utils/activity');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

const DETAIL = `
  SELECT w.*, c.name AS client_name, u.name AS assigned_to_name
  FROM work_orders w
  LEFT JOIN clients c ON c.id = w.client_id
  LEFT JOIN users u ON u.id = w.assigned_to`;

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query);
  const { search, status, sort } = req.query;
  const conditions = [];
  const values = [];
  let i = 1;
  if (search) { conditions.push(`(w.work_order_number ILIKE $${i} OR w.part_name ILIKE $${i} OR w.description ILIKE $${i})`); values.push(`%${search}%`); i++; }
  if (status) { conditions.push(`w.status = $${i}`); values.push(status); i++; }
  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
  const order = sort === 'oldest' ? 'ORDER BY w.created_at ASC' : 'ORDER BY w.created_at DESC';

  const total = await pool.query(`SELECT COUNT(*)::int c FROM work_orders w ${where}`, values);
  const rows = await pool.query(`${DETAIL} ${where} ${order} LIMIT $${i} OFFSET $${i + 1}`, [...values, pageSize, offset]);
  res.json(paginatedResponse(rows.rows, total.rows[0].c, page, pageSize));
}));

router.get('/:id', validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rows, rowCount } = await pool.query(`${DETAIL} WHERE w.id = $1`, [req.params.id]);
  if (rowCount === 0) throw notFound('Work order not found');
  res.json(rows[0]);
}));

router.post('/', managerOnly, validate({ body: schemas.createWorkOrder }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO work_orders (work_order_number, client_id, service_type, part_name, quantity, description, status, assigned_to, submission_date, created_by)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [b.work_order_number, b.client_id || null, b.service_type, b.part_name || null, b.quantity, b.description || null, b.status, b.assigned_to || null, b.submission_date || null, req.user.id]
  );
  const wo = rows[0];
  emitEvent('work_order_created', wo);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'created a work order', module: 'Work Orders', details: wo.work_order_number, entityType: 'work_order', entityId: wo.id });
  res.status(201).json(wo);
}));

router.put('/:id', managerOnly, validate({ params: schemas.idParam, body: schemas.updateWorkOrder }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows, rowCount } = await pool.query(
    `UPDATE work_orders SET client_id=$1, service_type=$2, part_name=$3, quantity=$4, description=$5, status=$6, assigned_to=$7, submission_date=$8
     WHERE id=$9 RETURNING *`,
    [b.client_id || null, b.service_type, b.part_name || null, b.quantity, b.description || null, b.status, b.assigned_to || null, b.submission_date || null, req.params.id]
  );
  if (rowCount === 0) throw notFound('Work order not found');
  emitEvent('work_order_updated', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'updated a work order', module: 'Work Orders', details: rows[0].work_order_number, entityType: 'work_order', entityId: rows[0].id });
  res.json(rows[0]);
}));

router.delete('/:id', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rows, rowCount } = await pool.query('DELETE FROM work_orders WHERE id = $1 RETURNING work_order_number', [req.params.id]);
  if (rowCount === 0) throw notFound('Work order not found');
  emitEvent('work_order_deleted', { id: Number(req.params.id) });
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'deleted a work order', module: 'Work Orders', details: rows[0].work_order_number });
  res.json({ success: true });
}));

module.exports = router;
