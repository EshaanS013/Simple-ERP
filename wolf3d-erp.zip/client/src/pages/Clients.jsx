import CrudPage from '../components/CrudPage';
import { fmtDate } from '../lib/options';

export default function Clients() {
  return (
    <CrudPage
      resource="clients"
      title="Clients"
      subtitle="Companies and contacts WOLF3D works with."
      createLabel="New Client"
      refreshEvents={['client_created', 'client_updated', 'client_deleted']}
      getRowTitle={(r) => r.name}
      defaults={{}}
      columns={[
        { key: 'name', header: 'Name', render: (r) => <span className="font-medium text-slate-900">{r.name}</span> },
        { key: 'contact_person', header: 'Contact', render: (r) => r.contact_person || '—' },
        { key: 'email', header: 'Email', render: (r) => r.email || '—' },
        { key: 'phone', header: 'Phone', render: (r) => r.phone || '—' },
        { key: 'created_at', header: 'Added', render: (r) => fmtDate(r.created_at) }
      ]}
      buildForm={(r) => ({ id: r.id, name: r.name, contact_person: r.contact_person, email: r.email, phone: r.phone, address: r.address })}
      fields={() => [
        { name: 'name', label: 'Company Name', type: 'text', required: true },
        { name: 'contact_person', label: 'Contact Person', type: 'text' },
        { name: 'email', label: 'Email', type: 'text', placeholder: 'name@company.com' },
        { name: 'phone', label: 'Phone', type: 'text' },
        { name: 'address', label: 'Address', type: 'textarea', full: true }
      ]}
    />
  );
}
