import { useState } from 'react';
import { Field, Input, Textarea, Select } from './ui';

// Renders a form from a field config array. Field shape:
// { name, label, type, required, options?, min?, max?, placeholder?, half? }
// type: text | number | date | textarea | select | checkbox | multiselect
export default function ResourceForm({ fields, initial, onSubmit, onCancel, submitLabel = 'Save', busy }) {
  const [values, setValues] = useState(() => {
    const v = {};
    fields.forEach((f) => {
      const init = initial?.[f.name];
      if (f.type === 'checkbox') v[f.name] = !!init;
      else if (f.type === 'multiselect') v[f.name] = Array.isArray(init) ? init.map(Number) : [];
      else if (f.type === 'date') v[f.name] = init ? String(init).slice(0, 10) : '';
      else v[f.name] = init ?? (f.type === 'number' ? '' : '');
    });
    return v;
  });
  const [errors, setErrors] = useState({});

  const set = (name, value) => setValues((v) => ({ ...v, [name]: value }));

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = {};
    fields.forEach((f) => {
      if (f.required) {
        const val = values[f.name];
        const empty = f.type === 'multiselect' ? !val?.length : val === '' || val == null;
        if (empty) errs[f.name] = `${f.label} is required`;
      }
    });
    if (Object.keys(errs).length) { setErrors(errs); return; }
    // Coerce types
    const payload = {};
    fields.forEach((f) => {
      let val = values[f.name];
      if (f.type === 'number') val = val === '' ? null : Number(val);
      if (f.type === 'select' && f.numeric) val = val === '' ? null : Number(val);
      if (f.type === 'date') val = val || null;
      if (f.type === 'multiselect') val = (val || []).map(Number);
      if ((f.type === 'text' || f.type === 'textarea') && typeof val === 'string') val = val.trim();
      payload[f.name] = val;
    });
    onSubmit(payload);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        {fields.map((f) => {
          const span = f.full || f.type === 'textarea' || f.type === 'multiselect' ? 'sm:col-span-2' : '';
          if (f.type === 'checkbox') {
            return (
              <label key={f.name} className={`flex items-center gap-2 ${span}`}>
                <input type="checkbox" checked={!!values[f.name]} onChange={(e) => set(f.name, e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-brand-600 focus:ring-brand-500" />
                <span className="text-sm text-slate-700">{f.label}</span>
              </label>
            );
          }
          return (
            <div key={f.name} className={span}>
              <Field label={f.label} required={f.required} error={errors[f.name]}>
                {f.type === 'textarea' ? (
                  <Textarea rows={f.rows || 3} value={values[f.name] ?? ''} placeholder={f.placeholder}
                    onChange={(e) => set(f.name, e.target.value)} />
                ) : f.type === 'select' ? (
                  <Select value={values[f.name] ?? ''} onChange={(e) => set(f.name, e.target.value)}>
                    <option value="">{f.placeholder || 'Select…'}</option>
                    {f.options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                  </Select>
                ) : f.type === 'multiselect' ? (
                  <div className="flex max-h-36 flex-wrap gap-2 overflow-y-auto rounded-lg border border-slate-200 p-2">
                    {f.options.length === 0 && <span className="text-xs text-slate-400">No options</span>}
                    {f.options.map((o) => {
                      const active = values[f.name]?.includes(Number(o.value));
                      return (
                        <button type="button" key={o.value}
                          onClick={() => set(f.name, active ? values[f.name].filter((x) => x !== Number(o.value)) : [...values[f.name], Number(o.value)])}
                          className={`badge cursor-pointer ${active ? 'bg-brand-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                          {o.label}
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <Input type={f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text'}
                    min={f.min} max={f.max} placeholder={f.placeholder}
                    value={values[f.name] ?? ''} onChange={(e) => set(f.name, e.target.value)} />
                )}
              </Field>
            </div>
          );
        })}
      </div>
      <div className="flex items-center justify-end gap-2 pt-2">
        <button type="button" className="btn-secondary" onClick={onCancel} disabled={busy}>Cancel</button>
        <button type="submit" className="btn-primary" disabled={busy}>{busy ? 'Saving…' : submitLabel}</button>
      </div>
    </form>
  );
}
