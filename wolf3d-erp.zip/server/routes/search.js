const express = require('express');
const { pool } = require('../db/pool');
const { authGuard } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();
router.use(authGuard);

// Global search. Employee/user results are restricted to managers to avoid
// exposing the staff directory to every authenticated user.
router.get('/', asyncHandler(async (req, res) => {
  const q = (req.query.q || '').trim();
  if (!q) return res.json({ results: [] });
  const term = `%${q}%`;
  const isManager = req.user.role === 'manager';

  const queries = [
    pool.query("SELECT id, project_number AS label, project_name AS detail, status FROM projects WHERE project_number ILIKE $1 OR project_name ILIKE $1 OR remarks ILIKE $1 LIMIT 8", [term]),
    pool.query("SELECT id, work_order_number AS label, part_name AS detail, status FROM work_orders WHERE work_order_number ILIKE $1 OR part_name ILIKE $1 OR description ILIKE $1 LIMIT 8", [term]),
    pool.query("SELECT id, name AS label, contact_person AS detail FROM clients WHERE name ILIKE $1 OR contact_person ILIKE $1 LIMIT 8", [term]),
    pool.query("SELECT id, task_name AS label, status AS detail FROM tasks WHERE task_name ILIKE $1 LIMIT 8", [term]),
    pool.query("SELECT id, title AS label, urgent AS detail FROM notices WHERE title ILIKE $1 OR content ILIKE $1 LIMIT 8", [term])
  ];

  const [projects, workOrders, clients, tasks, notices] = await Promise.all(queries);

  const results = [
    { type: 'Project', route: '/projects', items: projects.rows },
    { type: 'Work Order', route: '/work-orders', items: workOrders.rows },
    { type: 'Client', route: '/clients', items: clients.rows },
    { type: 'Task', route: '/tasks', items: tasks.rows },
    { type: 'Notice', route: '/notices', items: notices.rows }
  ];

  if (isManager) {
    const users = await pool.query("SELECT id, name AS label, role AS detail FROM users WHERE name ILIKE $1 OR username ILIKE $1 LIMIT 8", [term]);
    results.push({ type: 'Employee', route: '/users', items: users.rows });
  }

  res.json({ results: results.filter((r) => r.items.length > 0) });
}));

module.exports = router;
