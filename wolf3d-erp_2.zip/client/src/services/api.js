import axios from 'axios';

const baseURL = import.meta.env.VITE_API_BASE_URL || '';

export const TOKEN_KEY = 'wolf3d_token';
export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => localStorage.setItem(TOKEN_KEY, t);
export const clearToken = () => localStorage.removeItem(TOKEN_KEY);

const api = axios.create({ baseURL, timeout: 20000 });

api.interceptors.request.use((config) => {
  const token = getToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (error) => {
    if (error.response?.status === 401 && getToken()) {
      clearToken();
      window.dispatchEvent(new CustomEvent('auth:expired'));
    }
    const message =
      error.response?.data?.error ||
      (error.code === 'ECONNABORTED' ? 'The request timed out' : null) ||
      error.message || 'Something went wrong';
    return Promise.reject(new Error(message));
  }
);

const unwrap = (p) => p.then((r) => r.data);
const list = (resource, params) => unwrap(api.get(`/api/${resource}`, { params }));
const get = (resource, id) => unwrap(api.get(`/api/${resource}/${id}`));
const create = (resource, body) => unwrap(api.post(`/api/${resource}`, body));
const update = (resource, id, body) => unwrap(api.put(`/api/${resource}/${id}`, body));
const remove = (resource, id) => unwrap(api.delete(`/api/${resource}/${id}`));

export const Api = {
  raw: api,
  // Auth
  login: (body) => unwrap(api.post('/api/auth/login', body)),
  me: () => unwrap(api.get('/api/auth/me')),
  changePassword: (body) => unwrap(api.post('/api/auth/change-password', body)),
  // Dashboard / activity
  dashboard: () => unwrap(api.get('/api/dashboard')),
  activities: (params) => list('activities', params),
  // Lookups
  usersLookup: () => unwrap(api.get('/api/users/lookup')),
  // Departments (workspaces)
  departments: () => unwrap(api.get('/api/departments')),
  department: (id) => unwrap(api.get(`/api/departments/${id}`)),
  departmentUpdates: (id) => unwrap(api.get(`/api/departments/${id}/updates`)),
  postDepartmentUpdate: (id, message, parent_id) => unwrap(api.post(`/api/departments/${id}/updates`, parent_id ? { message, parent_id } : { message })),
  departmentMembers: (id) => unwrap(api.get(`/api/departments/${id}/members`)),
  setDepartmentMembers: (id, user_ids) => unwrap(api.put(`/api/departments/${id}/members`, { user_ids })),
  // Machines
  machines: () => unwrap(api.get('/api/machines')),
  machineUsage: (id, params) => unwrap(api.get(`/api/machines/${id}/usage`, { params })),
  machineDashboard: (id) => unwrap(api.get(`/api/machines/${id}/dashboard`)),
  accountsAnalytics: () => unwrap(api.get('/api/payments/analytics')),
  createMachine: (body) => unwrap(api.post('/api/machines', body)),
  deleteMachine: (id) => unwrap(api.delete(`/api/machines/${id}`)),
  logMachineUsage: (body) => unwrap(api.post('/api/machines/usage', body)),
  updateMachineUsage: (id, body) => unwrap(api.put(`/api/machines/usage/${id}`, body)),
  deleteMachineUsage: (id) => unwrap(api.delete(`/api/machines/usage/${id}`)),
  // Comments (attach to a project / task / production record)
  comments: (params) => list('comments', params),
  // Projects (central multi-department object)
  productionMeta: () => unwrap(api.get('/api/production/meta')),
  // Design assignments (central project workspace)
  designAssignments: () => unwrap(api.get('/api/design')),
  designAssignment: (id) => unwrap(api.get(`/api/design/${id}`)),
  createDesignAssignment: (body) => unwrap(api.post('/api/design', body)),
  updateDesignAssignment: (id, body) => unwrap(api.put(`/api/design/${id}`, body)),
  addDesignUpdate: (id, body) => unwrap(api.post(`/api/design/${id}/updates`, body)),
  designComments: (id) => unwrap(api.get(`/api/design/${id}/comments`)),
  postDesignComment: (id, body, parent_id) => unwrap(api.post(`/api/design/${id}/comments`, parent_id ? { body, parent_id } : { body })),
  deleteDesignAssignment: (id) => unwrap(api.delete(`/api/design/${id}`)),
  // Daily Design Planner
  designPlanner: (params) => unwrap(api.get('/api/design/planner', { params })),
  designStats: (params) => unwrap(api.get('/api/design/stats', { params })),
  assignPlannerRow: (body) => unwrap(api.post('/api/design/planner', body)),
  updatePlannerRow: (id, body) => unwrap(api.put(`/api/design/planner/${id}`, body)),
  deletePlannerRow: (id) => unwrap(api.delete(`/api/design/planner/${id}`)),
  productionHistory: (id) => unwrap(api.get(`/api/production/${id}/history`)),
  // Direct messages
  messageContacts: () => unwrap(api.get('/api/messages/contacts')),
  conversation: (userId) => unwrap(api.get(`/api/messages/${userId}`)),
  sendMessage: (recipient_id, body) => unwrap(api.post('/api/messages', { recipient_id, body })),
  unreadCount: () => unwrap(api.get('/api/messages/unread-count')),
  searchMessages: (q) => unwrap(api.get(`/api/messages/search?q=${encodeURIComponent(q)}`)),
  addComment: (body) => create('comments', body),
  deleteComment: (id) => remove('comments', id),
  // Notices
  notices: () => unwrap(api.get('/api/notices')),
  createNotice: (b) => unwrap(api.post('/api/notices', b)),
  deleteNotice: (id) => unwrap(api.delete(`/api/notices/${id}`)),
  // Generic
  list, get, create, update, remove
};

export default Api;
