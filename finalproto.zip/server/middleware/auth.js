const jwt = require('jsonwebtoken');
const { pool } = require('../db/pool');
const config = require('../config/env');
const { unauthorized, forbidden, asyncHandler } = require('./errorHandler');

function getToken(req) {
  const authHeader = req.headers.authorization;
  if (!authHeader) return null;
  const [type, token] = authHeader.split(' ');
  if (type !== 'Bearer' || !token) return null;
  return token;
}

// Verify a JWT and resolve the current user record. Shared by HTTP + sockets.
async function resolveUserFromToken(token) {
  const payload = jwt.verify(token, config.JWT_SECRET);
  const result = await pool.query(
    `SELECT u.id, u.name, u.username, u.role, u.status, u.must_change_password
     FROM users u WHERE u.id = $1`,
    [payload.userId]
  );
  if (result.rowCount === 0) return null;
  const user = result.rows[0];
  if (user.status !== 'active') return null;
  // Attach department memberships (ids + names) for scoping and UI.
  const deps = await pool.query(
    `SELECT d.id, d.name FROM user_departments ud JOIN departments d ON d.id = ud.department_id
     WHERE ud.user_id = $1 ORDER BY d.name`, [user.id]
  );
  user.departments = deps.rows;
  user.department_ids = deps.rows.map((r) => r.id);
  return user;
}

const authGuard = asyncHandler(async (req, res, next) => {
  const token = getToken(req);
  if (!token) throw unauthorized();
  let user;
  try {
    user = await resolveUserFromToken(token);
  } catch (err) {
    throw unauthorized('Invalid or expired session');
  }
  if (!user) throw unauthorized('Invalid or expired session');
  req.user = user;
  next();
});

function requireRole(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return next(forbidden('Manager access required'));
    }
    next();
  };
}

const managerOnly = requireRole('manager', 'admin');
const adminOnly = requireRole('admin');

// Allows admins, managers, or members of one of the named departments.
// Used to gate whole modules (e.g. Accounts) by department membership.
function requireDepartment(...names) {
  const wanted = names.map((n) => String(n).toLowerCase());
  return (req, res, next) => {
    if (!req.user) return next(unauthorized());
    if (req.user.role === 'admin' || req.user.role === 'manager') return next();
    const mine = (req.user.departments || []).map((d) => String(d.name).toLowerCase());
    if (mine.some((d) => wanted.includes(d))) return next();
    return next(forbidden('You do not have access to this module'));
  };
}

module.exports = { authGuard, managerOnly, adminOnly, requireRole, requireDepartment, resolveUserFromToken };
