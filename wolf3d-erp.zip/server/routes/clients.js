const express = require('express');
const { pool } = require('../db/pool');
const { authGuard, managerOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound } = require('../middleware/errorHandler');
const { recordActivity } = require('../utils/activity');
const { emitEvent } = require('../socket/socket');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

router.get('/', validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query, 50);
  const { search } = req.query;
  const where = search ? 'WHERE name ILIKE $1 OR contact_person ILIKE $1 OR email ILIKE $1' : '';
  const values = search ? [`%${search}%`] : [];
  const i = values.length + 1;
  const total = await pool.query(`SELECT COUNT(*)::int c FROM clients ${where}`, values);
  const rows = await pool.query(`SELECT * FROM clients ${where} ORDER BY name LIMIT $${i} OFFSET $${i + 1}`, [...values, pageSize, offset]);
  res.json(paginatedResponse(rows.rows, total.rows[0].c, page, pageSize));
}));

router.post('/', managerOnly, validate({ body: schemas.createClient }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO clients (name, contact_person, email, phone, address, created_by)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [b.name, b.contact_person || null, b.email || null, b.phone || null, b.address || null, req.user.id]
  );
  emitEvent('client_created', rows[0]);
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'added a client', module: 'Clients', details: rows[0].name, entityType: 'client', entityId: rows[0].id });
  res.status(201).json(rows[0]);
}));

router.put('/:id', managerOnly, validate({ params: schemas.idParam, body: schemas.createClient }), asyncHandler(async (req, res) => {
  const b = req.body;
  const { rows, rowCount } = await pool.query(
    `UPDATE clients SET name=$1, contact_person=$2, email=$3, phone=$4, address=$5 WHERE id=$6 RETURNING *`,
    [b.name, b.contact_person || null, b.email || null, b.phone || null, b.address || null, req.params.id]
  );
  if (rowCount === 0) throw notFound('Client not found');
  emitEvent('client_updated', rows[0]);
  res.json(rows[0]);
}));

router.delete('/:id', managerOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  const { rowCount } = await pool.query('DELETE FROM clients WHERE id = $1', [req.params.id]);
  if (rowCount === 0) throw notFound('Client not found');
  emitEvent('client_deleted', { id: Number(req.params.id) });
  res.json({ success: true });
}));

module.exports = router;
