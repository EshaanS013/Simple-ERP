const express = require('express');
const bcrypt = require('bcryptjs');
const { pool, withTransaction } = require('../db/pool');
const config = require('../config/env');
const { authGuard, managerOnly, adminOnly } = require('../middleware/auth');
const { validate } = require('../middleware/validate');
const { asyncHandler, notFound, badRequest } = require('../middleware/errorHandler');
const { recordActivity } = require('../utils/activity');
const { emitEvent, getOnlineUserIds } = require('../socket/socket');
const { getPagination, paginatedResponse } = require('../utils/pagination');
const schemas = require('../validators/schemas');

const router = express.Router();
router.use(authGuard);

// Lightweight lookup for assignee dropdowns (any authenticated user).
router.get('/lookup', asyncHandler(async (req, res) => {
  const { rows } = await pool.query("SELECT id, name, role FROM users WHERE status='active' ORDER BY name");
  res.json(rows);
}));

async function loadDepartments(userId) {
  const { rows } = await pool.query('SELECT department_id FROM user_departments WHERE user_id = $1', [userId]);
  return rows.map((r) => r.department_id);
}

// Full user list (manager only).
router.get('/', managerOnly, validate({ query: schemas.listQuery }), asyncHandler(async (req, res) => {
  const { page, pageSize, offset } = getPagination(req.query, 25);
  const { search, role } = req.query;
  const where = []; const params = []; let i = 1;
  if (role) { where.push(`role = $${i++}`); params.push(role); }
  if (search) { where.push(`name ILIKE $${i}`); params.push(`%${search}%`); i++; }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = await pool.query(`SELECT COUNT(*)::int c FROM users ${whereSql}`, params);
  const rows = await pool.query(
    `SELECT u.id, u.name, u.username, u.role, u.status, u.must_change_password, u.created_at,
        COALESCE(json_agg(json_build_object('id', d.id, 'name', d.name)) FILTER (WHERE d.id IS NOT NULL), '[]') AS departments
       FROM users u
       LEFT JOIN user_departments ud ON ud.user_id = u.id
       LEFT JOIN departments d ON d.id = ud.department_id
       ${whereSql}
       GROUP BY u.id ORDER BY u.name LIMIT $${i++} OFFSET $${i++}`,
    [...params, pageSize, offset]
  );
  const online = new Set(getOnlineUserIds());
  const data = rows.rows.map((u) => ({ ...u, online: online.has(u.id) }));
  res.json(paginatedResponse(data, total.rows[0].c, page, pageSize));
}));

router.post('/', adminOnly, validate({ body: schemas.createUser }), asyncHandler(async (req, res) => {
  const b = req.body;
  const hash = await bcrypt.hash(b.password, config.BCRYPT_ROUNDS);
  const created = await withTransaction(async (client) => {
    const { rows } = await client.query(
      `INSERT INTO users (name, password_hash, role, must_change_password, created_by)
       VALUES ($1,$2,$3,false,$4) RETURNING id, name, role, status`,
      [b.name, hash, b.role || 'employee', req.user.id]
    );
    const u = rows[0];
    for (const dId of b.department_ids || []) {
      await client.query('INSERT INTO user_departments (user_id, department_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [u.id, dId]);
    }
    return u;
  });
  emitEvent('user_created', { id: created.id });
  await recordActivity({ userId: req.user.id, userName: req.user.name, action: 'created a user', module: 'Team', details: created.name, entityType: 'user', entityId: created.id });
  res.status(201).json(created);
}));

router.put('/:id', adminOnly, validate({ params: schemas.idParam, body: schemas.updateUser }), asyncHandler(async (req, res) => {
  const b = req.body;
  const targetId = Number(req.params.id);
  const rank = { employee: 1, manager: 2, admin: 3 };
  if (targetId === req.user.id && (b.status !== 'active' || rank[b.role] < rank[req.user.role])) {
    throw badRequest('You cannot demote or deactivate your own account');
  }
  const updated = await withTransaction(async (client) => {
    const { rows, rowCount } = await client.query(
      'UPDATE users SET name=$1, role=$2, status=$3 WHERE id=$4 RETURNING id, name, username, role, status',
      [b.name, b.role, b.status, targetId]
    );
    if (rowCount === 0) return null;
    if (b.department_ids) {
      await client.query('DELETE FROM user_departments WHERE user_id = $1', [targetId]);
      for (const dId of b.department_ids) {
        await client.query('INSERT INTO user_departments (user_id, department_id) VALUES ($1,$2) ON CONFLICT DO NOTHING', [targetId, dId]);
      }
    }
    return rows[0];
  });
  if (!updated) throw notFound('User not found');
  emitEvent('user_updated', { id: targetId });
  res.json(updated);
}));

router.post('/:id/reset-password', adminOnly, validate({ params: schemas.idParam, body: schemas.resetPassword }), asyncHandler(async (req, res) => {
  const hash = await bcrypt.hash(req.body.newPassword, config.BCRYPT_ROUNDS);
  const { rowCount } = await pool.query('UPDATE users SET password_hash=$1, must_change_password=false WHERE id=$2', [hash, req.params.id]);
  if (rowCount === 0) throw notFound('User not found');
  res.json({ success: true });
}));

router.delete('/:id', adminOnly, validate({ params: schemas.idParam }), asyncHandler(async (req, res) => {
  if (Number(req.params.id) === req.user.id) throw badRequest('You cannot remove your own account');
  const { rowCount } = await pool.query('DELETE FROM users WHERE id = $1', [req.params.id]);
  if (rowCount === 0) throw notFound('User not found');
  emitEvent('user_deleted', { id: Number(req.params.id) });
  res.json({ success: true });
}));

module.exports = router;
